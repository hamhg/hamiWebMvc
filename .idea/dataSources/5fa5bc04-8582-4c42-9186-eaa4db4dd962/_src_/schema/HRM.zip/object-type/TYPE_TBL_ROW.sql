CREATE TYPE "TYPE_TBL_ROW"                                                                                                                                                                                                AS OBJECT
(
  COL1 VARCHAR2( 255 )
, COL2 VARCHAR2( 4000 )
, COL3 VARCHAR2( 255 )
, COL4 VARCHAR2( 255 )
);
/
