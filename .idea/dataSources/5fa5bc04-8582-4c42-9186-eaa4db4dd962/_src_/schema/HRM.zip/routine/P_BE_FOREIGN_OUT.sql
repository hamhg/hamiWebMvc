CREATE PROCEDURE     P_BE_FOREIGN_OUT 
(
    I_C_CD              IN  VARCHAR2,     --회사코드 
    I_EMP_ID            IN  VARCHAR2,     --  
    I_STA_YMD           IN  VARCHAR2,
    I_APPNT_CD          IN  VARCHAR2,
    O_ERRORCODE         OUT VARCHAR2,
    O_ERRORMESG         OUT VARCHAR2
)
IS
/***********************************************************************
  Program Name  : P_BE_FOREIGN_IN_OUT
  Description   : 해외부임 발령시 출입국 관리에 저장
  Author        : 김영규 
  History       : 2010-08-30 신규개발
***********************************************************************/
    --V_BE_CLOSE_YN   VARCHAR2(1);
    --V_DATA_ID       VARCHAR2(20);
    V_END_YMD           VARCHAR2(8);
    V_WORK_LOC_ID       VARCHAR(20);
    V_WORK_LOC_NM       VARCHAR(200);
    V_PER_NO            VARCHAR(32);
    V_BTRIP_CLASS       VARCHAR(20);
    V_CNT               NUMBER;
    
    V_EMP_TYPE          VARCHAR2(20);
    
BEGIN
       
    SELECT T2.PER_NO
           , T1.WORK_LOC_ID
           , T1.END_YMD
           , T1.WORK_LOC_NM
           , T1.BTRIP_CLASS
           , T1.EMP_TYPE
      INTO V_PER_NO
           , V_WORK_LOC_ID
           , V_END_YMD
           , V_WORK_LOC_NM
           , V_BTRIP_CLASS
           , V_EMP_TYPE
       FROM PA1020 T1
            , PA1010# T2
     WHERE T1.C_CD = I_C_CD
       AND T1.EMP_ID = I_EMP_ID
       AND I_STA_YMD BETWEEN T1.STA_YMD AND T1.END_YMD
       AND T1.LAST_YN = 'Y'           
       AND T2.C_CD = T1.C_CD 
       AND T2.EMP_ID = T1.EMP_ID;
       
    -- 외주직원의 경우 해외출입국 관리에 별도 관리하지 않는다.
    IF V_EMP_TYPE IN ('8','8H','8P') THEN
        RETURN;
    END IF;

    -- IF I_APPNT_CD ='20' OR (I_APPNT_CD ='11' AND V_BTRIP_CLASS ='002') THEN  -- 장기출장.해외현장부임
    IF I_APPNT_CD IN ( '20', '11' ) THEN  -- 장기출장.해외현장부임
        
        SELECT NVL(COUNT(*),0)
          INTO V_CNT
          FROM BE2310# T1
         WHERE T1.C_CD = I_C_CD
           AND T1.EMP_ID = I_EMP_ID
           AND I_STA_YMD BETWEEN T1.STA_YMD AND NVL(T1.END_YMD, '999991231');      
        
        IF V_CNT = 0 THEN
        
            INSERT INTO BE2310# 
            (
                C_CD
                , EMP_ID
                , PER_NO
                , WORK_LOC_ID
                , WORK_LOC_NM
                , STA_YMD
                , END_YMD
                , TRG_YN        -- 입력구분
                , IN_TYPE       --공재대상여부
                , INS_USER_ID
                , INS_YMDHMS
            )
            VALUES
            (
                I_C_CD
                , I_EMP_ID
                , V_PER_NO
                , V_WORK_LOC_ID
                , V_WORK_LOC_NM
                , I_STA_YMD
                , '99991231'
                , 'Y'
                , '1'
                , 'SYSTEM'
                , SYSDATE  
            );
            
        END IF;
    
            
    ELSIF I_APPNT_CD IN('12' , '22') THEN   -- 장기출장,해외현장복귀
        
        UPDATE BE2310# 
           SET END_YMD = I_STA_YMD
         WHERE C_CD   = I_C_CD 
           AND EMP_ID = I_EMP_ID
           AND I_STA_YMD BETWEEN STA_YMD AND NVL(END_YMD, '99991231');
    
    END IF;


    O_ERRORCODE := '0';
    O_ERRORMESG := '성공';
    
EXCEPTION

    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE;   -- -20000;
        O_ERRORMESG := SQLERRM;
        
END;
/
