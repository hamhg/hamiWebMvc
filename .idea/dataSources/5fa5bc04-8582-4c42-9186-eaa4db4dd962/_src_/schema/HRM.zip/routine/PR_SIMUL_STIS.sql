CREATE PROCEDURE     PR_SIMUL_STIS
(
     AV_C_CD              IN VARCHAR2,
     AV_STND_YY        IN VARCHAR2,
     AV_USER_ID           IN VARCHAR2, --작업자ID
     O_ERRORCODE        OUT VARCHAR2,
     O_ERRORMESG        OUT VARCHAR2
 )
IS


/***********************************************************************
 PROGRAM NAME   : PR_SIMUL_STIS
 DESCRIPTION    : 승진인건비시뮬레이션 데이터 생성
 AUTHOR         : 
 HISTORY        : 기본정보를 미리 생성하는 기능
                  
***********************************************************************/

V_VAL NUMBER;

BEGIN

    BEGIN
         SELECT COUNT(C_CD) CNT
         INTO V_VAL
         FROM   PA2336
         WHERE C_CD = AV_C_CD
         AND     STND_YY = AV_STND_YY;
    EXCEPTION 
    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE;
        O_ERRORMESG := SQLERRM;
        ROLLBACK;
        RETURN;
    END;
    
    IF V_VAL = 0 THEN
        BEGIN
             INSERT INTO  PA2336
                                  (C_CD,
                                   STND_YY,
                                   PROM_BF_POST,
                                   PROM_AFT_POST,
                                   INS_USER_ID,                
                                   INS_YMDHMS,                
                                   MOD_USER_ID,                
                                   MOD_YMDHMS  
                                   )
                                   (SELECT C_CD,
                                                PROM_YY,
                                                PROM_BF_POST,
                                                PROM_AFT_POST,
                                                AV_USER_ID,
                                                SYSDATE,
                                                AV_USER_ID,
                                                SYSDATE 
                                    FROM PA2310   
                                    WHERE C_CD =AV_C_CD
                                    AND     PROM_YY = AV_STND_YY
                                    GROUP BY C_CD,PROM_YY,PROM_BF_POST,PROM_AFT_POST
                                    UNION ALL
                                    SELECT AV_C_CD,
                                                AV_STND_YY,
                                                'TOT',
                                                'TOT',
                                                AV_USER_ID,
                                                SYSDATE,
                                                AV_USER_ID,
                                                SYSDATE
                                    FROM DUAL
                                    WHERE EXISTS (SELECT 'X' FROM PA2336 WHERE C_CD = AV_C_CD AND STND_YY = AV_STND_YY)
                                    );             
             
        EXCEPTION
        WHEN OTHERS THEN
            O_ERRORCODE := SQLCODE;
            O_ERRORMESG := SQLERRM;
            ROLLBACK;
            RETURN;
        END;
    END IF;

    O_ERRORCODE := '0';
    O_ERRORMESG := '';

  EXCEPTION
    WHEN OTHERS THEN
      O_ERRORCODE := SQLCODE;
      O_ERRORMESG := SQLERRM;

END PR_SIMUL_STIS;
/
