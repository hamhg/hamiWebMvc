CREATE PROCEDURE     att_temp(
    O_ERRORCODE    OUT VARCHAR2,   -- 처리코드
    O_ERRORMESG    OUT VARCHAR2    -- 처리내역
)
is
begin
for att_temp in (
select emp_id, substr(enter_ymd, 1, 6) enter_ym
from pa1020_v_1
where emp_type in ('A','B','C','D','G')
    and stat_cd in ('10','13')
    AND EMP_ID NOT IN (SELECT EMP_ID FROM PA2260 WHERE WORK_CLASS = 'N' AND ROWNUM >0)
    and (emp_id, substr(enter_ymd, 1, 6)) not in (  select emp_id, ym
                                                    from tm3110
                                                 )
    and enter_ymd like '2011%'      
)    
loop    
 P_TM_QUOTA_010_MAIN_MM(
  'HEC'
, att_temp.enter_ym
, att_temp.emp_id
, 'SUPER'
, O_ERRORCODE
, O_ERRORMESG);
end loop;    
end;
/
