CREATE PROCEDURE P_BE_CONDO_SLECTION
(
  I_C_CD            IN VARCHAR2,         -- 회사코드
  I_YY              IN VARCHAR2,         -- 년도
  I_ORDER_NO_CD     IN VARCHAR2,         -- 차수
  I_CONDO_CD        IN VARCHAR2,         -- 콘도
  I_MOD_USER_ID     IN VARCHAR2,         -- 작업자ID
  O_ERRORCODE       OUT VARCHAR2,
  O_ERRORMESG       OUT VARCHAR2
)
IS
/***********************************************************************
 PROGRAM NAME   : P_BE_CONDO_SLECTION
 DESCRIPTION    : 콘도 이용 신청자 선발
 AUTHOR         : 김미진
 HISTORY        : 2008-07-25
***********************************************************************/

  V_SEL_P_CNT NUMBER;

BEGIN

  UPDATE BEP250 SET SEL_YN = 'N'
   WHERE C_CD     = I_C_CD
     AND YY       = I_YY
     AND ORDER_NO_CD   = I_ORDER_NO_CD
     AND CONDO_CD = I_CONDO_CD ;


  SELECT SEL_P_CNT INTO V_SEL_P_CNT
    FROM BEP040
   WHERE C_CD     = I_C_CD
     AND YY       = I_YY
     AND ORDER_NO_CD   = I_ORDER_NO_CD
     AND CONDO_CD = I_CONDO_CD ;


  UPDATE BEP250 SET SEL_NO = TRUNC((DBMS_RANDOM.VALUE)*10000 ,0)
   WHERE C_CD     = I_C_CD
     AND YY       = I_YY
     AND ORDER_NO_CD   = I_ORDER_NO_CD
     AND CONDO_CD = I_CONDO_CD ;


   UPDATE BEP250 SET SEL_YN = 'Y'
    WHERE (C_CD, YY, ORDER_NO_CD, CONDO_CD, EMP_ID)
       IN
         (
            SELECT C_CD, YY, ORDER_NO_CD, CONDO_CD, EMP_ID
              FROM (
                    SELECT C_CD, YY, ORDER_NO_CD, CONDO_CD, EMP_ID
                      FROM BEP250
                     WHERE C_CD     = I_C_CD
                       AND YY       = I_YY
                       AND ORDER_NO_CD   = I_ORDER_NO_CD
                       AND CONDO_CD = I_CONDO_CD
                    ORDER BY SEL_NO
                   )
             WHERE ROWNUM < V_SEL_P_CNT + 1
         );

   UPDATE BEP040 SET SEL_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')
    WHERE C_CD     = I_C_CD
     AND YY       = I_YY
     AND ORDER_NO_CD   = I_ORDER_NO_CD
     AND CONDO_CD = I_CONDO_CD ;

  O_ERRORCODE := 0;
  O_ERRORMESG := '';

EXCEPTION
  WHEN OTHERS THEN
    O_ERRORCODE := SQLCODE;
    O_ERRORMESG := SQLERRM;
END;
/
