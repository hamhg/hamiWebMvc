CREATE PROCEDURE     P_BE_CLUB_180
(
    I_C_CD              IN VARCHAR2,
    I_PAYROLL_NO        IN VARCHAR2,
    I_CLUB_MON          IN  NUMBER,
    I_MOD_USER_ID       IN  VARCHAR2,
    O_ERRORCODE         OUT VARCHAR2,
    O_ERRORMESG         OUT VARCHAR2
)
IS
/***********************************************************************
  Program Name  : P_BE_CLUB_180
  Description   : 동호회비 대상자 동호회비 급여반영데이터 생성
  Author        : 김미진
  History       : 2008-08-12 신규개발
***********************************************************************/
    V_BE_CLOSE_YN VARCHAR2(1);

BEGIN

    -- 급여마감여부 체크
    -- 마감처리된 급여는 생성 불가함
    SELECT BE_CLOSE_YN
      INTO V_BE_CLOSE_YN
      FROM PY0300
     WHERE C_CD = I_C_CD
       AND PAYROLL_NO = I_PAYROLL_NO;


    IF V_BE_CLOSE_YN = 'Y' THEN
        RAISE_APPLICATION_ERROR(-20000, '급여가 마감되어 처리할 수 없습니다.');
    END IF;

    DELETE FROM BEE250
     WHERE C_CD = I_C_CD
       AND PAYROLL_NO = I_PAYROLL_NO;

    INSERT INTO BEE250
    (
        C_CD,
        PAYROLL_NO,
        EMP_ID,
        DDCT_MON,
        CONF_YN,
        BILL_DPS_YN,
        MOD_USER_ID,
        MOD_YMDHMS,
        INS_USER_ID,
        INS_YMDHMS
    )
    SELECT I_C_CD,
           I_PAYROLL_NO,
           --T1.CLUB_NO,
           T2.EMP_ID,
           I_CLUB_MON,
           'N',
           'N',
           I_MOD_USER_ID,
           SYSDATE,
           I_MOD_USER_ID,
           SYSDATE
      FROM BEE010# T1,
           BEE220 T2,
           PA1020_V_1 V1
     WHERE T1.C_CD = T2.C_CD
       AND T1.CLUB_NO = T2.CLUB_NO
       AND T2.C_CD = V1.C_CD
       AND T2.EMP_ID = V1.EMP_ID
       AND NVL(T1.END_YMD, '99991231') > TO_CHAR(SYSDATE, 'YYYYMMDD')   --폐쇄
       --AND NVL(T2.END_YMD,'99991231') > TO_CHAR(SYSDATE,'YYYYMMDD')   --탈퇴
       AND T2.STA_STAT_CD = '10'   -- 가입상태 재직
       AND T1.C_CD = I_C_CD
       AND V1.STAT_CD LIKE '1%';


    O_ERRORCODE := '0';
    O_ERRORMESG := '성공';
    
EXCEPTION

    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE;   -- -20000;
        O_ERRORMESG := SQLERRM;   --'동호회비 대상자 생성중 에러가 발생 하였습니다.';

END;
/
