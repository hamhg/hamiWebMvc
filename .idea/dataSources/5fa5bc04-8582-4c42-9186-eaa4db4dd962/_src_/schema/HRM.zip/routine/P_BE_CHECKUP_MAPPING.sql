CREATE PROCEDURE     P_BE_CHECKUP_MAPPING(
     AV_C_CD              IN  VARCHAR2,     --회사코드 
     AV_YY                   IN  VARCHAR2,     --대상년도
     AV_MOD_USER_ID IN  VARCHAR2,
     O_ERRORCODE   OUT VARCHAR2,
     O_ERRORMESG   OUT VARCHAR2
)
IS
/***********************************************************************
 Program Name   : P_BE_CHECKUP_MAPPING
 Description    : 건강검진 결과 대상자 매핑 처리 작업 
 Author         : 
 History        : 2010-11-18 신규개발
***********************************************************************/

BEGIN

    BEGIN
      MERGE INTO GAIS.BEH210# T1
                 USING (SELECT  T2.C_CD,T2.CHK_YMD,T2.PER_NO
                             FROM    GAIS.BEH100# T2
                             WHERE  T2.C_CD = AV_C_CD
                             AND      T2.YY = AV_YY
                             ) T2
                 ON (T1.YY = AV_YY
                       AND T1.C_CD = AV_C_CD
                       AND T2.PER_NO = T1.FAM_PER_NO
                       )
      WHEN MATCHED THEN
             UPDATE SET T1.CHK_YMD = T2.CHK_YMD,T1.CHK_YN='Y',T1.MAPPING_YN='Y',T1.MOD_USER_ID=AV_MOD_USER_ID,T1.MOD_YMDHMS=SYSDATE;
    EXCEPTION WHEN OTHERS THEN
       O_ERRORCODE := SQLCODE;   
       O_ERRORMESG := SQLERRM;
       ROLLBACK;
       RETURN;
    END;
    
    
      

  O_ERRORCODE := '0';
  O_ERRORMESG := '성공';
EXCEPTION
  WHEN OTHERS
  THEN
    O_ERRORCODE := SQLCODE;  
    O_ERRORMESG := SQLERRM;  
END;
/
