CREATE PROCEDURE P_ADJ_2014_CHANGE_PER_NO
(
    I_C_CD          VARCHAR2,
    I_ADJ_YY        VARCHAR2,
    I_EMP_ID        VARCHAR2,
    I_OLD_PER_NO    VARCHAR2,
    I_NEW_PER_NO    VARCHAR2,
    O_ERRORCODE     OUT VARCHAR2,
    O_ERRORMESG     OUT VARCHAR2    
)
/***********************************************************************
  Program Name  : P_ADJ_2014_CHANGE_PER_NO
  Description   : (14년 귀속) 연말정산 대상자 주민번호 일괄 갱신
  Author        : 노형래
  History       : 2015-02-09 신규개발 (부양가족 주민번호 일괄갱신)
***********************************************************************/
IS
BEGIN

    --// YA2030#
    INSERT INTO YA2030#
    (
        C_CD, ADJ_YY, EMP_ID
        , PER_NO
        , FAM_NM
        , FAM_CD, INCM_DDCT_YN, DISABLE_YN, OLD_YN, CHILD_YN
        , SCHO_CD, EDU_MON, CARD_MON, CASH_MON, ACD_GIRO_MON
        , STA_YMD, END_YMD, ADOPT_YMD, ADOPT_YN, NOTE
        , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
        , CHARG_CHILD_YN, BAS_COMOUT_YN, WOMAN_DDCT_YN, SGL_PNT_YN, DISABLE_CD, FOREIGN_YN    
    )
    SELECT C_CD, ADJ_YY, EMP_ID
           , F_HEC_ENC_PER( REPLACE(I_NEW_PER_NO, '-', '') ) AS PER_NO
           , FAM_NM, FAM_CD, INCM_DDCT_YN, DISABLE_YN, OLD_YN, CHILD_YN
           , SCHO_CD, EDU_MON, CARD_MON, CASH_MON, ACD_GIRO_MON
           , STA_YMD, END_YMD, ADOPT_YMD, ADOPT_YN, NOTE
           , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
           , CHARG_CHILD_YN, BAS_COMOUT_YN, WOMAN_DDCT_YN, SGL_PNT_YN, DISABLE_CD, FOREIGN_YN
      FROM YA2030# T1  
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;


    --// YA2050#
    INSERT INTO YA2050#
    (
        C_CD, ADJ_YY, EMP_ID
        , PER_NO
        , SEQ_NO
        , ADJITEM, DATA_TYPE, MEDI_ASSO_TYPE, BIZ_NO
        , FIRM_NM, CARD_CNT, CASH_MON, CARD_MON, CASH_CNT
        , NOTE
        , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
        , PDF_FILE_YN    
    )
    SELECT C_CD, ADJ_YY, EMP_ID
           , F_HEC_ENC_PER( REPLACE(I_NEW_PER_NO, '-', '') ) AS PER_NO
           , SEQ_NO
           , ADJITEM, DATA_TYPE, MEDI_ASSO_TYPE, BIZ_NO
           , FIRM_NM, CARD_CNT, CASH_MON, CARD_MON, CASH_CNT
           , NOTE
           , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
           , PDF_FILE_YN
      FROM YA2050# T1  
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;


    --// YA2060#
    INSERT INTO YA2060#        
    (
        C_CD, ADJ_YY, EMP_ID
        , PER_NO
        , SEQ_NO
        , DATA_TYPE, ADJITEM, ASSO_NM, BIZ_NO
        , TRG_PER_NO
        , MON, CNT, DONAT_TXT, YM
        , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
        , PDF_FILE_YN, PAY_DATA_YN    
    )
    SELECT C_CD, ADJ_YY, EMP_ID
           , F_HEC_ENC_PER( REPLACE(I_NEW_PER_NO, '-', '') ) AS PER_NO
           , SEQ_NO
           , DATA_TYPE, ADJITEM, ASSO_NM, BIZ_NO
           , TRG_PER_NO
           , MON, CNT, DONAT_TXT, YM
           , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
           , PDF_FILE_YN, PAY_DATA_YN    
      FROM YA2060# T1  
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;    

       
    --// YA2060#
    UPDATE YA2060# T1
       SET T1.TRG_PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )   
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.TRG_PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;


    --// YA2061#
    UPDATE YA2061# T1
       SET T1.TRG_PER_NO = F_HEC_ENC_PER( REPLACE(I_NEW_PER_NO, '-', '') )
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.TRG_PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;
       

    --// YA2062#
  /*
    INSERT INTO YA2062#
    (
        C_CD, PAYITEM, STA_YM, END_YM, DATA_TYPE
        , ADJITEM, ASSO_NM, BIZ_NO
        , TRG_PER_NO
        , DONAT_TXT
        , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS    
    )
    SELECT     
      FROM YA2062# T1  
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.TRG_PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
  */
 
  
    --// YA2070#
    INSERT INTO YA2070#
    (
        C_CD, ADJ_YY, EMP_ID
        , PER_NO
        , SEQ_NO, DATA_TYPE
        , INSURED_PER_NO
        , ADJITEM, FIRM_NM, MON
        , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
        , PDF_FILE_YN
    ) 
    SELECT C_CD, ADJ_YY, EMP_ID
           , F_HEC_ENC_PER( REPLACE(I_NEW_PER_NO, '-', '') ) AS PER_NO
           , SEQ_NO, DATA_TYPE
           , INSURED_PER_NO
           , ADJITEM, FIRM_NM, MON
           , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
           , PDF_FILE_YN
      FROM YA2070# T1 
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;

    UPDATE YA2070# T1   --INSURED_PER_NO
       SET T1.INSURED_PER_NO = F_HEC_ENC_PER(I_NEW_PER_NO)
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.INSURED_PER_NO = F_HEC_ENC_PER(I_OLD_PER_NO)
       ;
       

    --// YA2100#
    INSERT INTO YA2100#
    (
        C_CD, ADJ_YY, EMP_ID
        , PER_NO
        , SEQ_NO, DATA_TYPE, CARD_NM, CARD_MON
        , CASH_MON, ACD_GIRO_MON, DDCT_MON
        , BIZ_NO, ADJITEM
        , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
        , DEBIT_CARD_MON, PDF_FILE_YN, BAZAR_MON, PUB_TRANS_MON, CARD_HALF_MON
        , CASH_HALF_MON, DEBIT_CARD_HALF_MON, BAZAR_HALF_MON, PUB_TRANS_HALF_MON    
    )
    SELECT C_CD, ADJ_YY, EMP_ID
           , F_HEC_ENC_PER( REPLACE(I_NEW_PER_NO, '-', '') ) AS PER_NO
           , SEQ_NO, DATA_TYPE, CARD_NM, CARD_MON
           , CASH_MON, ACD_GIRO_MON, DDCT_MON
           , BIZ_NO, ADJITEM
           , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
           , DEBIT_CARD_MON, PDF_FILE_YN, BAZAR_MON, PUB_TRANS_MON, CARD_HALF_MON
           , CASH_HALF_MON, DEBIT_CARD_HALF_MON, BAZAR_HALF_MON, PUB_TRANS_HALF_MON
      FROM YA2100# T1
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;
       

    --// YA2130#
    INSERT INTO YA2130# 
    (
        C_CD, ADJ_YY, EMP_ID
        , PER_NO
        , SEQ_NO, ADJITEM, MON, DATA_TYPE, NOTE
        , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
        , SCHL_MON, SCHL_UNI_MON, PDF_FILE_YN    
    )
    SELECT C_CD, ADJ_YY, EMP_ID
           , F_HEC_ENC_PER( REPLACE(I_NEW_PER_NO, '-', '') ) AS PER_NO
           , SEQ_NO, ADJITEM, MON, DATA_TYPE, NOTE
           , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
           , SCHL_MON, SCHL_UNI_MON, PDF_FILE_YN 
      FROM YA2130# T1
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;


    --// YA2150#
    UPDATE YA2150# T1   --LOAN_PER_NO
       SET T1.LOAN_PER_NO = F_HEC_ENC_PER( REPLACE(I_NEW_PER_NO, '-', '') )
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.LOAN_PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') ) 
       ;
       
    UPDATE YA2150# T1   --LEASE_PER_PER_NO
       SET T1.LEASE_PER_PER_NO = F_HEC_ENC_PER( REPLACE(I_NEW_PER_NO, '-', '') )
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.LEASE_PER_PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') ) 
       ;


    --// YA3030#
    INSERT INTO YA3030#
    (
        C_CD, EMP_ID, ADJ_YY, ADJITEM
        , TRG_PER_NO
        , MON, APPLY_YN, NOTE
        , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
        , HALF_MON   
    )   
    SELECT C_CD, EMP_ID, ADJ_YY, ADJITEM
           , F_HEC_ENC_PER( REPLACE(I_NEW_PER_NO, '-', '') ) AS TRG_PER_NO
           , MON, APPLY_YN, NOTE
           , INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS
           , HALF_MON
      FROM YA3030# T1
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.TRG_PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;      
       
    --=====================================================================================================

    DELETE YA3030# T1
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.TRG_PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;

    DELETE FROM YA2130# T1
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;

    DELETE FROM YA2100# T1
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;

    DELETE FROM YA2070# T1
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;

    DELETE FROM YA2060# T1
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;

    DELETE FROM YA2050# T1
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;

    DELETE FROM YA2030# T1
     WHERE T1.C_CD = I_C_CD
       AND T1.ADJ_YY = I_ADJ_YY
       AND T1.EMP_ID = I_EMP_ID
       AND T1.PER_NO = F_HEC_ENC_PER( REPLACE(I_OLD_PER_NO, '-', '') )
       ;


    O_ERRORCODE := '0';
    O_ERRORMESG := '성공';

    COMMIT;

EXCEPTION

    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE;
        O_ERRORMESG := SQLERRM;
    
END;
/
