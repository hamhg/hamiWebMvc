CREATE PROCEDURE     P_BE015_BATCH01(
  I_C_CD        IN VARCHAR2,
  I_YY          IN VARCHAR2,
  I_SINS_TYPE   IN VARCHAR2,
  I_MOD_USER_ID IN VARCHAR2,
  O_CNT         OUT NUMBER,   --실행갯수
  O_ERRORCODE   OUT VARCHAR2,   --결과코드
  O_ERRORMESG   OUT VARCHAR2   --결과메시지
)
IS
/***********************************************************************
 Program Name   : P_BE015_BATCH01
 Description    : 사회보험 등급 생성 배치
 Author         :
 History        :
***********************************************************************/
  V_YY_PRV VARCHAR2(4);   --전년
  V_RPT_NO NUMBER;   --일련번호
  R1 BE2040%ROWTYPE;
  V_TOT_MON_20 NUMBER;   --월근무20일미만 급여
/*
DECLARE
  O_CNT      NUMBER;
  O_ERRORCODE      VARCHAR2(500);
  O_ERRORMESG      VARCHAR2(500);
  A        DATE;
  B        DATE;
BEGIN
   SELECT SYSDATE INTO A FROM DUAL;
  P_BE015_BATCH01(  '10', '2007', '2', 'SUPER',O_CNT , O_ERRORCODE, O_ERRORMESG);

    SELECT SYSDATE INTO B FROM DUAL;
  DBMS_OUTPUT.put_line(TO_CHAR(A,'HH:MI:SS')||' = '||TO_CHAR(B,'HH:MI:SS')||' = '||O_ERRORMESG);
END;
*/
BEGIN
  V_RPT_NO := 0;
  --v_yy_prv := to_char(to_number(i_yy)-1);
  V_YY_PRV := I_YY;

  DELETE FROM BE2040
        WHERE SINS_TYPE = I_SINS_TYPE
          AND YY = I_YY;

  IF I_SINS_TYPE = '1'
  THEN
    /*
    대상 : 전년도 10월 1일 이전 입사자 (10월 2일 이후 입사자는 제외) 중 국민연금 가입중인 직원
    - 산정월수 : 전년도 당해 사업장 근무월수 - 20일 미만 근무월수
    - 기준일 : 전년도 1월 1일 입사자=전년도1월1일 / 전년 중 입사자=입사일
    - 산정기준금액 : 전년도 당해 사업장 소득총액(연말정산결과 YA2120 테이블에서 현근무지 소득총액) - 20일 미만 근무월 소득
    - 평균소득 : 산정기준금액 / 산정월수
    - 표준보수월액 : 사회보험등급표(BE0011)에서 평균소득이 해당되는 구간의 표준보수월액
    - 신고번호 : 성명 가나다순 일련번호
    */
    FOR C1 IN (SELECT   T1.EMP_ID,
                        T1.ENTER_YMD,
                        T1.RETIRE_YMD
                   FROM PA1010# T1,
                        BE1010 T2,
                        PA1020 T3
                  WHERE T1.C_CD = I_C_CD
                    AND T1.ENTER_YMD <= V_YY_PRV || '1001'
                    AND T2.C_CD = T1.C_CD
                    AND T2.EMP_ID = T1.EMP_ID
                    AND T2.SINS_TYPE = I_SINS_TYPE
                    AND T3.C_CD = T1.C_CD
                    AND T3.EMP_ID = T1.EMP_ID
                    AND T3.LAST_YN = 'Y'
                    AND TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN T3.STA_YMD AND T3.END_YMD
                    AND T3.STAT_CD LIKE '1%'
               ORDER BY T1.EMP_NM)
    LOOP
      V_RPT_NO := V_RPT_NO + 1;
      R1.STD_YMD := GREATEST(C1.ENTER_YMD, V_YY_PRV || '0101');   --기준일

      --산정월수
      SELECT COUNT(*)
        INTO R1.M_CNT
        FROM YA2090
       WHERE C_CD = I_C_CD
         AND ADJ_YY = V_YY_PRV
         AND EMP_ID = C1.EMP_ID
         AND D_CNT >= 20;

      --소득총액
      SELECT NVL(MAX(CR_TOT_INCM_MON), 0)
        INTO R1.TOT_INCM_MON
        FROM YA2110
       WHERE C_CD = I_C_CD
         AND ADJ_YY = V_YY_PRV
         AND EMP_ID = C1.EMP_ID;

      --20일미만월금액
      SELECT NVL(SUM(TOT_PAY_MON + TOT_BONUS_MON + RCG_BONUS_MON), 0)
        INTO V_TOT_MON_20
        FROM YA2090
       WHERE C_CD = I_C_CD
         AND ADJ_YY = V_YY_PRV
         AND EMP_ID = C1.EMP_ID
         AND D_CNT < 20;

      --산정기준금액
      R1.CALC_STD_MON := R1.TOT_INCM_MON - V_TOT_MON_20;

      --평균소득
      R1.AVG_INCM_MON := CASE WHEN R1.M_CNT = 0 THEN 0 ELSE R1.CALC_STD_MON / R1.M_CNT END;

      --전년보험료남부총액
      SELECT NVL(SUM(T1.PSN_MON + T1.COM_MON), 0),
             COUNT(*)
        INTO R1.BF_TOT_INS_MON,
             R1.BF_INS_M_CNT
        FROM BE2010 T1,
             PY0300 T2
       WHERE T1.C_CD = I_C_CD
         AND T1.EMP_ID = C1.EMP_ID
         AND T1.SINS_TYPE = I_SINS_TYPE
         AND T2.C_CD = T1.C_CD
         AND T2.PAYROLL_NO = T1.PAYROLL_NO
         AND T2.PAYROLL_YMD LIKE V_YY_PRV || '%';

      --신고번호
      R1.RPT_NO := LPAD(V_RPT_NO, 5, '0');

-------------------------------
-------------------------------
-------------------------------
      INSERT INTO BE2040
                  (C_CD,
                   EMP_ID,
                   SINS_TYPE,
                   YY,
                   STD_YMD,
                   M_CNT,
                   TOT_INCM_MON,
                   CALC_STD_MON,
                   AVG_INCM_MON,
                   STD_MPAY_MON,
                   BF_INS_M_CNT,
                   BF_TOT_INS_MON,
                   RPT_NO,
                   GRD_CD,
                   MOD_USER_ID,
                   MOD_YMDHMS,
INS_USER_ID,
INS_YMDHMS
                  )
           VALUES (I_C_CD,
                   C1.EMP_ID,
                   I_SINS_TYPE,
                   I_YY,
                   R1.STD_YMD,
                   R1.M_CNT,
                   R1.TOT_INCM_MON,
                   NVL(R1.CALC_STD_MON, 0),
                   R1.AVG_INCM_MON,
                   0,   -- r1.STD_MPAY_MON
                   R1.BF_INS_M_CNT,
                   NVL(R1.BF_TOT_INS_MON, 0),
                   R1.RPT_NO,
                   0,   -- r1.GRD_CD
                   I_MOD_USER_ID,
                   SYSDATE,
                   I_MOD_USER_ID,
                   SYSDATE
                  );
    END LOOP;
  ELSIF I_SINS_TYPE = '2'
  THEN
    /*
    <건강보험 소득총액 신고파일 Logic >
    - 대상 : 전년도 12월 31일 이전 입사하여 현재 건강보험 가입중인 직원
    - 산정월수 : 당해 사업장 근무월수
    - 기준일 : 전년도 1월 1일 입사자=전년도1월1일 / 전년 중 입사자=입사일
    - 산정기준금액 : 전년도 당해 사업장 소득총액(연말정산결과 YA2120 테이블에서 현근무지 소득총액)
    */
    FOR C1 IN (SELECT   T1.EMP_ID,
                        T1.ENTER_YMD,
                        T1.RETIRE_YMD
                   FROM PA1010# T1,
                        BE1010 T2,
                        PA1020 T3
                  WHERE T1.C_CD = I_C_CD
                    AND T1.ENTER_YMD <= V_YY_PRV || '1231'
                    AND T2.C_CD = T1.C_CD
                    AND T2.EMP_ID = T1.EMP_ID
                    AND T2.SINS_TYPE = I_SINS_TYPE
                    AND T3.C_CD = T1.C_CD
                    AND T3.EMP_ID = T1.EMP_ID
                    AND T3.LAST_YN = 'Y'
                    AND TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN T3.STA_YMD AND T3.END_YMD
                    AND T3.STAT_CD LIKE '1%'
               ORDER BY T1.EMP_NM)
    LOOP
      V_RPT_NO := V_RPT_NO + 1;
      R1.STD_YMD := GREATEST(C1.ENTER_YMD, V_YY_PRV || '0101');   --기준일

      --산정월수
      SELECT COUNT(*)
        INTO R1.M_CNT
        FROM YA2090
       WHERE ADJ_YY = V_YY_PRV
         AND EMP_ID = C1.EMP_ID;

      --소득총액
      SELECT NVL(MAX(CR_TOT_INCM_MON), 0)
        INTO R1.TOT_INCM_MON
        FROM YA2110
       WHERE C_CD = I_C_CD
         AND ADJ_YY = V_YY_PRV
         AND EMP_ID = C1.EMP_ID;

      /*
      --20일미만월금액
      select sum(TOT_PAY_MON + TOT_BONUS_MON + RCG_BONUS_MON)
        into v_tot_mon_20
        from ya2090
       where adj_yy = v_yy_prv
         and emp_id = c1.emp_id
         and D_CNT < 20;
      */

      --산정기준금액
      R1.CALC_STD_MON := R1.TOT_INCM_MON;

      --평균소득
      R1.AVG_INCM_MON := CASE WHEN R1.M_CNT = 0 THEN 0 ELSE R1.CALC_STD_MON / R1.M_CNT END;

      --전년보험료남부총액
      SELECT SUM(PSN_MON + COM_MON),
             COUNT(*)
        INTO R1.BF_TOT_INS_MON,
             R1.BF_INS_M_CNT
        FROM BE2010 T1,
             PY0300 T2
       WHERE T1.C_CD = I_C_CD
         AND T1.C_CD = T2.C_CD
         AND T1.EMP_ID = C1.EMP_ID
         AND T1.PAYROLL_NO = T2.PAYROLL_NO
         AND T1.SINS_TYPE = I_SINS_TYPE
         AND T2.PAYROLL_YMD LIKE V_YY_PRV || '%';

      DBMS_OUTPUT.PUT_LINE(C1.EMP_ID || ' = ' || R1.BF_TOT_INS_MON);
      --신고번호
      R1.RPT_NO := LPAD(V_RPT_NO, 5, '0');

-------------------------------
-------------------------------
-------------------------------
      INSERT INTO BE2040
                  (C_CD,
                   EMP_ID,
                   SINS_TYPE,
                   YY,
                   STD_YMD,
                   M_CNT,
                   TOT_INCM_MON,
                   CALC_STD_MON,
                   AVG_INCM_MON,
                   STD_MPAY_MON,
                   BF_INS_M_CNT,
                   BF_TOT_INS_MON,
                   RPT_NO,
                   GRD_CD,
                   MOD_USER_ID,
                   MOD_YMDHMS,
INS_USER_ID,
INS_YMDHMS
                  )
           VALUES (I_C_CD,
                   C1.EMP_ID,
                   I_SINS_TYPE,
                   I_YY,
                   R1.STD_YMD,
                   R1.M_CNT,
                   R1.TOT_INCM_MON,
                   NVL(R1.CALC_STD_MON, 0),
                   R1.AVG_INCM_MON,
                   0,   --r1.STD_MPAY_MON
                   R1.BF_INS_M_CNT,
                   NVL(R1.BF_TOT_INS_MON, 0),
                   R1.RPT_NO,
                   0,   --r1.GRD_CD
                   I_MOD_USER_ID,
                   SYSDATE,
                   I_MOD_USER_ID,
                   SYSDATE
                  );
    END LOOP;
  ELSE
    RAISE_APPLICATION_ERROR(-20000, 'invalid SINS_TYPE.');
  END IF;

  O_CNT := V_RPT_NO;
  O_ERRORCODE := 0;
  O_ERRORMESG := '';
EXCEPTION
  WHEN OTHERS
  THEN
    O_ERRORCODE := SQLCODE;
    O_ERRORMESG := SQLERRM;
END;
/
