CREATE PROCEDURE     P_BE_CHECKUP_094_UL01
(
    I_C_CD              IN  VARCHAR2,     --회사코드 
    I_YY                IN  VARCHAR2,     --대상년도
    I_MOD_USER_ID       IN  VARCHAR2,
    O_ERRORCODE         OUT VARCHAR2,
    O_ERRORMESG         OUT VARCHAR2
)
IS
/***********************************************************************
  Program Name  : P_BE_CHECKUP_094_UL01
  Description   : 건강검진 결과 대상자 매핑 처리 작업 
  Author        : 윤병근 
  History       : 2010-11-18 신규개발
***********************************************************************/
    V_COUNT           NUMBER := 0;  
    V_EMP_ID          VARCHAR2(20);       
    CUR_PER_NO        VARCHAR2(32);       
    CUR_SEQ_NO        NUMBER;
    CUR_CHK_YMD       VARCHAR2(8);

    CURSOR CUR1 IS SELECT SEQ_NO, 
                          PER_NO,
                          CHK_YMD
                     FROM GAIS.BEH100#
                    WHERE C_CD = I_C_CD
                      AND YY   = I_YY;   
                       
BEGIN


    OPEN CUR1;
                          
    LOOP FETCH CUR1 INTO CUR_SEQ_NO,    
                         CUR_PER_NO,
                         CUR_CHK_YMD;    
    
        IF CUR1%NOTFOUND THEN 
            GOTO END_RTN;      
        END IF;

        BEGIN
      
            SELECT COUNT(*)
              INTO V_COUNT 
              FROM GAIS.BEH210#
             WHERE C_CD       = I_C_CD
               AND YY         = I_YY
               AND FAM_PER_NO = CUR_PER_NO;
               
        EXCEPTION
        
            WHEN NO_DATA_FOUND THEN 
                V_COUNT := 0;   
         
        END;
        
        IF V_COUNT > 0 THEN 

            --==========================
            --== 가족정보 확인 
            --==========================
            BEGIN 
         
                SELECT EMP_ID
                  INTO V_EMP_ID        
                  FROM PA2030#
                 WHERE C_CD   = I_C_CD
                   AND PER_NO = CUR_PER_NO
                   AND ROWNUM = 1; 
                
            EXCEPTION
            
                WHEN NO_DATA_FOUND THEN 
                    SELECT EMP_ID 
                      INTO V_EMP_ID        
                      FROM PA1010#
                     WHERE C_CD   = I_C_CD
                       AND PER_NO = CUR_PER_NO
                       AND ROWNUM = 1;  
            END;

            --=========================================
            --== 건강검진 관리 테이블에 검진여부 적용  
            --=========================================
            UPDATE GAIS.BEH210#
               SET MAPPING_YN = 'Y',
                   CHK_YN     = 'Y',
                   CHK_YMD    = CUR_CHK_YMD
             WHERE C_CD       = I_C_CD
               AND YY         = I_YY
               AND FAM_PER_NO = CUR_PER_NO;      
            
            --=========================================
            --== 건강검진 임시 테이블에 매핑여부 적용 
            --=========================================
            UPDATE GAIS.BEH100#
               SET EMP_ID      = V_EMP_ID,
                   MAPPING_YN  = 'Y',
                   MOD_USER_ID = I_MOD_USER_ID,
                   MOD_YMDHMS  = SYSDATE
             WHERE C_CD   = I_C_CD
               AND YY     = I_YY      
               AND SEQ_NO = CUR_SEQ_NO    
               AND PER_NO = CUR_PER_NO;
               

        ELSE 

            --============================================
            --== 건강검진 임시 테이블에 미매핑 자료 적용  
            --============================================
            UPDATE GAIS.BEH100#
               SET EMP_ID      = V_EMP_ID,
                   MAPPING_YN  = 'N',
                   MOD_USER_ID = I_MOD_USER_ID,
                   MOD_YMDHMS  = SYSDATE
             WHERE C_CD   = I_C_CD
               AND YY     = I_YY      
               AND SEQ_NO = CUR_SEQ_NO    
               AND PER_NO = CUR_PER_NO;
                 
        END IF;


    END LOOP;    
  
    << END_RTN >>     
    CLOSE  CUR1;                 

    O_ERRORCODE := '0';
    O_ERRORMESG := '성공';

EXCEPTION

    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE;   -- -20000;
        O_ERRORMESG := SQLERRM;   --'건강검진 결과 완료 매핑 처리 중 에러가 발생 하였습니다.';
        
END;
/
