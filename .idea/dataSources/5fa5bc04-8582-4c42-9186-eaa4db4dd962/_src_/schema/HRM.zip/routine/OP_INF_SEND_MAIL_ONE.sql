CREATE PROCEDURE     OP_INF_SEND_MAIL_ONE
(
     I_C_CD              IN VARCHAR2
    ,I_MAILTYPE          IN VARCHAR2 --메일유형 (채용비번찾기 EHR01, E-HR비번찾기 EHR02, 신청서 EHR03 ...)
    ,I_EMAIL             IN VARCHAR2 --받는사람메일주소
    ,I_EMP_ID            IN VARCHAR2 --받는사람사번
    ,I_NAME              IN VARCHAR2 --받는사람이름
    ,I_VAL01             IN VARCHAR2 --메일내용
    ,I_VAL02             IN VARCHAR2 --메일내용
    ,I_VAL03             IN VARCHAR2 --메일내용
    ,I_VAL04             IN VARCHAR2 --메일내용
    ,I_VAL05             IN VARCHAR2 --메일내용
    ,I_VAL06             IN VARCHAR2 --메일내용
    ,I_VAL07             IN VARCHAR2 --메일내용
    ,I_VAL08             IN VARCHAR2 --메일내용
    ,I_VAL09             IN VARCHAR2 --메일내용
    ,I_VAL10             IN VARCHAR2 --메일내용
    ,I_USER_ID           IN VARCHAR2 --작업자ID
    ,I_ORG_NM            IN VARCHAR2 --받는사람조직명
    ,O_ERRORCODE        OUT VARCHAR2
    ,O_ERRORMESG        OUT VARCHAR2
 )
IS


/***********************************************************************
 PROGRAM NAME   : OP_INF_SEND_MAIL
 DESCRIPTION    : 메일 발송
 AUTHOR         : YYK
 HISTORY        : 2009-04-14 신규개발
                  TMP 테이블에 여러건 담아 한꺼번에 메일발송하는 방법.
***********************************************************************/


BEGIN



    INSERT INTO SC_MAIL_LIST_EHR@EMA_LINK
    (
         SEQ            --emaview.seq_sc_mail_list_ehr.NEXTVAL@dbl_ema
        ,MAILTYPE        --메일 유형을 구분하기 위한 값
        ,EMAIL            --수신자 메일 주소
        ,CMPNCODE        --EMA 시스템에 등록된 자동메일캠페인 번호(자동으로 업데이트됨)
        ,SENDYN            --N
        ,ENTERDATE        --SYSDATE
        ,MODIFYDATE
        ,OPENDATE
        ,EMP_ID            --사번
        ,NAME            --사원명
        ,VAL1
        ,VAL2
        ,VAL3
        ,VAL4
        ,VAL5
        ,VAL6
        ,VAL7
        ,VAL8
        ,VAL9
        ,VAL10
        ,CUSTOMERTYPE
        ,USER_ID
        ,I_SISL            --조직명
    )
    SELECT
         seq_sc_mail_list_ehr.NEXTVAL@EMA_LINK SEQ            --emaview.seq_sc_mail_list_ehr.NEXTVAL@dbl_ema
        ,I_MAILTYPE        --메일 유형을 구분하기 위한 값
        ,I_EMAIL            --수신자 메일 주소
        ,null CMPNCODE        --EMA 시스템에 등록된 자동메일캠페인 번호(자동으로 업데이트됨)
        ,'N' SENDYN            --N
        ,SYSDATE ENTERDATE        --SYSDATE
        ,NULL MODIFYDATE
        ,NULL OPENDATE
        ,I_EMP_ID            --사번
        ,I_NAME            --사원명
        ,I_VAL01
        ,I_VAL02
        ,I_VAL03
        ,I_VAL04
        ,I_VAL05
        ,I_VAL06
        ,I_VAL07
        ,I_VAL08
        ,I_VAL09
        ,I_VAL10
        ,NULL CUSTOMERTYPE
        ,I_USER_ID
        ,I_ORG_NM            --조직명
    FROM DUAL
    ;


    O_ERRORCODE := '0';
    O_ERRORMESG := '';

  EXCEPTION
    WHEN OTHERS THEN
      O_ERRORCODE := SQLCODE;
      O_ERRORMESG := SQLERRM;

END OP_INF_SEND_MAIL_ONE;
/
