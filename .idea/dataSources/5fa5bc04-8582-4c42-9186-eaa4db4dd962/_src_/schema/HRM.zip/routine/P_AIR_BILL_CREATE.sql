CREATE PROCEDURE     P_AIR_BILL_CREATE(
  I_C_CD            IN VARCHAR2,
  I_BILL_CD         IN VARCHAR2,      --전표구분코드
  I_BILL_SEQ_NO     IN VARCHAR2,      --전표번호
  I_MOD_USER_ID     IN VARCHAR2,
  O_ERRORCODE       OUT VARCHAR2,
  O_ERRORMESG       OUT VARCHAR2,
  O_BILL_SEQ_NO     OUT VARCHAR2
)
IS
/***********************************************************************
 Program Name   : P_AIR_BILL_CREATE
 Description    : 항공권 전표 발행 본지점
 Author         : 김영규
 History        : 2010-10-10
***********************************************************************/
  V_LOGIN_EMP_ID   VARCHAR(20);     -- 발행자사번
  V_BILL_SEQ_NO    NUMBER;          -- SLIPMASTER 고유번호
  V_ORG_GRP_CD     VARCHAR2(20);    -- 조직그룹코드
  V_ORG_ID_002     VARCHAR2(20);    -- 본부코드
  V_CONNECTIONCODE VARCHAR(10);     -- 거래처코드
  V_MON            NUMBER;          -- 계산된 금액
  V_C_MON_SUM      NUMBER:=0;            -- 대변합
  V_D_MON_SUM      NUMBER:=0;            -- 차변합
  V_RET_MSG        VARCHAR2(4000);      -- ERR MSG
  V_PER_NO         VARCHAR(13);
  V_EMP_ID         VARCHAR(20);
  V_EMP_NM         VARCHAR(20);
  
  R1 TB_SLIPDETAIL%ROWTYPE;
BEGIN


  /* 테스트 허용   
  IF PAY_R.CLOSE_YN <> 'Y'
  THEN
    RAISE_APPLICATION_ERROR( -20000, '급여가 마감되지 않았습니다.');
  END IF;   
*/    

  --발행자의 사번을 가져온다..
  SELECT EMP_ID
    INTO V_LOGIN_EMP_ID
    FROM SY4100#
   WHERE C_CD = I_C_CD
     AND USER_ID = I_MOD_USER_ID;
     --테스트용 임시..
    -- V_LOGIN_EMP_ID := '200901482';
/*
  --발행자회계부서를 가져온다.
  SELECT F_GET_CC_CD(I_C_CD, V_LOGIN_EMP_ID, TO_CHAR(SYSDATE, 'YYYYMMDD'))
    INTO V_BILL_CRE_EMP_CC_CD
    FROM DUAL;
    */
  /*
  --전표번호를 가져온다.(HRM에서만 인식용으로 사용.)
  SELECT SEQ_BILL_SEQ_NO.NEXTVAL
    INTO I_BILL_SEQ_NO
    FROM DUAL;
  */
 
  --삭제 후 재생성..
  IF I_BILL_SEQ_NO <> '0' THEN
      DELETE FROM TB_SLIPMASTER WHERE SLIPNO = I_BILL_SEQ_NO;
  END IF;
  
  --발행전표관리 테이블에 추가한다.
  INSERT INTO SY8030
  (
   BILL_SEQ_NO,
   SLIPNO
  )
  VALUES
  (
   I_BILL_SEQ_NO,
   0
  );
  
  
  DBMS_OUTPUT.PUT_LINE('전표 마스터 생성 ..START AT  '||I_BILL_SEQ_NO  ||'번호'|| F_SY_GET_FMT_TIME(NULL, NULL) || ', SQL%ROWCOUNT: ' || TO_CHAR(SQL%ROWCOUNT) );

  --전표 마스터를 생성한다. 
  INSERT INTO TB_SLIPMASTER
  (
    BILL_SEQ_NO,            -- 전표일련번호
    SLIPNO,                 -- 전표번호
    MASTERPROJECTCODE,      -- 프로젝트코드
    MASTERORGGROUPCODE,     -- 사업본부
    SLIPSTATUS,             -- 전표상태
    SLIPCANCELYN,           -- 전표취소여부
    SLIPINPUTSYSTEM,        -- 전표입력시스템
    SLIPTYPE,               -- 전표종류
    WRITEEMPNO,             -- 작성자사번
    WRITEDATE,              -- 작성일
    ACCOUNTMANAGEREMPNO,    -- 경리담당자사번   
    ACCOUNTMANAGERYN,       -- 경리담당자확인여부
    ACCOUNTSIGNERYN,        -- 경리결재자확인여부
    CHANGESLIPYN,           -- 대체전표여부
    FIRSTSEQNOOFDETAIL,     -- 상세최초순번
    FISCALDATE
  )
  SELECT I_BILL_SEQ_NO,        -- 표일련번호
         T1.SLIPNO,             --전표번호
         T1.MASTERPROJECTCODE,  --프로젝트코드
         T1.MASTERORGGROUPCODE, --사업본부
         T1.SLIPSTATUS,         --전표상태
         T1.SLIPCANCELYN,       --전표취소여부
         T1.SLIPINPUTSYSTEM,    --전표입력시스템
         T1.SLIPTYPE,           --전표종류
         V_LOGIN_EMP_ID,        --작성자사번
         REPLACE(TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD/HH24:MI:SS.FF3'),'/','T')||SESSIONTIMEZONE  WRITEDATE, --작성일 MSSQL TIMESTAMP 형태와 같도록..
         T1.ACCOUNTMANAGEREMPNO ACCOUNTMANAGEREMPNO,    -- 경리담당자사번  
         T1.ACCOUNTMANAGERYN,   --경리담당자확인여부
         T1.ACCOUNTSIGNERYN,    --경리결재자확인여부
         T1.CHANGESLIPYN,       --대체전표여부
         T1.FIRSTSEQNOOFDETAIL,  --상세최초순번
         TO_CHAR(SYSDATE,'YYYYMMDD')
    FROM SY8010 T1
   WHERE T1.C_CD = I_C_CD
     AND T1.BILL_CD = I_BILL_CD;
  
 DBMS_OUTPUT.PUT_LINE('전표 디테일 조회 ..START AT ' || F_SY_GET_FMT_TIME(NULL, NULL) || ', SQL%ROWCOUNT: ' || TO_CHAR(SQL%ROWCOUNT) );   
 FOR CUR1 IN(
      
         SELECT T1.SEQ_NO ,
                T1.ACCOUNTCODE ,    --계정과목코드
                T1.ACCOUNTNAME,     --계정과목명
                T1.DEBITCREDITTYPE, --차대구분
                T1.REG_CDS,         --사용코드
                T1.GRP_CLASS,       --그룹구분
                T1.SLIPNO,          --전표번호
                T1.ORGGROUPCODE,    --사업본부
                T1.PROJECTCODE,     --프로젝트코드
                NVL(T1.CONNECTIONCODE, ' ') CONNECTIONCODE,                                   --거래처코드
                T1.TRANSACTDESCRIPTION ,                       --거래내용
                NVL(T1.SETTLEMENTTYPE, ' ') SETTLEMENTTYPE,     --정산구분
                NVL(T1.SETTLEMENTSTATUS, ' ') SETTLEMENTSTATUS, --정산상태
                T1.CURRENCY,                                    --통화
                T1.EXCHANGERATE,                                --환율
                T1.FOREIGNCURRENCY,                             --외화
                T1.KOREACURRENCY,                               --원화
                REPLACE(T1.PERIODFROMFIELD, ':공백', ' ')  PERIODFROMFIELD ,                            --기간적요
                T1.LEDGERFIELD    ,                             --원장적요
                REPLACE(T1.OPTIONFIELD1, ':공백',' ') OPTIONFIELD1 ,  --추가적요
                REPLACE(T1.OPTIONFIELD2, ':공백',' ') OPTIONFIELD2 ,           --추가적요2
                T1.OPTIONFIELD3 ,           -- 추가적요3
                T1.REVERSEENTRYYN ,
                T1.ORDER_NO ,
                REPLACE(T1.EXPENSEITEMCD, ':공백',' ') EXPENSEITEMCD ,
                T1.TARGETACCOUNTCODE  ,
                PROGRESSID
           FROM SY8020 T1
          WHERE T1.C_CD    = I_C_CD
            AND T1.BILL_CD = 'BE08'
          ORDER BY
                T1.ORDER_NO
                
    )
  LOOP
     /****************************************************************
     본부별 지급 총액     
     *****************************************************************/ 
      IF CUR1.SEQ_NO  = '1' THEN
          FOR GROUP1 IN(
                    --  출국일 기준 본부로 전표 발행. 2012.02.08 김성관
                    SELECT F_ORG_NM (T2.C_CD,T2.BOARD_YMD,T4.ORG_ID,'6') ORG_ID3
                          ,T1.PROJECT_CD
                          ,NVL(SUM(AIR_APPL_MON),0) MON
                          ,T1.IN_APPR_NO
                          ,T2.BOARD_YMD
                      FROM BEQ100 T1,
                           BEQ010 T2,
                           PA1010# T3,
                           PA1020 T4
                     WHERE T1.C_CD    = I_C_CD
                       AND T1.BILL_NO = I_BILL_SEQ_NO
                       AND T1.C_CD = T2.C_CD
                       AND T1.IN_APPR_NO = T2.APPR_NO
                       AND T1.C_CD       = T3.C_CD
                       AND T2.EMP_ID     = T3.EMP_ID
                       AND T3.C_CD       = T4.C_CD
                       AND T3.EMP_ID     = T4.EMP_ID
                       AND T4.LAST_YN    = 'Y'
                       AND T2.BOARD_YMD BETWEEN T4.STA_YMD AND T4.END_YMD      
                       AND AIR_APPL_MON <> 0
                      GROUP BY T1.C_CD,T1.IN_APPR_NO,F_ORG_NM (T2.C_CD,T2.BOARD_YMD,T4.ORG_ID,'6') ,T1.PROJECT_CD,T2.BOARD_YMD
                      ORDER BY ORG_ID3 DESC             
/*          
                    SELECT T3.ORG_ID3
                          ,T1.PROJECT_CD
                          ,NVL(SUM(AIR_APPL_MON),0) MON
                          ,T1.IN_APPR_NO
                      FROM BEQ100 T1,
                           BEQ010 T2,
                           PA1020_V_1 T3
                     WHERE T1.C_CD    = I_C_CD
                       AND T1.BILL_NO = I_BILL_SEQ_NO
                       AND T1.C_CD = T2.C_CD
                       AND T1.IN_APPR_NO = T2.APPR_NO
                       AND T1.C_CD       = T3.C_CD
                       AND T2.EMP_ID     = T3.EMP_ID
                       AND AIR_APPL_MON <> 0
                      GROUP BY T1.C_CD,T1.IN_APPR_NO,T3.ORG_ID3 ,T1.PROJECT_CD 
                      ORDER BY T3.ORG_ID3 DESC
*/                      
          ) 
          LOOP
                 
              --SLIPDETAIL 순번
              SELECT NVL(MAX(SLIPSEQ_NO)+1, 1)
                INTO R1.SLIPSEQ_NO
                FROM TB_SLIPDETAIL 
               WHERE BILL_SEQ_NO = I_BILL_SEQ_NO;
                       
             -- 본부코드를 가져온다.(WK_SITE)
              SELECT SUBSTR(SUBSTR(WK_SITE,1,2), 1, 2) 
                INTO R1.ORGGROUPCODE
                FROM SY3010 
               WHERE C_CD = I_C_CD 
                 AND OBJ_TYPE = 'O' 
                 --AND TO_CHAR(SYSDATE,'YYYYMMDD') BETWEEN STA_YMD AND END_YMD
                 AND GROUP1.BOARD_YMD BETWEEN STA_YMD AND END_YMD
                 AND OBJ_ID = GROUP1.ORG_ID3;  
                 
            /*       
              -- 조직그룹을 가져온다.
              SELECT ORG_GRP_CD 
                INTO V_ORG_GRP_CD
                FROM OM0010 
               WHERE C_CD = I_C_CD 
                 AND ORG_ID = GROUP1.ORG_ID;       
              
                   
              -- 본부별 사업관리코드 가져온다.(본부의 프로젝트 코드를 가져옴..) 미정..
              SELECT CD_NM
                INTO R1.PROJECTCODE
                FROM SY5020 
               WHERE C_CD = I_C_CD
                 AND IDX_CD = 'SY340'
                 AND CD = R1.ORGGROUPCODE;
                             
              --거래처코드를 가져온다.
              SELECT F_PY_ORG_CONNECTIONCODE(I_C_CD,GROUP1.ORG_ID,'1',PAY_R.PAYROLL_YMD)
                INTO R1.CONNECTIONCODE  
                FROM DUAL;
            */
              -- 금액이 0이면 전표를 생성하지 않는다.
              IF GROUP1.MON <> 0 THEN
              /*
                IF V_ORG_GRP_CD =  '0030'THEN                  
                     R1.ACCOUNTCODE  :=  '364'; -- 0030 이면 지원   
                ELSE
                     R1.ACCOUNTCODE  :=  '256'; -- 매출     
                END IF; 
             */                       
                R1.SLIPNO              := CUR1.SLIPNO;                --전표번호
                R1.TRANSACTDESCRIPTION := CUR1.TRANSACTDESCRIPTION;   --거래내용
                R1.DEBITCREDITTYPE     := CUR1.DEBITCREDITTYPE;       --차대구분
                R1.SETTLEMENTTYPE      := CUR1.SETTLEMENTTYPE;        --정산구분
                R1.SETTLEMENTSTATUS    := CUR1.SETTLEMENTSTATUS;      --정산상태
                R1.ACCOUNTNAME         := CUR1.ACCOUNTNAME;     --계정과목코드명
                R1.CURRENCY            := CUR1.CURRENCY;        --통화
                R1.EXCHANGERATE        := CUR1.EXCHANGERATE;    --환율
                R1.FOREIGNCURRENCY     := CUR1.FOREIGNCURRENCY; --외화
                R1.KOREACURRENCY       := GROUP1.MON;           --원화
                R1.PERIODFROMFIELD     := CUR1.PERIODFROMFIELD; --기간적요
                R1.LEDGERFIELD         := CUR1.LEDGERFIELD;     --원장적요
                R1.OPTIONFIELD1        := CUR1.OPTIONFIELD1;    --추가적요1
                R1.OPTIONFIELD2        := CUR1.OPTIONFIELD2;    --추가적요2
                R1.OPTIONFIELD3        := CUR1.OPTIONFIELD3;    --추가적요3
                R1.REVERSEENTRYYN      := CUR1.REVERSEENTRYYN;  --
                R1.EXPENSEITEMCD       := CUR1.EXPENSEITEMCD;    --
                R1.TARGETACCOUNTCODE   := CUR1.TARGETACCOUNTCODE;  --
                R1.PROJECTCODE         := GROUP1.PROJECT_CD;       --
                R1.CONNECTIONCODE      := CUR1.CONNECTIONCODE;  --거례처코드
                R1.ACCOUNTCODE         := CUR1.ACCOUNTCODE;
                R1.ACCOUNTNAME         := ' ';
                       
                                 
                INSERT INTO TB_SLIPDETAIL
                (
                    BILL_SEQ_NO,
                    SLIPSEQ_NO,
                    ACCOUNTCODE,        --계정과목코드
                    DEBITCREDITTYPE,    --차대구분
                    SLIPNO,             --전표번호
                    ORGGROUPCODE,       --사업본부
                    PROJECTCODE,        --프로젝트코드
                    CONNECTIONCODE,     --거래처코드
                    TRANSACTDESCRIPTION,--거래내용
                    SETTLEMENTTYPE,     --정산구분
                    SETTLEMENTSTATUS,   --정산상태
                    CURRENCY,           --통화
                    EXCHANGERATE,       --환율
                    FOREIGNCURRENCY,    --외화
                    KOREACURRENCY,      --원화
                    PERIODFROMFIELD,    -- 기간적요
                    LEDGERFIELD,        --원장적요
                    OPTIONFIELD1,       --추가적요1
                    OPTIONFIELD2 ,      --추가적요2
                    OPTIONFIELD3 ,      -- 추가적요3
                    REVERSEENTRYYN ,
                    SLIPAUTOCREATEYN,
                    EXPENSEITEMCD ,
                    TARGETACCOUNTCODE ,
                    PROGRESSID ,
                    ACCOUNTNAME
                  )
                  VALUES
                  (
                    I_BILL_SEQ_NO,
                    R1.SLIPSEQ_NO,
                    R1.ACCOUNTCODE,
                    R1.DEBITCREDITTYPE,
                    R1.SLIPNO,
                    R1.ORGGROUPCODE,
                    R1.PROJECTCODE,
                    R1.CONNECTIONCODE,
                    R1.TRANSACTDESCRIPTION,
                    R1.SETTLEMENTTYPE,
                    R1.SETTLEMENTSTATUS,
                    R1.CURRENCY,
                    R1.EXCHANGERATE,
                    R1.FOREIGNCURRENCY,
                    R1.KOREACURRENCY,
                    R1.PERIODFROMFIELD,
                    R1.LEDGERFIELD,
                    R1.OPTIONFIELD1,        --추가적요1
                    R1.OPTIONFIELD2 ,       --추가적요2
                    R1.OPTIONFIELD3 ,       -- 추가적요3
                    R1.REVERSEENTRYYN ,
                    'false',
                    R1.EXPENSEITEMCD,
                    R1.TARGETACCOUNTCODE,
                    '0' ,
                    R1.ACCOUNTNAME
                  );  
                  
                  
                  INSERT INTO TB_SLIPDETAIL
                ( 
                    BILL_SEQ_NO,
                    SLIPSEQ_NO,
                    ACCOUNTCODE,
                    DEBITCREDITTYPE,    --차대구분
                    SLIPNO,             --전표번호
                    ORGGROUPCODE,       --사업본부
                    PROJECTCODE,        --프로젝트코드
                    CONNECTIONCODE,     --거래처코드
                    TRANSACTDESCRIPTION,--거래내용
                    CURRENCY,           --통화
                    EXCHANGERATE,       --환율
                    FOREIGNCURRENCY,    --외화
                    KOREACURRENCY,      --원화
                    OPTIONFIELD1,       --추가적요1
                    OPTIONFIELD2 ,      --추가적요2
                    REVERSEENTRYYN ,
                    SLIPAUTOCREATEYN,
                    EXPENSEITEMCD ,
                    TARGETACCOUNTCODE   ,
                    PROGRESSID,
                    ACCOUNTNAME               
                )      
                SELECT  I_BILL_SEQ_NO
                       ,ROWNUM+( SELECT NVL(MAX(SLIPSEQ_NO), 1)  FROM TB_SLIPDETAIL WHERE BILL_SEQ_NO = I_BILL_SEQ_NO ) SLIPSEQ_NO
                                   ,'608'      
                                   ,'D'  
                                   ,'1'
                       ,(     SELECT SUBSTR(SUBSTR(WK_SITE,1,2), 1, 2) 
                                FROM SY3010 
                               WHERE C_CD = I_C_CD
                                 AND OBJ_TYPE = 'O' AND OBJ_ID = F_ORG_NM (T2.C_CD,T2.BOARD_YMD,T4.ORG_ID,'6')  
                                 AND T2.BOARD_YMD BETWEEN STA_YMD AND END_YMD ) ORGGROUPCODE
                       ,T1.PROJECT_CD                   --프로젝트코드
                       ,'0000028708'                                                            CONNECTIONCODE     --거래처코드      
                       ,'Aircraft Ticket Fee('|| T3.ENG_EMP_NM ||')'                            TRANSACTDESCRIPTION   --거례내용
                       ,'WON'                   CURRENCY
                       ,0                       EXCHANGERATE       --환율
                       ,0                       FOREIGNCURRENCY    --외화
                       ,NVL(AIR_APPL_MON,0)     KOREACURRENCY      --원화
                       ,' '                     OPTIONFIELD1       --추가적요1
                       ,' '                     OPTIONFIELD2       --추가적요2
                       ,'false'                       REVERSEENTRYYN
                       ,'false'                          SLIPAUTOCREATEYN
                       ,'10710'                 EXPENSEITEMCD 
                       ,'288'                   TARGETACCOUNTCODE
                       ,'0' PROGRESSID
                       ,' ' ACCOUNTNAME
                  FROM BEQ100 T1,
                       BEQ010 T2,
                       PA1010# T3,
                       PA1020 T4
                 WHERE T1.C_CD    = I_C_CD
                   AND T1.BILL_NO = I_BILL_SEQ_NO
                   AND T2.APPR_NO = GROUP1.IN_APPR_NO
                   AND T1.C_CD = T2.C_CD
                   AND T1.IN_APPR_NO = T2.APPR_NO
                   AND T1.C_CD       = T3.C_CD
                   AND T2.EMP_ID     = T3.EMP_ID
                   AND T1.C_CD       = T4.C_CD
                   AND T3.EMP_ID     = T4.EMP_ID
                   AND T4.LAST_YN    = 'Y'
                   AND T2.BOARD_YMD BETWEEN T4.STA_YMD AND T4.END_YMD
                   AND F_ORG_NM (T2.C_CD,T2.BOARD_YMD,T4.ORG_ID,'6') = GROUP1.ORG_ID3
                   AND AIR_APPL_MON <> 0;
                  
              END IF;   
                         
          END LOOP; 
          
      END IF;
              
  END LOOP;
         
  --증빙 테이블을 생성한다.
  INSERT INTO TB_EVIDENCE#
  (
    BILL_SEQ_NO,    -- 전표일련번호
    SLIPNO,         --전표번호
    EVIDENCECODE ,   --증빙코드
    EVIDENCEDATE,
    CREDITCARDNO
  )
  SELECT I_BILL_SEQ_NO, -- 전표일련번호
         T1.SLIPNO,      --전표번호
         T1.EVIDENCECODE, --증빙코드
         TO_CHAR(SYSDATE,'YYYYMMDD') ,
         0
    FROM SY8010 T1
   WHERE T1.C_CD = I_C_CD
     AND T1.BILL_CD = I_BILL_CD;
    
  -- 전표 공통 VALIDATION CHECK
  V_RET_MSG := F_BILL_VALIDATION(I_C_CD, I_BILL_SEQ_NO);
  IF V_RET_MSG IS NOT NULL
  THEN
    RAISE_APPLICATION_ERROR( -20000, V_RET_MSG);
  END IF;
      
  O_ERRORCODE := '0';
  O_BILL_SEQ_NO := I_BILL_SEQ_NO;
--COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    O_ERRORCODE := SQLCODE;
    O_ERRORMESG := SQLERRM;
END;
/
