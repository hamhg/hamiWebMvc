CREATE PROCEDURE     P_BE_COPY_BEP200
(
    I_C_CD      IN VARCHAR2,
    I_SRC_YY    IN VARCHAR2, -- 복사원본 연도
    I_TRG_YY    IN VARCHAR2, -- 복사대상 연도
    O_ERRORCODE OUT VARCHAR2,
    O_ERRORMESG OUT VARCHAR2
) IS
    V_ERRORCODE VARCHAR2(1000);
    V_ERRORMESG VARCHAR2(1000);
    V_ERR_CNT   NUMBER := 0;
    V_CNT       NUMBER;
BEGIN

    -- 복사원본년도의 데이터를 양/음력 구분하여 조회(퇴직자 필터링 됨)
    FOR C IN (
              SELECT T1.*
                FROM (
                      SELECT T1.*
                            ,I_TRG_YY || SUBSTR(T1.BIRTH_YMD, 5, 4) SOLAR_YMD -- 복사대상년도의 양력환산 생일
                        FROM BEP200#     T1
                       WHERE T1.C_CD = I_C_CD
                         AND T1.YYYY = I_SRC_YY  -- 원본년도이고..
                         AND T1.SOLAR_LUNAR_CLASS = '+' -- 양력 생일자인경우
                      UNION ALL
                      SELECT T1.*
                            ,CASE WHEN T3.SOLAR_YMD IS NOT NULL THEN T3.SOLAR_YMD 
                                  ELSE (SELECT MAX(SOLAR_YMD)
                                          FROM TMP_CALENDAR
                                         WHERE LUNAR_YMD < I_TRG_YY || SUBSTR(T1.BIRTH_YMD, 5, 4)
                                           AND INTER_MM_YN = 'N') END SOLAR_YMD  -- 복사대상년도의 양력환산 생일
                        FROM BEP200#       T1
                            ,TMP_CALENDAR T3
                       WHERE T1.SOLAR_LUNAR_CLASS = '-' -- 음력 생일자인경우
                         AND T1.YYYY = I_SRC_YY  -- 원본년도이고..
                         AND I_TRG_YY || SUBSTR(T1.BIRTH_YMD, 5, 4) = T3.LUNAR_YMD(+)
                         AND INTER_MM_YN(+) = 'N'  -- 평달로만.. 윤달까지는 모르겠음
                     ) T1 -- 원본년도 생신선물 신청데이터
                    ,PA1020_V_1 T2
               WHERE 1 = 1 
                 AND T2.C_CD = I_C_CD
                 AND T2.EMP_ID = T1.EMP_ID
                 AND T2.RETIRE_YMD IS NULL -- 퇴직일 없고   
                 --AND T2.EMP_TYPE IN ('A', 'B', 'C', 'D', 'G', 'O') -- 직원구분 조건이고..
                 AND T2.EMP_TYPE NOT IN ('P', '8', '8H', '8P') -- 직원구분 조건이고..
                 AND NVL(T2.PAY_CALC_EXEC_YN, 'N') = 'N' -- 급여지급 제외자 아니고..
                 AND NOT EXISTS (
                                 SELECT 1
                                   FROM GAIS.BEA220# S1
                                  WHERE S1.C_CD = I_C_CD
                                    AND S1.EMP_ID = T1.EMP_ID
                                    AND S1.CON_TYPE = '140' -- 경조유형 사망 
                                    AND S1.PER_NO = T1.FAM_PER_NO -- 주민번호있고..
                                 )  -- 경공조관리에 사망 신청건 없고..
                 AND NOT EXISTS (
                                 SELECT 1
                                   FROM BEP200# S1
                                  WHERE S1.C_CD = I_C_CD
                                    AND S1.YYYY = I_TRG_YY  -- 대상년도이고..
                                    AND S1.EMP_ID = T1.EMP_ID
                                    AND S1.FAM_PER_NO = T1.FAM_PER_NO -- 주민번호같고..
                                 )  -- 대상년도에 신청데이터 있는 건은 제외
                ORDER BY T2.EMP_ID
                        ,T1.SOLAR_YMD
             )   
    LOOP  
    
      -- BEP200 INSERT
      BEGIN
        INSERT INTO BEP200#
        VALUES(I_C_CD
              ,C.EMP_ID
              ,C.FAM_PER_NO
              ,I_TRG_YY
              ,I_TRG_YY || SUBSTR(C.BIRTH_YMD, 5, 4)  -- CR_BIRTH_YMD
              ,C.BIRTH_YMD
              ,C.SOLAR_LUNAR_CLASS
              ,C.ZIP_NO
              ,C.ADDR_BASE
              ,C.ADDR_DTL
              ,C.TEL_NO
              ,C.MOBILE_NO
              ,C.GFT_CD
              ,'N'
              ,C.PARC_MESSAGE
              ,C.DEATH_YN
              ,C.SOLAR_YMD  -- SOLAR_CNVT_YMD
              ,C.MAIL_SEND_YN
              ,NULL   -- PAY_YMD
              ,NULL -- BILL_SEQ_NO
              ,C.ACCOUNT_ID
              ,C.FAM_NM
              ,C.FAM_CD
              ,C.NOTE
              ,'SYSTEM'
              ,SYSDATE
              ,'SYSTEM'
              ,SYSDATE);
              
          DBMS_OUTPUT.PUT_LINE(C.EMP_ID || ', ' || C.FAM_PER_NO || ', ' || C.SOLAR_YMD);
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          V_ERR_CNT := V_ERR_CNT + 1;
          
          -- 윤달문제인지 체크
          SELECT COUNT(*)
            INTO V_CNT
            FROM TMP_CALENDAR
           WHERE LUNAR_YMD = I_TRG_YY || SUBSTR(C.BIRTH_YMD, 5, 4);
          
          DBMS_OUTPUT.PUT_LINE('중복키입력 : ' || C.EMP_ID || ', ' || C.FAM_PER_NO || ', ' || C.SOLAR_YMD || ', 음력일수:' || V_CNT);
      END;
    
    END LOOP;

    O_ERRORCODE := '0';   
    O_ERRORMESG := V_ERR_CNT || '건 오류발생';

EXCEPTION
    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE;
        O_ERRORMESG := SQLERRM;
END P_BE_COPY_BEP200;
/
