CREATE PROCEDURE     P_BE_BE2080_SAVE01
(
    I_C_CD              IN VARCHAR2,
    I_IUD               IN VARCHAR2,
    I_EMP_ID            IN VARCHAR2,
    I_SINS_TYPE         IN VARCHAR2,
    I_ORGN_YM           IN VARCHAR2,
    I_PAY_YM            IN VARCHAR2,
    I_PAYROLL_TYPE      IN VARCHAR2,
    
    I_EMP_TYPE          IN VARCHAR2,
    I_RSN_TYPE          IN VARCHAR2,
    I_RSN_CD            IN VARCHAR2,
    I_PSN_MON           IN NUMBER,
    I_COM_MON           IN NUMBER,
    I_OINS_MON          IN NUMBER,
    I_HEALTH_INT_MON    IN NUMBER,
    I_OINS_INT_MON      IN NUMBER,
    I_FUNC_MON          IN NUMBER,
    I_YA_HEALTH_MON     IN NUMBER, --연말정산 건강보험 추가 20150609 김형준
    I_YA_OINS_MON       IN NUMBER, --연말정산 건강보험 추가 20150609 김형준
    I_YA_COM_HEALTH_MON IN NUMBER, --연말정산 건강보험 추가 20150609 김형준
    I_YA_COM_OINS_MON   IN NUMBER, --연말정산 건강보험 추가 20150609 김형준
    I_ETC_YN            IN VARCHAR2,
    I_NOTE              IN VARCHAR2,
    
    I_MOD_USER_ID       IN VARCHAR2,
    O_ERRORCODE         OUT VARCHAR2,
    O_ERRORMESG         OUT VARCHAR2
)
IS
/***********************************************************************
  Program Name  : P_BE_BE2080_SAVE01
  Description   : 사회보험 미공제금액 저장
  Author        : 김성관
  History       : 2014-06-20 신규개발
***********************************************************************/
    V_CLOSE_YN VARCHAR2(1);
    V_EMP_ID   VARCHAR2(20);

BEGIN



    -- 공제월 급여 마감여부 체크
    BEGIN
        SELECT NVL(CLOSE_YN,'N')
          INTO V_CLOSE_YN
          FROM PY0300
         WHERE C_CD = I_C_CD
           AND PAY_YM = I_PAY_YM
           AND PAYROLL_TYPE = I_PAYROLL_TYPE;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            V_CLOSE_YN := 'N';
        WHEN OTHERS THEN
            O_ERRORCODE := SQLCODE;
            O_ERRORMESG := SQLERRM;
    END;            
                       

    IF V_CLOSE_YN = 'Y' THEN
        RAISE_APPLICATION_ERROR(-20000, '급여 마감된 월에 공제건이 존재하여 저장할 수 없습니다.');
    END IF;
    
    -- 사번조회
    BEGIN
        SELECT EMP_ID
          INTO V_EMP_ID
          FROM PA1010#
         WHERE C_CD = I_C_CD
           AND ( EMP_ID = I_EMP_ID
              OR SUBSTR(EMP_ID, 3, 7) = I_EMP_ID
              );
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            O_ERRORMESG := '사번이 존재하지 않습니다.('||I_EMP_ID||') : '||SQLERRM;
        WHEN OTHERS THEN
            O_ERRORCODE := SQLCODE;
            O_ERRORMESG := SQLERRM;
    END;            


    -- IUD에 따른 저장처리
    IF I_IUD = 'I' THEN

dbms_output.put_line('---- 입력 쿼리 키------');
dbms_output.put_line('C_CD : '||I_C_CD);
dbms_output.put_line('EMP_ID : '||I_EMP_ID);
dbms_output.put_line('SINS_TYPE : '||I_SINS_TYPE);
dbms_output.put_line('ORGN_YM : '||I_ORGN_YM);
dbms_output.put_line('----------------------');     
        INSERT INTO BE2080(C_CD
                         , EMP_ID
                         , SINS_TYPE
                         , ORGN_YM
                         , PAY_YM
                         , PAYROLL_TYPE
                         , EMP_TYPE
                         , RSN_TYPE
                         , RSN_CD
                         , PSN_MON
                         , COM_MON
                         , OINS_MON
                         , HEALTH_INT_MON
                         , OINS_INT_MON
                         , FUNC_MON
                         , YA_HEALTH_MON
                         , YA_OINS_MON
                         , YA_COM_HEALTH_MON
                         , YA_COM_OINS_MON
                         , ETC_YN
                         , NOTE
                         , INS_USER_ID
                         , INS_YMDHMS
                         , MOD_USER_ID
                         , MOD_YMDHMS
                         )
                   VALUES
                          (I_C_CD
                         , V_EMP_ID
                         , I_SINS_TYPE
                         , I_ORGN_YM
                         , I_PAY_YM
                         , I_PAYROLL_TYPE
                         , I_EMP_TYPE
                         , I_RSN_TYPE
                         , I_RSN_CD
                         , I_PSN_MON
                         , I_COM_MON
                         , I_OINS_MON
                         , I_HEALTH_INT_MON
                         , I_OINS_INT_MON
                         , I_FUNC_MON
                         , I_YA_HEALTH_MON    
                         , I_YA_OINS_MON      
                         , I_YA_COM_HEALTH_MON
                         , I_YA_COM_OINS_MON  
                         , I_ETC_YN
                         , I_NOTE
                         , I_MOD_USER_ID
                         , SYSDATE
                         , I_MOD_USER_ID
                         , SYSDATE
                         );

    ELSIF I_IUD = 'U' THEN
    
        UPDATE BE2080
           SET PAY_YM               = I_PAY_YM
             , PAYROLL_TYPE         = I_PAYROLL_TYPE
             , EMP_TYPE             = I_EMP_TYPE
             , RSN_TYPE             = I_RSN_TYPE
             , RSN_CD               = I_RSN_CD
             , PSN_MON              = I_PSN_MON
             , COM_MON              = I_COM_MON
             , OINS_MON             = I_OINS_MON
             , HEALTH_INT_MON       = I_HEALTH_INT_MON
             , OINS_INT_MON         = I_OINS_INT_MON
             , FUNC_MON             = I_FUNC_MON
             , ETC_YN               = I_ETC_YN
             , YA_HEALTH_MON        = I_YA_HEALTH_MON
             , YA_OINS_MON          = I_YA_OINS_MON
             , YA_COM_HEALTH_MON    = I_YA_COM_HEALTH_MON
             , YA_COM_OINS_MON      = I_YA_COM_OINS_MON
             , NOTE                 = I_NOTE
             , MOD_USER_ID          = I_MOD_USER_ID
             , MOD_YMDHMS           = SYSDATE
         WHERE C_CD = I_C_CD
           AND EMP_ID = V_EMP_ID
           AND SINS_TYPE = I_SINS_TYPE
           AND ORGN_YM = I_ORGN_YM;        

    ELSIF I_IUD = 'D' THEN
    
        DELETE BE2080
         WHERE C_CD = I_C_CD
           AND EMP_ID = V_EMP_ID
           AND SINS_TYPE = I_SINS_TYPE
           AND ORGN_YM = I_ORGN_YM;                

    END IF;
    

    O_ERRORCODE := '0';
    O_ERRORMESG := '성공';
    
EXCEPTION

    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE;
        O_ERRORMESG := SQLERRM;

END;
/
