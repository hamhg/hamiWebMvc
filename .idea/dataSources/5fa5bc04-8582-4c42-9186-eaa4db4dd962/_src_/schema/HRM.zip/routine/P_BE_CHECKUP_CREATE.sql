CREATE PROCEDURE     P_BE_CHECKUP_CREATE
(
    I_C_CD        IN VARCHAR2, --회사코드      
    I_YY          IN VARCHAR2,
    I_YMD         IN VARCHAR2, --생성일
    I_MOD_USER_ID IN VARCHAR2,
    O_ERRORCODE   OUT VARCHAR2,
    O_ERRORMESG   OUT VARCHAR2
) IS
    /***********************************************************************
     Program Name   : P_BE_CHECKUP_CREATE
     Description    : 건강검진대상자 생성
                           1.당해년도 입사자는 채용신체검사로 대체하기 때문에 대상자에서 제외된다.
                           2.기준정보 중에서 해외근무직원(대상자생성일당시 해외지사,해외현장근무직원의 경우), 배우자의 경우 과장급 이상은 A그룹으로 포함된다.
                               해외지사라 함은  근무지구분이 해외지지점을 해외현장은 근무지 구분이 해외현장을 이야기 함
                           3.기준정보의 B그룹중에서 대리이하직원(전임포함)은 만 40세 이상 본인 ,배우자
                              그리고 대리이하(전임포함) 은 (만 39세,만37세,만35세) 에 해당하면 B그룹으로 처리하며 이때는 배우자를 생성하지 않는다..
                           4. A,B그룹은 모두 희망신청을 할 수 있으며 위 1,2,3항에 해당하지 않는 사람들도 희망신청을 할 수 있다(이때 회사는 50%를 지원)
                           5.종합검진은 1년에 한 사람당 한번만 실시 할 수 있다.
                           1. 직위 코드 
    
    
     Author         :  김성관
     History        : 2015-01-06 임원대상그룹 조정 등으로 로직 수정 개발. 김성관
    ***********************************************************************/
    V_BEH200_EXISTS_YN VARCHAR2(1);  -- 검진대상자 데이터 존재여부
    V_BEH210_EXISTS_YN VARCHAR2(1);  -- 검진신청 데이터 존재여부
    V_OLD_TRG_GRP_CD VARCHAR2(20); -- 기존 대상자 그룹
BEGIN
    O_ERRORCODE := '0';

             
                 
    -- 기준일 기준 건강검진 대상자 loop
    -- 기준년도 입사자 제외
    -- 재직자만
    -- 비상근자 제외(PA2260.WORK_CLASS = 'N' -- 비상근 )
    -- 건강검진 신청 데이터 있으면 변경하지 않음
    FOR C IN (
              SELECT SUBSTR(T1.GROUP_CD, 1, 3) AS TRG_GRP_CD                                        --대상그룹코드
                    ,T1.EMP_ID
                    ,(CASE WHEN T3.NO = 1 THEN '001' ELSE T1.FAM_CD END) AS FAM_CD                  --가족관계코드
                    ,(CASE WHEN T3.NO = 1 THEN T1.PER_NO ELSE T1.FAM_PER_NO END) AS FAM_PER_NO      --가족주민번호
                    ,(CASE WHEN T3.NO = 1 THEN T1.EMP_NM ELSE T1.FAM_NM END) AS FAM_NM              --가족성명
                    ,I_YMD AS CRE_YMD
                FROM (
                      SELECT T1.GROUP_CD
                            ,T1.EMP_ID
                            ,T2.FAM_CD
                            ,T1.PER_NO
                            ,T2.PER_NO AS FAM_PER_NO
                            ,T2.EMP_ID AS EMP_ID2
                            ,T1.EMP_NM
                            ,T2.FAM_NM
                        FROM (
                              SELECT F_BE_CHECKUP_GRP_VALUE(T1.C_CD, I_YY, I_YMD, T1.EMP_ID, T2.POST_CD, '1') AS GROUP_CD   -- 대상자 그룹조회 함수로 일원화하여 조회
                                    ,T2.WORK_LOC_ID
                                    ,T1.EMP_NM
                                    ,T1.PER_NO
                                    ,T1.EMP_ID
                                    ,NVL(T4.WORK_CLASS, 'Y') AS WORK_CLASS   -- 비상근여부
                                FROM PA1010# T1
                                    ,PA1020 T2
                                    ,OM3010 T3
                                    ,PA2260 T4  -- 인사기본_기타(비상근여부 조회용, 사원별로 데이터가 없는 경우 많으므로 OUTJOIN 처리할 것)
                               WHERE T1.C_CD = I_C_CD
                                 AND T1.GRP_YMD < I_YY || '0101'  -- 기준년도 입사자 제외
                                 AND T1.STAT_CD LIKE '1%'  -- 재직중이고..
                                 AND T2.C_CD = T1.C_CD
                                 AND T2.EMP_ID = T1.EMP_ID
                                 AND I_YMD BETWEEN T2.STA_YMD AND T2.END_YMD  -- 기준일자로..
                                 AND T2.LAST_YN = 'Y'
                                 ----------------------------------------------------------------------------------------------------
                                 AND T2.EMP_TYPE NOT IN ('O','8','8P','8H','P')   -- 직군체계 개편으로, 운영직, 전임직, PJT,PJT2 추가 2014.08.24 김성관
                                 AND T1.FOREIGN_YN <> 'Y'                               -- 외국인 직원은 대상자 제외. 직군 체계 개편으로 처리기준 변경. 2014.08.24 김성관  
                                 ----------------------------------------------------------------------------------------------------
                                 AND T3.C_CD = I_C_CD
                                 AND T3.WORK_LOC_ID = T2.WORK_LOC_ID   -- 발령근무지ID, 타사직원들 외에는 모두 WORK_LOC_ID 있음
                                 --
                                 AND T4.C_CD(+) = T1.C_CD
                                 AND T4.EMP_ID(+) = T1.EMP_ID
                             ) T1
                            ,PA2030# T2  -- 가족
                       WHERE 1 = 1
                         AND T1.WORK_CLASS = 'Y'   -- 비상근 제외
                         AND T2.C_CD(+) = I_C_CD
                         AND T2.EMP_ID(+) = T1.EMP_ID 
                         AND NVL(T2.DEATH_YN(+), 'N') = 'N'
                         AND T2.FAM_CD(+) IN ('002', '003')  -- 처, 남편
                         AND T2.USE_YN(+) = 'Y'
                     ) T1
                    ,COPY_T T3  -- NO 따기 위해
               WHERE T1.GROUP_CD IS NOT NULL
                 AND T3.NO BETWEEN 1 AND (CASE WHEN T1.GROUP_CD IN ('010', '011') THEN 1 
                                               WHEN T1.EMP_ID2 IS NOT NULL THEN 2 ELSE 1 END)   -- 010, 011 배우자 생성안하도록
             )
    LOOP
        BEGIN
            
            --  해당 사원의 건강검진신청 여부 조회
            SELECT CASE WHEN EXISTS (
                                     SELECT 1
                                       FROM GAIS.BEH210#  -- 건강검진신청
                                      WHERE C_CD = I_C_CD
                                        AND YY = I_YY
                                        AND EMP_ID = C.EMP_ID
                                        AND FAM_CD = C.FAM_CD
                                    ) THEN 'Y' ELSE 'N' END AS V_BEH210_EXISTS_YN  -- 직원/가족의 검진신청 데이터 여부
              INTO V_BEH210_EXISTS_YN
              FROM DUAL;  
            -- 신청데이터가 있다면 PASS
            IF V_BEH210_EXISTS_YN = 'Y' THEN
                CONTINUE;
            END IF;
            
            --  해당 사원의 건강검진대상자 조회
            BEGIN
             SELECT 'Y' AS V_BEH200_EXISTS_YN
                   ,TRG_GRP_CD
               INTO V_BEH200_EXISTS_YN 
                   ,V_OLD_TRG_GRP_CD
               FROM GAIS.BEH200#                 -- 건강검진대상자 
              WHERE C_CD = I_C_CD
                AND YY = I_YY
                AND EMP_ID = C.EMP_ID
                AND FAM_CD = C.FAM_CD
              ;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                V_BEH200_EXISTS_YN := 'N';
                V_OLD_TRG_GRP_CD := 'XXX';
            END;
            
            -- 대상자 데이터 존재하고, 기존 대상자그룹이 A그룹(BE590, 001)인데, 현시점 기준 대상자그룹이 B그룹 이라면.. PASS
            -- A그룹에서 B그룹으로의 변경은 없음
            -- 임원이 직원이 된다거나 등등 이상한 CASE 는 고려안함..
            IF V_BEH200_EXISTS_YN = 'Y' AND V_OLD_TRG_GRP_CD IN ('001', '009', '010') AND C.TRG_GRP_CD IN ('002', '011') THEN  
               CONTINUE;
            END IF;
            
            -- 대상자 데이터 존재한다면 DELETE
            IF V_BEH200_EXISTS_YN = 'Y' THEN  

                DELETE FROM GAIS.BEH200#
                 WHERE C_CD = I_C_CD        --회사코드             
                   AND YY = I_YY            --년도
                   AND EMP_ID = C.EMP_ID    --사번
                   AND FAM_CD = C.FAM_CD    --가족관계코드
                ;
            END IF;
            
            INSERT INTO GAIS.BEH200# T1
                (C_CD,              --회사코드             
                 YY,                --년도             
                 TRG_GRP_CD,        --대상그룹코드                
                 EMP_ID,            --사번                
                 FAM_CD,            --가족관계코드             
                 FAM_PER_NO,        --가족주민번호                
                 HOSPITAL_CD,       --병원코드                
                 FAM_NM,            --가족성명             
                 NOTE,              --비고            
                 CRE_YMD,           --생성일
                 INS_USER_ID,       --입력자ID              
                 INS_YMDHMS,        --입력일시                
                 MOD_USER_ID,       --작업자ID               
                 MOD_YMDHMS         --수정일시                
                 )
            VALUES
                (I_C_CD,            --회사코드             
                 I_YY,              --년도             
                 C.TRG_GRP_CD,      --대상그룹코드                
                 C.EMP_ID,          --사번                
                 C.FAM_CD,          --가족관계코드             
                 C.FAM_PER_NO,      --가족주민번호                
                 NULL,              --병원코드                
                 C.FAM_NM,          --가족성명             
                 (CASE WHEN V_BEH200_EXISTS_YN = 'Y' AND V_OLD_TRG_GRP_CD <> C.TRG_GRP_CD THEN TO_CHAR(TO_DATE(I_YMD, 'YYYYMMDD'), 'YYYY/MM/DD') || '대상자그룹변경' 
                       WHEN V_BEH200_EXISTS_YN = 'N' THEN TO_CHAR(TO_DATE(I_YMD, 'YYYYMMDD'), 'YYYY/MM/DD') || '신규생성'
                   END),            --비고, 대상자 존재했었고, 대상자그룹변경된 경우
                 C.CRE_YMD,         --생성일
                 I_MOD_USER_ID,     --입력자ID              
                 SYSDATE,           --입력일시                
                 I_MOD_USER_ID,     --작업자ID               
                 SYSDATE            --수정일시                
                 );
            
            
        EXCEPTION
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20000, SQLERRM || ', 사번:' || C.EMP_ID);
        END;
    
    END LOOP;

    O_ERRORCODE := '0';
    O_ERRORMESG := '성공';
EXCEPTION
    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE;
        O_ERRORMESG := SQLERRM;
END;
/
