CREATE PROCEDURE P_BE_COPY_BEP240
(
    I_C_CD      IN VARCHAR2,
    I_SRC_YY    IN VARCHAR2, -- 복사원본 연도
    I_TRG_YY    IN VARCHAR2, -- 복사대상 연도
    O_ERRORCODE OUT VARCHAR2,
    O_ERRORMESG OUT VARCHAR2
) IS
    V_ERRORCODE VARCHAR2(1000);
    V_ERRORMESG VARCHAR2(1000);
    V_ERR_CNT   NUMBER := 0;
    V_CNT       NUMBER := 0;
BEGIN

    -- 복사원본년도의 데이터 조회
    FOR C IN (
              SELECT T1.*
                    /*,case when exists (
                                        select 1
                                          from pa2030 s1
                                          where s1.c_cd = t2.c_cd
                                          and s1.emp_id = t2.emp_id
                                          and s1.fam_cd in ('002', '003')  -- 남편, 처
                                          and s1.use_yn = 'Y'   -- 사용중인 배우자
                                       ) then 'Y' ELSE 'N' END AS MARRY_YN  -- 사용중인 배우자 있다면 Y*/  -- 2012.12.13 이보영 요청, 인사기본 결혼여부로..
                    ,T2.MARRY_YN
                    ,T2.MARRY_YMD AS PA1010_MARRY_YMD
                    ,T2.BIRTH_YMD AS PA1010_BIRTH_YMD
                FROM BEP240     T1
                    ,PA1020_V_1 T2
               WHERE 1 = 1 
                 AND T1.C_CD = I_C_CD
                 AND T1.YYYY = I_SRC_YY  -- 원본년도이고..
                 AND T2.C_CD = T1.C_CD
                 AND T2.EMP_ID = T1.EMP_ID
                 AND T2.RETIRE_YMD IS NULL -- 퇴직일 없고   
                 --AND T2.EMP_TYPE IN ('A', 'B', 'C', 'D', 'G', 'O') -- 직원구분 조건이고..
                 AND T2.EMP_TYPE NOT IN ('P', '8', '8H', '8P') -- 프로젝트전문직 추가 작업. 2012.07.31 김성관
                 AND NVL(T2.PAY_CALC_EXEC_YN, 'N') = 'N' -- 급여지급 제외자 아니고..
                 AND NOT EXISTS (
                                 SELECT 1
                                   FROM BEP240 S1
                                  WHERE S1.C_CD = I_C_CD
                                    AND S1.YYYY = I_TRG_YY  -- 대상년도이고..
                                    AND S1.EMP_ID = T1.EMP_ID
                                 )  -- 대상년도에 신청데이터 있는 건은 제외
             )   
    LOOP  
    
      -- BEP240 INSERT
      BEGIN
        INSERT INTO BEP240
        VALUES(I_C_CD            -- C_CD
              ,I_TRG_YY            -- YYYY
              ,C.EMP_ID          -- EMP_ID
              ,DECODE(C.MARRY_YN, 'Y', '1', '2')  -- WED_APPL_CD, 기혼여부에 따라
              ,C.ANNIV_YMD      -- ANNIV_YMD, 어차피 NULL 임
              ,DECODE(C.MARRY_YN, 'Y', '1', C.LNS_TYPE)        -- LNS_TYPE, 0 음, 1양  결혼기념일이면 무조건 양력
              ,C.ZIP_CODE        -- ZIP_CODE
              ,C.ADDR            -- ADDR
              ,C.DTL_ADDR        -- DTL_ADDR
              ,C.WORK_LOC_TEL_NO -- WORK_LOC_TEL_NO
              ,C.TEL_NO          -- TEL_NO
              ,C.MOBILE_NO       -- MOBILE_NO
              ,C.TAEBE_TXT       -- TAEBE_TXT
              ,'N'       -- SUPPLY_YN
              ,C.NOTE            -- NOTE
              ,'SYSTEM'
              ,SYSDATE
              ,'SYSTEM'
              ,SYSDATE
              ,NULL         -- PAY_YMD
              ,C.PA1010_MARRY_YMD   -- wedding_ymd 
              ,C.PA1010_BIRTH_YMD   -- BIRTH_YMD
              );
          
          V_CNT := V_CNT + 1;
          --DBMS_OUTPUT.PUT_LINE(C.EMP_ID);
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          V_ERR_CNT := V_ERR_CNT + 1;
          DBMS_OUTPUT.PUT_LINE('중복키입력 : ' || C.EMP_ID);
      END;
    
    END LOOP;

    O_ERRORCODE := '0';   
    O_ERRORMESG := V_CNT || '건 등록, ' || V_ERR_CNT || '건 오류발생';

EXCEPTION
    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE;
        O_ERRORMESG := SQLERRM;
END P_BE_COPY_BEP240;

/
