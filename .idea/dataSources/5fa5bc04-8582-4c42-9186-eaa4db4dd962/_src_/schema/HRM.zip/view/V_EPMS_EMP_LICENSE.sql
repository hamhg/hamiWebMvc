CREATE VIEW V_EPMS_EMP_LICENSE AS SELECT A.C_CD,
          A.EMP_ID,
          A.CERT_CD,
          B.CD_NM,
          A.STA_YMD
     FROM PA2040 A, SY5020 B
    WHERE     A.EMP_ID IN (SELECT EMP_ID FROM V_EPMS_EMP)
          AND A.C_CD = B.C_CD
          AND A.CERT_CD = B.CD
          AND A.C_CD = 'HEC'
          AND B.IDX_CD = '01020'
          AND (A.C_CD, A.EMP_ID, A.CERT_CD, A.STA_YMD) IN (   SELECT C_CD, EMP_ID, CERT_CD, MAX(STA_YMD)
                                                                FROM PA2040
                                                               GROUP BY C_CD, EMP_ID, CERT_CD, STA_YMD
                                                           )
/
COMMENT ON VIEW V_EPMS_EMP_LICENSE IS '자격정보'
/
COMMENT ON COLUMN V_EPMS_EMP_LICENSE.C_CD IS '회사코드'
/
COMMENT ON COLUMN V_EPMS_EMP_LICENSE.EMP_ID IS '사번'
/
COMMENT ON COLUMN V_EPMS_EMP_LICENSE.CERT_CD IS '자격코드'
/
COMMENT ON COLUMN V_EPMS_EMP_LICENSE.CERT_NM IS '자격명'
/
COMMENT ON COLUMN V_EPMS_EMP_LICENSE.STA_YMD IS '취득일'
/
