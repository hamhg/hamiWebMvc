CREATE VIEW PY2360_V_NO_RETRO AS SELECT   A.C_CD,
              A.PAYROLL_NO,
              A.EMP_ID,
              A.PAYITEM,
              MAX (B.CD_NM) AS PAYITEM_NM,
              SUM (LAST_MON) AS LAST_MON,
              MAX (C.PAYITEM_TYPE) AS PAYITEM_TYPE,
              MAX (C.ORDER_NO) AS ORDER_NO
       FROM   PY2360 A, SY5020 B, PY0100 C
      WHERE       1 = 1
              AND A.INC_RETRO_YN = 'N'    -- 인상분소급으로 인한 소급 아니고..
              AND B.C_CD = A.C_CD
              AND B.IDX_CD = '/PY02'                               -- 급여항목
              AND B.CD = A.PAYITEM
              AND C.C_CD = A.C_CD
              AND C.PAYITEM = A.PAYITEM
   GROUP BY   A.C_CD,
              A.PAYROLL_NO,
              A.EMP_ID,
              A.PAYITEM
    --// [2012.06.07] PY2360_V_ERP 내에서 이용되었으나, 성능 개선을 위해 제거
    --   : 다른 곳에서 사용되는지 확인이 요구됨 
/
COMMENT ON VIEW PY2360_V_NO_RETRO IS '(PY2360_V_NO_RETRO)급여_계산결과(인상분_소급_제외)'
/
