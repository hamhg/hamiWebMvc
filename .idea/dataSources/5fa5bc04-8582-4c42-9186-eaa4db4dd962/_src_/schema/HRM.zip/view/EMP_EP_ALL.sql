CREATE VIEW EMP_EP_ALL AS SELECT   T1.EMP_ID EMPNO,
            SUBSTR (T1.EMP_ID, 3, 7) EMPNO_SHORT,
            '0' DUP_DUTY_NO,
            T2.DUTY_CD DUTY_CD,
            T1.MAIL_ADDR EMAIL,
            T5.G_NO G_NO,
            T5.B_NO B_NO,
            T5.D_NO D_NO,
            T5.T_NO T_NO,
            T5.G_NAME_KO,
            T5.B_NAME_KO,
            T5.D_NAME_KO,
            T5.T_NAME_KO,
            T1.EMP_NM NAME_KO,
            T1.ENG_EMP_NM NAME_EN,
            T2.POST_CD POSITION_CD,
            F_GET_CODENM (T2.C_CD,
                          '00101',
                          F_GET_COND_CD1 (T2.C_CD, '00100', T2.POST_CD2))
               POSITION_NM,
            --XX1.DEC_VARCHAR2_SEL (T1.PER_NO, '10', 'RRN')
             ''  RESIDENT_REGISTRATION_NO,
            TO_DATE (T1.ENTER_YMD, 'YYYYMMDD') EMPLOYMENT_DATE_COMPANY,
            T3.ADDR || T3.DTL_ADDR ADDRESS_CARD,
            T1.TEL_NO TEL_RESIDENCE,
            T1.MOBILE_NO TEL_CELLULARPHONE,
            F_GET_CODENM (T1.C_CD, '00090', T1.WORK_PLACE_NM)
               WORK_SITE_LOCATION,
            T1.WORK_LOC_TEL_NO WORK_SITE_TEL,
            T1.WORK_LOC_FAX WORK_SITE_FAX,
            T1.HOMEP_ADDR HOMEPAGE,
            F_GET_CODENM (T2.C_CD, '/SY05', T2.DUTY_CD) DUTY_NAME,
            (SELECT   ENG_NM
               FROM   SY5020
              WHERE   C_CD = T1.C_CD AND CD = T2.POST_CD AND IDX_CD = '/SY04')
               POSITION_NAME_EN,
            (SELECT   LPAD (TO_CHAR (DP_ORDER), 3, '0')
               FROM   SY5020
              WHERE   C_CD = T1.C_CD AND CD = T2.POST_CD AND IDX_CD = '00100')
               POSITION_SORT,
            CASE
               WHEN T2.EMP_TYPE IN ('8', 'P', 'O', '8P', '8H') THEN '0'
               ELSE '1'
            END
               EMP_TYPE_CD,
            T1.WELFARE_CARD_YN,
            T1.RETIRE_YMD,
            F.ALTERNATE_KEY                                      --대체KEY추가
     FROM   PA1010# T1,
            PA1020 T2,
            PA2010 T3,
            (SELECT  DISTINCT A.C_CD,
                      A.OBJ_ID ORG_ID,
                      A.WK_SITE,
                      A.STA_YMD,
                      A.END_YMD,
                      B.G_NO,
                      B.G_NAME_KO,
                      B.G_NAME_KO_SHORT,
                      B.D_NO,
                      B.D_NAME_KO,
                      B.D_NAME_KO_SHORT,
                      B.T_NO,
                      B.T_NAME_KO,
                      B.T_NAME_KO_SHORT,
                      B.B_NO,
                      B.B_NAME_KO,
                      B.B_NAME_KO_SHORT
               FROM   SY3010 A, OM0010_ALL_VW B
              WHERE   A.WK_SITE = B.WK_SITE
                      AND (A.OBJ_TYPE = 'O'
                           OR a.obj_id IN
                                   (SELECT   codexcd FROM HRworksiteexception)))
            T5,
            -- 대체KEY추가
            (SELECT   *
               FROM   (SELECT   RANK ()
                                   OVER (
                                      PARTITION BY EMP_ID
                                      ORDER BY
                                         ins_ymdhms DESC,
                                         mod_ymdhms DESC,
                                         seq_no DESC
                                   )
                                   AS rk,
                                F.*
                         FROM   PA9080# F) FF
              WHERE   FF.RK = 1) F
    WHERE   T2.C_CD = T1.C_CD AND T2.EMP_ID = T1.EMP_ID
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                  AND  T2.END_YMD
            --            AND T2.STAT_CD LIKE '1%'
            -- 대체KEY 추가
            AND T1.EMP_ID = F.EMP_ID(+)
            AND T2.LAST_YN = 'Y'
            AND T3.C_CD(+) = T1.C_CD
            AND T3.EMP_ID(+) = T1.EMP_ID
            AND T3.ADDR_CD(+) = '003'
            AND T5.C_CD(+) = T2.C_CD
            AND T5.ORG_ID(+) = T2.ORG_ID
            AND DECODE (T2.APPNT_CD,
                        '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                        T2.STA_YMD) BETWEEN T5.STA_YMD(+)
                                        AND  T5.END_YMD(+)
/
COMMENT ON VIEW EMP_EP_ALL IS '[HECOS_IF용] (EMP_EP_ALL)인사정보'
/
