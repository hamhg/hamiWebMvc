CREATE VIEW V_HDECLAW_EMP AS SELECT 'HEC' AS C_CD,
          T1.EMP_ID,
          T1.EMP_NM,
          T1.ENG_EMP_NM,
          T1.POST_CD2 AS POST_CD,
          F_GET_CODENM (T1.C_CD, '00100', T1.POST_CD2) AS POST_NM,
          T1.DUTY_CD,
          T1.DUTY_NM,
          F_ORG_NM (T1.C_CD,
                    TO_CHAR (SYSDATE, 'YYYYMMDD'),
                    T1.ORG_ID,
                    '6A')
             AS HQ_ID,
          F_ORG_NM (T1.C_CD,
                    TO_CHAR (SYSDATE, 'YYYYMMDD'),
                    T1.ORG_ID,
                    '1')
             AS HQ_NM,
          T1.WORK_LOC_ID,
          T1.WORK_LOC_NM,
          T2.WORK_LOC_CLASS_CD,
          F_GET_CODENM (T2.C_CD, 'OM020', T2.WORK_LOC_CLASS_CD)
             AS WORK_LOC_CLASS_NM,
          T1.ORG_ID,
          T1.ORG_NM,
          T1.ORG_ID AS TEAM_ID,
          T1.ORG_NM AS TEAM_NM,
          NULL AS PART_ID,
          NULL AS PART_NM,
          T1.OFFICE_TEL_NO,
          T1.MOBILE_NO,
          T1.MAIL_ADDR,
          NULL AS SORT_NO
     FROM PA1020_V_1 T1, OM3010 T2
    WHERE     T1.C_CD = T2.C_CD(+)
          AND T1.WORK_LOC_ID = T2.WORK_LOC_ID(+)
          AND T1.STAT_CD LIKE '1%'
          AND T1.EMP_TYPE NOT IN ('8',
                                  '8P',
                                  'P',
                                  'O',
                                  '8H')
/
