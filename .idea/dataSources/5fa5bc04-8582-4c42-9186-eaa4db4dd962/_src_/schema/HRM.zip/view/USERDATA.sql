CREATE VIEW USERDATA AS SELECT T2.ORG_ID
         , T1.EMP_ID
         , T1.MAIL_ADDR
         , T1.EMP_NM
      FROM PA1010# T1
         , PA1020 T2
     WHERE T1.C_CD = T2.C_CD
       AND T1.EMP_ID = T2.EMP_ID
       AND T2.LAST_YN ='Y'
       AND TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD AND T2.END_YMD
       AND T2.STAT_CD LIKE '1%'
       AND T2.ORG_ID NOT IN (   SELECT OBJ_ID
                                  FROM SY3010
                                 WHERE OBJ_TYPE = 'OE'
                             )
/
COMMENT ON VIEW USERDATA IS '[CANNON_IF용] (USERDATA)'
/
