CREATE VIEW ORG_V_GUCC_FINAL AS SELECT 'H139' AS COMPANY_CODE,
          U1.OBJ_ID AS ORG_CODE,
          CASE
             WHEN U6.OBJ_NM IS NULL
             THEN
                REPLACE (F_GET_OBJNM (U1.C_CD,
                                      U1.OBJ_TYPE,
                                      U1.OBJ_ID,
                                      TO_CHAR (SYSDATE, 'YYYYMMDD')),
                         '근무지체계도',
                         '현대엔지니어링')
             WHEN TRIM (F_ORG_NM (U2.C_CD,
                                  TO_CHAR (SYSDATE, 'YYYYMMDD'),
                                  U2.ORG_ID,
                                  '4D')) <>
                     F_GET_OBJNM (U1.C_CD,
                                  U1.OBJ_TYPE,
                                  U1.OBJ_ID,
                                  TO_CHAR (SYSDATE, 'YYYYMMDD'))
             THEN
                F_GET_OBJNM (U1.C_CD,
                             U1.OBJ_TYPE,
                             U1.OBJ_ID,
                             TO_CHAR (SYSDATE, 'YYYYMMDD'))
             ELSE
                U6.OBJ_NM
          END
             AS ORG_NAME,
          F_ORG_ENG_NM (U1.C_CD,
                        TO_CHAR (SYSDATE, 'YYYYMMDD'),
                        U2.ORG_ID,
                        '4')
             AS ORG_ENG_NAME,
          CASE
             WHEN U1.PAR_OBJ_ID = '0000000000' THEN NULL
             ELSE U1.PAR_OBJ_ID
          END
             AS HI_ORG_CODE,
          U3.ORG_CLASS AS ORG_HD_ASGN_CODE,
          F_GET_CODENM (U3.C_CD, 'OM010', U3.ORG_CLASS) AS ORG_HD_ASGN_NAME,
          SUBSTR (U4.EMP_ID, 3, 7) AS ORG_HD_ID,
          U5.EMP_NM AS ORG_HD_NAME,
          NULL AS ORG_HD_ENG_NAME,
          U4.DUTY_CD AS ORG_GRADE_CODE,
          F_GET_CODENM (U4.C_CD, '/SY05', U4.DUTY_CD) AS ORG_GRADE_NAME,
          NULL AS COMPANY_GRP_CODE,
          NULL AS COMPANY_DET_CODE,
          NULL AS ING_ORG_FLAG,
          '1' AS WP_CODE,
          '본사' AS WP_NAME,
          NULL AS WP_ENG_NAME,
          NULL AS SUB_ORG_FLAG,
          NULL AS EX_ORG_FLAG,
          TO_CHAR (
             CASE WHEN U1.OBJ_ID = 'O000000001' THEN 1 ELSE U1.SEQ_NO END,
             '00000')
             AS SORT_NO,
          TO_NUMBER (U3.ORG_CLASS) AS ORG_RANK,
          TO_CHAR (
             CASE WHEN U1.OBJ_ID = 'O000000001' THEN 1 ELSE U1.SEQ_NO END,
             '00000')
             AS ORG_PRT_ORDER,
          'Y' AS USE_FLAG,
          NULL AS DELETE_DATE,
          NULL AS COMM_ORG_CODE,
          NULL AS CUSTOM_ATTR1,
          NULL AS CUSTOM_ATTR2,
          NULL AS CUSTOM_ATTR3,
          NULL AS CUSTOM_ATTR4,
          NULL AS CUSTOM_ATTR5,
          NULL AS WORK_TYPE,
          NULL AS WORK_DATE
     FROM (           SELECT LEVEL AS LEVEL_NO, T1.*
                        FROM (SELECT T1.*
                                FROM SY3020 T1
                               WHERE     T1.OBJ_TYPE IN (SELECT A.OBJ_TYPE
                                                           FROM SY3080 A
                                                          WHERE A.OBJ_TREE_TYPE =
                                                                   'WATREE')
                                     AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                           AND T1.END_YMD)
                             T1
                  START WITH     1 = 1
                             AND (T1.C_CD, T1.OBJ_TYPE, T1.OBJ_ID) IN (SELECT C_CD,
                                                                              ROOT_OBJ_TYPE,
                                                                              ROOT_OBJ_ID
                                                                         FROM SY3070
                                                                        WHERE     OBJ_TREE_TYPE =
                                                                                     'WATREE'
                                                                              AND TO_CHAR (
                                                                                     SYSDATE,
                                                                                     'YYYYMMDD') BETWEEN STA_YMD
                                                                                                     AND END_YMD)
                             AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                   AND T1.END_YMD
                  CONNECT BY     1 = 1
                             AND PRIOR T1.C_CD = T1.C_CD
                             AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
                             AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
           ORDER SIBLINGS BY T1.SEQ_NO) U1,
          OM3010 U2,
          OM0010 U3,
          OM0020 U4,
          PA1010# U5,
          SY3010 U6
    WHERE     U1.C_CD = U2.C_CD(+)
          AND U1.OBJ_ID = U2.WORK_LOC_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN U2.STA_YMD(+)
                                                AND U2.END_YMD(+)
          --
          AND U2.C_CD = U3.C_CD(+)
          AND U2.ORG_ID = U3.ORG_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN U3.STA_YMD(+)
                                                AND U3.END_YMD(+)
          --
          AND U2.C_CD = U4.C_CD(+)
          AND U2.ORG_ID = U4.ORG_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN U4.STA_YMD(+)
                                                AND U4.END_YMD(+)
          --
          AND U4.C_CD = U5.C_CD(+)
          AND U4.EMP_ID = U5.EMP_ID(+)
          --
          AND U2.C_CD = U6.C_CD(+)
          AND U2.ORG_ID = U6.OBJ_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN U6.STA_YMD(+)
                                                AND U6.END_YMD(+)
          --
          AND U1.OBJ_ID NOT IN ('WG00000006',                       -- 해외설계사무소
                                'WG00000009',                        -- 고용원근무지
                                'WG00000000',                         -- 휴직/퇴직
                                'WG0000000H',                            -- 휴직
                                'WG0000000R')                            -- 퇴직
          --
          AND NVL (U2.ORG_ID, 'XX') NOT IN ('O000000928',
                                            'OAMCQ11211',
                                            'O000001017',
                                            'OAMCO11211',
                                            'O000001290',
                                            'O000001291')   -- 인사팀 배치대기 조직은 제외
          --
          AND NVL (U2.ORG_ID, 'XX') NOT IN ('WA00009797',   -- 인력운영팀배치대기 조직 제외
                                            'WA00005888',        -- 입사교육 조직 제외
                                            'WA00009237',        -- 인사대기 조직 제외
                                            'WA00009583')        -- 발령대기 조직 제외
   -- M+조직도상 본부장은 본부아래 동일한 명칭의 조직을 기표하기 위해 추가. 2015.10.16
   UNION
   SELECT 'H139' AS COMPANY_CODE,
          --'X' || U1.OBJ_ID AS ORG_CODE, -- 본부등급 조직 하위에 본부장 배치용 조직은 'X'를 추가로 기재한다.
          REPLACE(U1.OBJ_ID,'WA','XA') AS ORG_CODE, -- 본부등급 조직 하위에 본부장 배치용 조직은 'X'를 추가로 기재한다.
          CASE
             WHEN U6.OBJ_NM IS NULL
             THEN
                F_GET_OBJNM (U1.C_CD,
                             U1.OBJ_TYPE,
                             U1.OBJ_ID,
                             TO_CHAR (SYSDATE, 'YYYYMMDD'))
             WHEN TRIM (F_ORG_NM (U2.C_CD,
                                  TO_CHAR (SYSDATE, 'YYYYMMDD'),
                                  U2.ORG_ID,
                                  '4D')) <>
                     F_GET_OBJNM (U1.C_CD,
                                  U1.OBJ_TYPE,
                                  U1.OBJ_ID,
                                  TO_CHAR (SYSDATE, 'YYYYMMDD'))
             THEN
                F_GET_OBJNM (U1.C_CD,
                             U1.OBJ_TYPE,
                             U1.OBJ_ID,
                             TO_CHAR (SYSDATE, 'YYYYMMDD'))
             ELSE
                U6.OBJ_NM
          END
             AS ORG_NAME,
          F_ORG_ENG_NM (U1.C_CD,
                        TO_CHAR (SYSDATE, 'YYYYMMDD'),
                        U2.ORG_ID,
                        '4')
             AS ORG_ENG_NAME,
          CASE WHEN U1.PAR_OBJ_ID = '0000000000' THEN NULL ELSE U1.OBJ_ID END
             AS HI_ORG_CODE,
          U3.ORG_CLASS AS ORG_HD_ASGN_CODE,
          F_GET_CODENM (U3.C_CD, 'OM010', U3.ORG_CLASS) AS ORG_HD_ASGN_NAME,
          SUBSTR (U4.EMP_ID, 3, 7) AS ORG_HD_ID,
          U5.EMP_NM AS ORG_HD_NAME,
          NULL AS ORG_HD_ENG_NAME,
          U4.DUTY_CD AS ORG_GRADE_CODE,
          F_GET_CODENM (U4.C_CD, '/SY05', U4.DUTY_CD) AS ORG_GRADE_NAME,
          NULL AS COMPANY_GRP_CODE,
          NULL AS COMPANY_DET_CODE,
          NULL AS ING_ORG_FLAG,
          '1' AS WP_CODE,
          '본사' AS WP_NAME,
          NULL AS WP_ENG_NAME,
          NULL AS SUB_ORG_FLAG,
          NULL AS EX_ORG_FLAG,
          -- 본부 아래에 바로 기표되도록 정렬 순서는 0으로 한다.
          TO_CHAR (0, '00000') AS SORT_NO,
          TO_NUMBER (U3.ORG_CLASS) AS ORG_RANK,
          TO_CHAR (
             CASE WHEN U1.OBJ_ID = 'O000000001' THEN 1 ELSE U1.SEQ_NO END,
             '00000')
             AS ORG_PRT_ORDER,
          'Y' AS USE_FLAG,
          NULL AS DELETE_DATE,
          NULL AS COMM_ORG_CODE,
          NULL AS CUSTOM_ATTR1,
          NULL AS CUSTOM_ATTR2,
          NULL AS CUSTOM_ATTR3,
          NULL AS CUSTOM_ATTR4,
          NULL AS CUSTOM_ATTR5,
          NULL AS WORK_TYPE,
          NULL AS WORK_DATE
     FROM (           SELECT LEVEL AS LEVEL_NO, T1.*
                        FROM (SELECT T1.*
                                FROM SY3020 T1
                               WHERE     T1.OBJ_TYPE IN (SELECT A.OBJ_TYPE
                                                           FROM SY3080 A
                                                          WHERE A.OBJ_TREE_TYPE =
                                                                   'WATREE')
                                     AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                           AND T1.END_YMD)
                             T1
                  START WITH     1 = 1
                             AND (T1.C_CD, T1.OBJ_TYPE, T1.OBJ_ID) IN (SELECT C_CD,
                                                                              ROOT_OBJ_TYPE,
                                                                              ROOT_OBJ_ID
                                                                         FROM SY3070
                                                                        WHERE     OBJ_TREE_TYPE =
                                                                                     'WATREE'
                                                                              AND TO_CHAR (
                                                                                     SYSDATE,
                                                                                     'YYYYMMDD') BETWEEN STA_YMD
                                                                                                     AND END_YMD)
                             AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                   AND T1.END_YMD
                  CONNECT BY     1 = 1
                             AND PRIOR T1.C_CD = T1.C_CD
                             AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
                             AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
           ORDER SIBLINGS BY T1.SEQ_NO) U1,
          OM3010 U2,
          OM0010 U3,
          OM0020 U4,
          PA1010# U5,
          SY3010 U6
    WHERE     U1.C_CD = U2.C_CD(+)
          AND U1.OBJ_ID = U2.WORK_LOC_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN U2.STA_YMD(+)
                                                AND U2.END_YMD(+)
          --
          AND U2.C_CD = U3.C_CD(+)
          AND U2.ORG_ID = U3.ORG_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN U3.STA_YMD(+)
                                                AND U3.END_YMD(+)
          --
          AND U2.C_CD = U4.C_CD(+)
          AND U2.ORG_ID = U4.ORG_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN U4.STA_YMD(+)
                                                AND U4.END_YMD(+)
          --
          AND U4.C_CD = U5.C_CD(+)
          AND U4.EMP_ID = U5.EMP_ID(+)
          --
          AND U2.C_CD = U6.C_CD(+)
          AND U2.ORG_ID = U6.OBJ_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN U6.STA_YMD(+)
                                                AND U6.END_YMD(+)
          --
          AND U3.ORG_CLASS = '002'             -- 사업본부에 해당하는 경우만 추가 : 조직등급이 본부
          AND U1.OBJ_ID <> 'WA00008610'
/
COMMENT ON VIEW ORG_V_GUCC_FINAL IS 'GUCC 연동용 조직뷰'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.COMPANY_CODE IS '회사코드(GMDM)'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.ORG_CODE IS '부서(조직)코드'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.ORG_NAME IS '부서(조직) 명'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.ORG_ENG_NAME IS '부서(조직) 영문명'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.HI_ORG_CODE IS '상위부서(조직) 코드'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.ORG_HD_ASGN_CODE IS '부서(조직) 등급'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.ORG_HD_ASGN_NAME IS '부서(조직) 등급 명'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.ORG_HD_ID IS '조직장 사번'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.ORG_HD_NAME IS '조직장 이름'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.ORG_HD_ENG_NAME IS '조직장 영문이름'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.ORG_GRADE_CODE IS '조직장 호칭'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.ORG_GRADE_NAME IS '조직장 호칭 명'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.WP_CODE IS '소재지역'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.WP_NAME IS '소재지역 명'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.WP_ENG_NAME IS '소재지역 영문 명'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.SORT_NO IS '조직순서'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.ORG_RANK IS '조직레벨'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.ORG_PRT_ORDER IS '출력순서'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.USE_FLAG IS '사용여부'
/
COMMENT ON COLUMN ORG_V_GUCC_FINAL.DELETE_DATE IS '폐지일자'
/
