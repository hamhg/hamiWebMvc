CREATE VIEW V_IM_ORG_TEST AS SELECT "ORG_CLASS",
            "TLEVEL",
            "SEQ_NO",
            "OBJ_TYPE",
            "OBJ_ID",
            "PAR_OBJ_ID",
            "G_ID",
            "G_NM",
            "B_ID",
            "B_NM",
            "OBJ_NM",
            "STA_YMD",
            "END_YMD",
            "SMR_OBJ_NM",
            "ENG_OBJ_NM",
            "TABLE_NM",
            "WK_SITE",
            "ORG_FULL_NM",
            "BONBU_ID",
            "WORK_LOC_CLASS_CD"
       FROM (SELECT O1.ORG_CLASS,
                    T1.TLEVEL,
                    T1.SEQ SEQ_NO,
                    T1.OBJ_TYPE,
                    T1.OBJ_ID,
                    T1.PAR_OBJ_ID,
                    F_ORG_ID ('HEC',
                              TO_CHAR (SYSDATE + 3, 'YYYYMMDD'),
                              T1.OBJ_ID,
                              '1')
                       AS G_ID,
                    F_ORG_NM ('HEC',
                              TO_CHAR (SYSDATE + 3, 'YYYYMMDD'),
                              T1.OBJ_ID,
                              '1')
                       AS G_NM,
                    F_ORG_ID ('HEC',
                              TO_CHAR (SYSDATE + 3, 'YYYYMMDD'),
                              T1.OBJ_ID,
                              '2')
                       AS B_ID,
                    F_ORG_NM ('HEC',
                              TO_CHAR (SYSDATE + 3, 'YYYYMMDD'),
                              T1.OBJ_ID,
                              '2')
                       AS B_NM,
                    T2.OBJ_NM,
                    T2.STA_YMD,
                    T2.END_YMD,
                    T2.SMR_OBJ_NM,
                    T2.ENG_OBJ_NM,
                    T2.TABLE_NM,
                    DECODE (T2.WK_SITE,
                            '1100', '11',
                            '2100', '21',
                            '3100', '31',
                            '4200', '42',
                            '7200', '72',
                            '7100', '71',
                            '6100', '61',
                            '9100', '91',
                            T2.WK_SITE)
                       WK_SITE,
                    T2.ORG_FULL_NM,
                    '' BONBU_ID,
                    '' WORK_LOC_CLASS_CD
               FROM (           SELECT LEVEL TLEVEL,
                                       T1.OBJ_TYPE,
                                       T1.OBJ_ID,
                                       T1.PAR_OBJ_ID,
                                       T1.SEQ_NO,
                                       ROWNUM SEQ
                                  FROM (SELECT T1.*
                                          FROM SY3020 T1
                                         WHERE     T1.C_CD = 'HEC'
                                               AND T1.OBJ_TYPE LIKE 'O%'
                                               AND TO_CHAR (SYSDATE + 3, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                                     AND T1.END_YMD)
                                       T1
                            START WITH     T1.C_CD = 'HEC'
                                       AND T1.OBJ_TYPE = 'O'
                                       AND T1.OBJ_ID = 'O000000001'
                                       AND TO_CHAR (SYSDATE + 3, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                             AND T1.END_YMD
                            CONNECT BY     PRIOR T1.C_CD = T1.C_CD
                                       AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
                                       AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
                     ORDER SIBLINGS BY T1.SEQ_NO) T1,
                    SY3010 T2,
                    OM0010 O1
              WHERE     T2.C_CD = 'HEC'
                    AND T2.OBJ_TYPE = T1.OBJ_TYPE
                    AND T2.OBJ_ID = T1.OBJ_ID
                    AND O1.ORG_ID = T1.OBJ_ID
                    AND TO_CHAR (SYSDATE + 3, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                          AND T2.END_YMD
                    AND TO_CHAR (SYSDATE + 3, 'YYYYMMDD') BETWEEN O1.STA_YMD
                                                          AND O1.END_YMD
             -- ORDER BY T1.SEQ
             UNION ALL
             SELECT '' ORG_CLASS,
                    T1.TLEVEL,
                    T1.SEQ SEQ_NO,
                    T1.OBJ_TYPE,
                    T1.OBJ_ID,
                    T1.PAR_OBJ_ID,
                    '' G_ID,
                    '' G_NM,
                    '' B_ID,
                    '' B_NM,
                    T2.OBJ_NM,
                    T2.STA_YMD,
                    T2.END_YMD,
                    T2.SMR_OBJ_NM,
                    T2.ENG_OBJ_NM,
                    T2.TABLE_NM,
                    T2.WK_SITE,
                    T2.ORG_FULL_NM,
                    T3.BONBU_ID,
                    T3.WORK_LOC_CLASS_CD
               FROM (           SELECT LEVEL TLEVEL,
                                       T1.OBJ_TYPE,
                                       T1.OBJ_ID,
                                       T1.PAR_OBJ_ID,
                                       ROWNUM SEQ
                                  FROM (SELECT T1.*
                                          FROM SY3020 T1
                                         WHERE     T1.C_CD = 'HEC'
                                               AND T1.OBJ_TYPE IN (SELECT A.OBJ_TYPE
                                                                     FROM SY3080 A
                                                                    WHERE     A.C_CD =
                                                                                 'HEC'
                                                                          AND A.OBJ_TREE_TYPE =
                                                                                 'WATREE')
                                               AND TO_CHAR (SYSDATE + 3, 'yyyymmdd') BETWEEN T1.STA_YMD
                                                                                     AND T1.END_YMD)
                                       T1
                            START WITH     (T1.C_CD, T1.OBJ_TYPE, T1.OBJ_ID) IN (SELECT C_CD,
                                                                                        ROOT_OBJ_TYPE,
                                                                                        ROOT_OBJ_ID
                                                                                   FROM SY3070
                                                                                  WHERE     C_CD =
                                                                                               'HEC'
                                                                                        AND OBJ_TREE_TYPE =
                                                                                               'WATREE'
                                                                                        AND TO_CHAR (
                                                                                               SYSDATE + 3,
                                                                                               'yyyymmdd') BETWEEN STA_YMD
                                                                                                               AND END_YMD)
                                       AND TO_CHAR (SYSDATE + 3, 'yyyymmdd') BETWEEN T1.STA_YMD
                                                                             AND T1.END_YMD
                            CONNECT BY     PRIOR T1.C_CD = T1.C_CD
                                       AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
                                       AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
                     ORDER SIBLINGS BY T1.SEQ_NO) T1,
                    SY3010 T2,
                    OM3010 T3
              WHERE     T2.C_CD = 'HEC'
                    AND T2.OBJ_TYPE = T1.OBJ_TYPE
                    AND T2.OBJ_ID = T1.OBJ_ID
                    AND TO_CHAR (SYSDATE + 3, 'yyyymmdd') BETWEEN T2.STA_YMD
                                                          AND T2.END_YMD
                    AND T2.C_CD = T3.C_CD(+)
                    AND T2.OBJ_ID = T3.WORK_LOC_ID(+)
                    AND T2.STA_YMD = T3.STA_YMD(+)
             -- ORDER BY T1.SEQ
             UNION ALL
             SELECT '' ORG_CLASS,
                    ROWNUM TLEVEL,
                    ROWNUM SEQ_NO,
                    A.OBJ_TYPE,
                    A.OBJ_ID,
                    '' PAR_OBJ_ID,
                    '' G_ID,
                    '' G_NM,
                    '' B_ID,
                    '' B_NM,
                    A.OBJ_NM,
                    A.STA_YMD,
                    '' END_YMD,
                    '' SMR_OBJ_NM,
                    '' ENG_OBJ_NM,
                    '' TABLE_NM,
                    '' WK_SITE,
                    '' ORG_FULL_NM,
                    '' BONUB_ID,
                    '' WORK_LOC_CLASS_CD
               FROM SY3010 A
              WHERE     A.OBJ_TYPE = 'OE'
                    AND A.STA_YMD >= '20080101'
                    AND A.OBJ_ID NOT IN ('OE00000001',
                                         'OE00000002',
                                         'OE00000003',
                                         'OE00000004',
                                         'OE00000005',
                                         'OE00000006',
                                         'OE00000007',
                                         'OE00000008',
                                         'OE00000009',
                                         'OE00000391',
                                         'OE00000394',
                                         'OE00000392',
                                         'OE00000293'))
   ORDER BY OBJ_TYPE, SEQ_NO
/
COMMENT ON VIEW V_IM_ORG_TEST IS '[IM_IF용] (V_IM_ORG)조직정보점검'
/
