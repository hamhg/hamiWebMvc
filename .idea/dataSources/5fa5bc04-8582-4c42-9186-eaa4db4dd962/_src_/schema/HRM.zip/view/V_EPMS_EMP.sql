CREATE VIEW V_EPMS_EMP AS SELECT A.C_CD,
          A.EMP_ID,
          SUBSTR (A.EMP_ID, 3, 7) AS EMP_ID7,
          A.EMP_NM,
          B.POST_CD2,                                       -- hecos 직위 / 호칭직위
          F_GET_CODENM (A.C_CD, '00100', B.POST_CD2) AS POST_NM2,
          A.WORK_LOC_TEL_NO,
          A.MOBILE_NO,
          A.MAIL_ADDR,
          CASE
             WHEN B.STAT_CD = '30' THEN '3'
             WHEN B.STAT_CD = '13' THEN '2'
             WHEN B.STAT_CD = '10' THEN '1'
             ELSE ''
          END
             AS EMP_STATUS,
          CASE
             WHEN B.STAT_CD = '30'
             THEN
                A.RETIRE_YMD
             WHEN B.STAT_CD LIKE '13'
             THEN
                F_GET_OBJ_STA_YMD2 (B.C_CD,
                                    B.EMP_ID,
                                    'WA',
                                    B.WORK_LOC_ID,
                                    TO_CHAR (SYSDATE, 'YYYYMMDD'))
             WHEN B.STAT_CD LIKE '10'
             THEN
                A.ENTER_YMD
             ELSE
                ''
          END
             AS END_YMD,
          B.ORG_ID,
          B.WORK_LOC_ID
     FROM PA1010# A, PA1020 B
    WHERE     B.EMP_TYPE != 'O'
          AND A.PAY_CALC_EXEC_YN != 'Y'
          AND A.C_CD = B.C_CD
          AND A.EMP_ID = B.EMP_ID
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN B.STA_YMD AND B.END_YMD
          AND B.LAST_YN = 'Y'
          AND B.STAT_CD LIKE '1%' --// 퇴직자, 부서이동자의 경우. ePMS에서 연동데이터 비교하여 자체 정리
          AND B.EMP_TYPE NOT IN ('8', 'O', '8H')
          AND F_ORG_NM (B.C_CD,
                        TO_CHAR (SYSDATE, 'YYYYMMDD'),
                        B.ORG_ID,
                        '6') = 'O000001626'              --// 자산관리실 인원에 한해 조회
/
