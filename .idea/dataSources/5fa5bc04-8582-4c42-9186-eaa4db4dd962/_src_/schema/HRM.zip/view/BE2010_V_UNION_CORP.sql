CREATE VIEW BE2010_V_UNION_CORP AS SELECT T1.C_CD,
          T1.PAYROLL_NO,
          T1.SINS_TYPE,
          T1.EMP_ID,
          T1.ORGN_YMD,
          T1.GRD_CD,
          T1.DDCT_STAT_CD,
          T1.PAY_TYPE,
          'HQ' AS PAY_CORP_TYPE,
          T1.PSN_MON,
          T1.COM_MON,
          T1.EXCE_PSN_MON,
          T1.EXCE_COM_MON,
          T1.REAL_PSN_MON,
          T1.REAL_COM_MON,
          T1.CALC_STD_MON,
          T1.OINS_MON,
          T1.CONF_INS_MON,
          T1.HEALTH_DDCT_PER,
          T1.CAL_CONF_INS_MON,
          T1.JOB_TYPE,
          T1.HEALTH_INT_MON,
          T1.OINS_INT_MON,
          T1.FUNC_MON,
          T1.EXCEPT_YN,
          T1.CONF_YN,
          T1.NOTE,
          T1.INS_USER_ID,
          T1.INS_YMDHMS,
          T1.MOD_USER_ID,
          T1.MOD_YMDHMS
     FROM BE2010 T1
    WHERE T1.C_CD = 'HEC' AND T1.EMP_ID LIKE '%' AND T1.CONF_YN = 'Y'
   --=====================================
   UNION
   --=====================================
   SELECT T2.C_CD,
          T2.PAYROLL_NO,
          T2.SINS_TYPE,
          T2.EMP_ID,
          T2.ORGN_YMD,
          T2.GRD_CD,
          T2.DDCT_STAT_CD,
          T2.PAY_TYPE,
          --'CORP' AS PAY_SRC_TYPE,
          (SELECT A2.CORP_TYPE
             FROM PY0300 A1, PY1020_CORP_EMP A2
            WHERE     A1.C_CD = T2.C_CD
                  AND A1.PAYROLL_NO = T2.PAYROLL_NO
                  AND A2.C_CD = A1.C_CD
                  AND A2.EMP_ID = T2.EMP_ID
                  AND A2.PAYROLL_TYPE = A1.PAYROLL_TYPE
                  AND A1.ORGN_YM BETWEEN A2.STA_YM AND A2.END_YM)
             AS PAY_CORP_TYPE,
          T2.PSN_MON,
          T2.COM_MON,
          T2.EXCE_PSN_MON,
          T2.EXCE_COM_MON,
          T2.REAL_PSN_MON,
          T2.REAL_COM_MON,
          T2.CALC_STD_MON,
          T2.OINS_MON,
          T2.CONF_INS_MON,
          T2.HEALTH_DDCT_PER,
          T2.CAL_CONF_INS_MON,
          T2.JOB_TYPE,
          T2.HEALTH_INT_MON,
          T2.OINS_INT_MON,
          T2.FUNC_MON,
          T2.EXCEPT_YN,
          'Y' AS CONF_YN,        -- 법인으로 백업된 내역은 모두 마감처리분으로 처리. 2014.10.15 김성관
          T2.NOTE,
          T2.INS_USER_ID,
          T2.INS_YMDHMS,
          T2.BACKUP_USER_ID,                                  --T2.MOD_USER_ID
          T2.BACKUP_YMDHMS                                     --T2.MOD_YMDHMS
     FROM BE2010_EXCEPT_CORP T2
    WHERE T2.C_CD = 'HEC' AND T2.EMP_ID LIKE '%'
      AND T2.PAYROLL_NO >= '20140401'  --//합병(전) 미수금 예외등록자 제외 목적)
/
