CREATE VIEW OUTEMP_HECOS AS SELECT   T1.EMP_ID EMPNO,
            SUBSTR (T1.EMP_ID, 3, 7) EMPNO_SHORT,
            T5.G_NO G_NO,
            T5.B_NO B_NO,
            T5.D_NO D_NO,
            T5.T_NO T_NO,
            T5.G_NAME_KO,
            T5.B_NAME_KO,
            T5.D_NAME_KO,
            T5.T_NAME_KO,
            T1.EMP_NM NAME_KO,
            T2.POST_CD POSITION_CD,
            F_GET_CODENM (T2.C_CD,
                          '00101',
                          F_GET_COND_CD1 (T2.C_CD, '00100', T2.POST_CD2))
               AS POSITION_NM
     FROM   PA1010# T1,
            PA1020 T2,
            (SELECT   A.C_CD,
                      A.OBJ_ID ORG_ID,
                      A.WK_SITE,
                      A.STA_YMD,
                      A.END_YMD,
                      B.G_NO,
                      B.G_NAME_KO,
                      B.G_NAME_KO_SHORT,
                      B.D_NO,
                      B.D_NAME_KO,
                      B.D_NAME_KO_SHORT,
                      B.T_NO,
                      B.T_NAME_KO,
                      B.T_NAME_KO_SHORT,
                      B.B_NO,
                      B.B_NAME_KO,
                      B.B_NAME_KO_SHORT
               FROM   SY3010 A, OM0010_ALL_VW B
              WHERE   A.WK_SITE = B.WK_SITE
                      AND (A.OBJ_TYPE = 'O'
                           OR a.obj_id IN
                                   (SELECT   codexcd FROM HRworksiteexception)))
            T5                                                             --,
    --            PA2261 T6
    WHERE   T2.C_CD = T1.C_CD AND T2.EMP_ID = T1.EMP_ID -- 조직변경적용위해 임시 변경(20110614)
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD -- AND TO_CHAR (SYSDATE + 2, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                  AND  T2.END_YMD
            AND T2.STAT_CD LIKE '1%'
            AND T2.EMP_TYPE IN ('8')
            AND T2.LAST_YN = 'Y'
            AND T5.C_CD(+) = T2.C_CD
            AND T5.ORG_ID(+) = T2.ORG_ID
   -- 2012/08/29  HECOS 사용여부를 등록하지 않음
   --             재직중인 외주직원 전체 전달
   --            AND T6.C_CD = T1.C_CD
   --            AND T6.EMP_ID = T1.EMP_ID
   --            AND T6.USE_SYS = '002'
   --            -- 조직변경적용위해 임시 변경(20110614)
   --            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T6.STA_YMD -- AND TO_CHAR (SYSDATE + 2, 'YYYYMMDD') BETWEEN T6.STA_YMD
   --                                                  AND  T6.END_YMD
   UNION ALL
   -- 퇴직자  예외처리
   SELECT   T1.EMP_ID EMPNO,
            SUBSTR (T1.EMP_ID, 3, 7) EMPNO_SHORT,
            T5.G_NO G_NO,
            T5.B_NO B_NO,
            T5.D_NO D_NO,
            T5.T_NO T_NO,
            T5.G_NAME_KO,
            T5.B_NAME_KO,
            T5.D_NAME_KO,
            T5.T_NAME_KO,
            T1.EMP_NM NAME_KO,
            T2.POST_CD POSITION_CD,
            F_GET_CODENM (T2.C_CD,
                          '00101',
                          F_GET_COND_CD1 (T2.C_CD, '00100', T2.POST_CD2))
               POSITION_NM
     FROM   PA1010# T1,
            PA1020 T2,
            (SELECT   A.C_CD,
                      A.OBJ_ID ORG_ID,
                      A.WK_SITE,
                      A.STA_YMD,
                      A.END_YMD,
                      B.G_NO,
                      B.G_NAME_KO,
                      B.G_NAME_KO_SHORT,
                      B.D_NO,
                      B.D_NAME_KO,
                      B.D_NAME_KO_SHORT,
                      B.T_NO,
                      B.T_NAME_KO,
                      B.T_NAME_KO_SHORT,
                      B.B_NO,
                      B.B_NAME_KO,
                      B.B_NAME_KO_SHORT
               FROM   SY3010 A, OM0010_ALL_VW B
              WHERE   A.WK_SITE = B.WK_SITE
                      AND (A.OBJ_TYPE = 'O'
                           OR a.obj_id IN
                                   (SELECT   codexcd FROM HRworksiteexception)))
            T5,
            PA2261 T6
    WHERE   T2.C_CD = T1.C_CD AND T2.EMP_ID = T1.EMP_ID
            -- 조직변경적용위해 임시 변경(20110614)
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD -- AND TO_CHAR (SYSDATE + 2, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                  AND  T2.END_YMD
            AND T2.STAT_CD = '30'
            AND T2.EMP_TYPE IN ('8')
            AND T2.LAST_YN = 'Y'
            AND T5.C_CD(+) = T2.C_CD
            AND T5.ORG_ID(+) = T2.ORG_ID
            AND DECODE (T2.APPNT_CD,
                        '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                        T2.STA_YMD) BETWEEN T5.STA_YMD(+)
                                        AND  T5.END_YMD(+)
            AND T6.C_CD = T1.C_CD
            AND T6.EMP_ID = T1.EMP_ID
            AND T6.USE_SYS = '002'
            -- 조직변경적용위해 임시 변경(20110614)
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T6.STA_YMD -- AND TO_CHAR (SYSDATE + 2, 'YYYYMMDD') BETWEEN T6.STA_YMD
                                                  AND  T6.END_YMD
/
