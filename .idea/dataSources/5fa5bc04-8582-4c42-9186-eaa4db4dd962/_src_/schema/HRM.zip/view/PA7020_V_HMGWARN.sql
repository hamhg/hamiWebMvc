CREATE VIEW PA7020_V_HMGWARN AS SELECT   T2.EMP_ID,
            T2.ORG_ID,
            T2.ORG_NM,
            T2.POST_CD,
            T2.POST_NM,
            T2.EMP_NM,
            T1.CERT_CD,
            F_GET_CODENM(T1.C_CD, 'PA051', T1.CERT_CD) CERT_NM,
            T1.ASSO_NM,
            T1.RSN_TXT,
            TO_CHAR(INS_YMDHMS, 'YYYYMMDD') ISSUE_YMD
     FROM   PA7020 T1
          , PA1020_V_1 T2
    WHERE   T1.C_CD = T2.C_CD
      AND   T1.EMP_ID = T2.EMP_ID
      AND   T1.CERT_CD IN ('11','16','13','20') -- 재직증명서, 재직증명서(영문), 경력증명서, 경력증명서(영문)
--      AND   T1.ISSUE_YMD IS NOT NULL 
/
