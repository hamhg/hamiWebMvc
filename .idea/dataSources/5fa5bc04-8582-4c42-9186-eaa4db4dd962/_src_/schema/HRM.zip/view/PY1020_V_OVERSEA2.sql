CREATE VIEW PY1020_V_OVERSEA2 AS SELECT S1.C_CD,
       S1.EMP_ID,
       (SELECT MAX(S2.EXPT_END_YMD)
          FROM PY1020_V_OVERSEA S2
         WHERE S2.C_CD = S1.C_CD
           AND S2.EMP_ID = S1.EMP_ID
           AND S2.STA_YMD <= S1.ASSIGN_END_YMD
           AND S2.SCH_END_YMD2 >= S1.ASSIGN_STA_YMD
           AND S2.STA_YMD = (SELECT MAX(S3.STA_YMD)
                               FROM PY1020_V_OVERSEA S3
                              WHERE S3.C_CD = S1.C_CD
                                AND S3.EMP_ID = S1.EMP_ID
                                AND S3.STA_YMD <= S1.ASSIGN_END_YMD
                                AND S3.SCH_END_YMD2 >= S1.ASSIGN_STA_YMD)
       ) AS EXPT_END_YMD,
       S1.ASSIGN_STA_YMD,
       S1.ASSIGN_END_YMD
  FROM (SELECT S1.C_CD,
               S1.EMP_ID,
               S1.ASSIGN_STA_YMD,
               MAX (S1.ASSIGN_END_YMD) AS ASSIGN_END_YMD
         FROM (SELECT S1.C_CD,
                      S1.EMP_ID,
                      NVL (S1.ASSIGN_STA_YMD, S1.STA_YMD) AS ASSIGN_STA_YMD,
                      (SELECT NVL (
                                 MIN (
                                    CASE
                                       WHEN S2.APPNT_CD = '23'
                                       THEN
                                          STA_YMD
                                       ELSE
                                          TO_CHAR (
                                             TO_DATE (STA_YMD, 'YYYYMMDD') - 1,
                                             'YYYYMMDD')
                                    END),
                               '99991231')
                       FROM PA1020 S2
                      WHERE     S2.C_CD = S1.C_CD
                            AND S2.EMP_ID = S1.EMP_ID
                            AND S2.APPNT_CD IN ('22',
                                                '23',
                                                '03',
                                                '04',
                                                '20') -- 해외현장복귀, 퇴사, 국내현장부임 ,국내현장전임, 해외현장부임
                            AND S2.STA_YMD > S1.STA_YMD
                            AND S2.ROWID <> S1.ROWID)
                       AS ASSIGN_END_YMD
                 FROM PA1020 S1
                WHERE     S1.APPNT_CD IN ('20')     -- 해외현장부임~복귀까지시의 구간을 구하기 위해서
                    -- 같은날 중복발령이 난 경우를 피하기 위해서
                  AND S1.SEQ_NO =
                           (SELECT MAX (S2.SEQ_NO)
                              FROM PA1020 S2
                             WHERE     S2.C_CD = S1.C_CD
                                   AND S2.EMP_ID = S1.EMP_ID
                                   AND S2.STA_YMD = S1.STA_YMD
                                   AND S2.APPNT_CD IN ('20'))) S1
        GROUP BY S1.C_CD, S1.EMP_ID, S1.ASSIGN_STA_YMD) S1
/
