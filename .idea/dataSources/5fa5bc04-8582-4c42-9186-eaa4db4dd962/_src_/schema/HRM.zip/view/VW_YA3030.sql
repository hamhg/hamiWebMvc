CREATE VIEW VW_YA3030 AS SELECT   "C_CD",
            "EMP_ID",
            "ADJ_YY",
            "ADJITEM",
            "TRG_PER_NO",
            "MON",
            "APPLY_YN",
            "NOTE",
            "INS_USER_ID",
            "INS_YMDHMS",
            "MOD_USER_ID",
            "MOD_YMDHMS",
            "HALF_MON",
            "HALF_MON2"
     FROM   YA3030#
/
