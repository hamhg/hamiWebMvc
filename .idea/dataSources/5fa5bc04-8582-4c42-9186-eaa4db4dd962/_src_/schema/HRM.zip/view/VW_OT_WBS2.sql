CREATE VIEW VW_OT_WBS2 AS SELECT /*+CHOOSE */
         T1.POSID,
          NVL (T2.PROJECT_NM, '') || ' ' || NVL (T1.LTEXT, '') AS POSNM,
          T2.SELC_ACCT
     FROM SAP.VW_IF_WBS T1, SAP.VW_IF_PROJECTMASTER T2
    WHERE     T1.PSPHI = T2.PROJECT_CD
          AND T2.PRJ_STATUS = '1'
          AND (   SUBSTR (T1.POSID, 1, 1) IN ('H', 'J', 'I')
               OR T1.BUZTY2 IN ('H012', 'H012V', 'H0121')
               OR T1.POSID = 'BDLA1501-BXHH-H0121')
/
