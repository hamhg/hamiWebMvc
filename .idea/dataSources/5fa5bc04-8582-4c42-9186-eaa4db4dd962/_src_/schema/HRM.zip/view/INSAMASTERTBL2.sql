CREATE VIEW INSAMASTERTBL2 AS SELECT 'HE' COMPANYCD,
          'ko' LANGCD,
          A.EMP_ID SABUN,
          SUBSTR (A.EMP_ID, 3, 7) USERID,
          A.EMP_NM KNAME,
          A.ENG_EMP_NM ENAME,
          A.CHA_EMP_NM SNAME,
          B.POST_CD2 JIKWICD,                               -- hecos 직위 / 호칭직위
          --B.WORK_LOC_ID BUSOCD,
          CASE WHEN B.DUTY_CD IN ('AE', 'AK') AND E.ORG_CLASS = '002' THEN 'X' END || B.WORK_LOC_ID
             BUSOCD, -- 본부장 직책의 경우 근무지ID 앞에 X를 기표하여 본부장 근무지 아래에 dummy로 추가된 조직에 매핑되도록 처리한다.
          NULL TEAMCD,
          SUBSTR (A.EMP_ID, 3, 7) || 'hec*' JUMINNO,
          A.WORK_LOC_TEL_NO TELOFFICE,
          A.MOBILE_NO TELHOME,
          A.WORK_LOC_FAX FAX,
          NVL (A.MAIL_ADDR, SUBSTR (A.EMP_ID, 3, 7) || '@hec.co.kr') EMAILID,
          A.VOIP VOIP_TEL,
          DECODE (D.EMP_ID, NULL, '0', '1') ISGROUPWARE,
          DECODE (A.MAIL_ADDR, NULL, '0', '1') ISEMAIL,
          NULL ISEIS,
          SYSDATE CREATEDATE,
          SYSDATE CHANGEDATE,
          C.JOB_TXT BUSINESS,
          F_ORG_NM (B.C_CD,
                    B.STA_YMD,
                    B.ORG_ID,
                    '1')
             ORGSAUP,
          DECODE (B.DUTY_CD, 'ZZ', '', B.DUTY_CD) SITEPOS,
          DECODE (B.DUTY_NM, '직책없음', '', B.DUTY_NM) SITEPOS_NM,
          F_ORG_ID (B.C_CD,
                    B.STA_YMD,
                    B.ORG_ID,
                    '1')
             ORGDEPT,
          SUBSTR (A.MAIL_ADDR, 1, INSTR (A.MAIL_ADDR, '@') - 1) MAILID,
          SUBSTR (A.MAIL_ADDR, INSTR (A.MAIL_ADDR, '@') + 1) MAILDOMAIN,
          NULL MODIFYINFODATE,
          '2' CHILDCOMPANYCD,
          CASE
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 4) = '2166'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 7) = '02-2166'
             THEN
                '2166'
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 4) = '2136'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 7) = '02-2136'
             THEN
                '2166'
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 9) = '82-2-2166'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 10) = '82-02-2166'
             THEN
                '2166'
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 4) = '2134'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 7) = '02-2134'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 6) = '022134'
             --THEN '2134'
             THEN
                '8833'                    -- 계동사옥 전체 이전전까지 임시변경. 현대CnI 박재형 과장.
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 9) = '82-2-2134'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 10) = '82-02-2134'
             --THEN '2134'
             THEN
                '8833'                    -- 계동사옥 전체 이전전까지 임시변경. 현대CnI 박재형 과장.
          END
             EXTENSIONNUMBER,
          DECODE (A.EMP_ID,
                  '201004721', 'N',
                  '200903192', 'N',
                  DECODE (SUBSTR (B.ORG_ID, 1, 2), 'OE', 'N', 'Y'))
             DISPLAYYN                              -- 인재개발부 고문/자문 김동혁, 이평호 제외
     FROM PA1010# A,
          PA1020 B,
          PA2170 C,
          PA2261 D,
          OM0010 E
    WHERE     B.EMP_TYPE != 'O'
          AND A.PAY_CALC_EXEC_YN != 'Y'
          AND A.C_CD = B.C_CD
          AND A.EMP_ID = B.EMP_ID
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN B.STA_YMD AND B.END_YMD
          AND B.LAST_YN = 'Y'
          AND B.STAT_CD = '10'
          AND A.EMP_ID = C.EMP_ID(+)
          AND '2' = C.CLASS_CD(+)
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN C.STA_YMD(+)
                                                AND C.END_YMD(+)
          AND '005' = D.USE_SYS(+)
          AND A.EMP_ID = D.EMP_ID
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN D.STA_YMD AND D.END_YMD
          AND B.C_CD = E.C_CD(+)
          AND B.ORG_ID = E.ORG_ID(+)
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN E.STA_YMD(+) AND D.END_YMD(+)
          AND A.EMP_ID NOT IN ('201202978',                        -- 공정위 예외처리
                               '200903192',                        -- 공정위 예외처리
                               '200700035',
                               '201100041',
                               '200400032',
                               '201411284',
                               '201411295',
                               '201410994', -- 인사기획팀 등록 고문/자문 숨김처리 2014.04.04 안준휘 과장 요청
                               '201503036',
                               '201503040',
                               '201503051' -- 비상근 자문역 숨김처리. 2015.01.05 김현진 사원 요청
                                          )
          AND 1 =
                 (CASE
                     -- 외주직원중 해외근무자이면서 PC 사용자는 포함 처리. 2015.01.15 김성관
                     WHEN     B.EMP_TYPE IN ('8', 'O', '8H')
                          AND NVL (A.WORK_PLACE_CD, '0010') = '0030' -- 본사:0010, 국내:0020, 해외:0030
                          AND PC_USE_YN = 'Y'
                     THEN
                        1
                     -- 구 현대CnI 예외처리한 외주직원이면서 전문직위를 제외한 모든 외주직원 제외
                     WHEN     B.EMP_TYPE IN ('8', 'O', '8H') -- 구 현대CnI 예외처리한 외주직원이면서 전문직위를 제외한 모든 외주직원 제외
                          AND B.POST_CD NOT LIKE '3%'
                     THEN
                        0
                     ELSE
                        1
                  END)
   -- 퇴직자를 시스템 사용자 사용기간을 처리
   UNION
   SELECT 'HE' COMPANYCD,
          'ko' LANGCD,
          A.EMP_ID SABUN,
          SUBSTR (A.EMP_ID, 3, 7) USERID,
          A.EMP_NM KNAME,
          A.ENG_EMP_NM ENAME,
          A.CHA_EMP_NM SNAME,
          B.POST_CD2 JIKWICD,                             -- hecos 직위 / 호칭직위--
          B.WORK_LOC_ID BUSOCD,
          NULL TEAMCD,
          SUBSTR (A.EMP_ID, 3, 7) JUMINNO,
          A.WORK_LOC_TEL_NO TELOFFICE,
          A.MOBILE_NO TELHOME,
          A.WORK_LOC_FAX FAX,
          A.MAIL_ADDR EMAILID,
          A.VOIP VOIP_TEL,
          DECODE (D.EMP_ID, NULL, '0', '1') ISGROUPWARE,
          DECODE (A.MAIL_ADDR, NULL, '0', '1') ISEMAIL,
          NULL ISEIS,
          SYSDATE CREATEDATE,
          SYSDATE CHANGEDATE,
          C.JOB_TXT BUSINESS,
          F_ORG_NM (B.C_CD,
                    B.STA_YMD,
                    B.ORG_ID,
                    '1')
             ORGSAUP,
          DECODE (B.DUTY_CD, 'ZZ', '', B.DUTY_CD) SITEPOS,
          DECODE (B.DUTY_NM, '직책없음', '', B.DUTY_NM) SITEPOS_NM,
          F_ORG_ID (B.C_CD,
                    B.STA_YMD,
                    B.ORG_ID,
                    '1')
             ORGDEPT,
          SUBSTR (A.MAIL_ADDR, 1, INSTR (A.MAIL_ADDR, '@') - 1) MAILID,
          SUBSTR (A.MAIL_ADDR, INSTR (A.MAIL_ADDR, '@') + 1) MAILDOMAIN,
          NULL MODIFYINFODATE,
          '2' CHILDCOMPANYCD,
          CASE
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 4) = '2166'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 7) = '02-2166'
             THEN
                '2166'
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 4) = '2136'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 7) = '02-2136'
             THEN
                '2166'
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 9) = '82-2-2166'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 10) = '82-02-2166'
             THEN
                '2166'
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 4) = '2134'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 7) = '02-2134'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 6) = '022134'
             --               THEN '2134'
             THEN
                '8833'                    -- 계동사옥 전체 이전전까지 임시변경. 현대CnI 박재형 과장.
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 9) = '82-2-2134'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 10) = '82-02-2134'
             --               THEN '2134'
             THEN
                '8833'                    -- 계동사옥 전체 이전전까지 임시변경. 현대CnI 박재형 과장.
          END
             EXTENSIONNUMBER,
          DECODE (A.EMP_ID,
                  '201004721', 'N',
                  '200903192', 'N',
                  DECODE (SUBSTR (B.ORG_ID, 1, 2), 'OE', 'N', 'Y'))
             DISPLAYYN                              -- 인재개발부 고문/자문 김동혁, 이평호 제외
     FROM PA1010# A,
          PA1020 B,
          PA2170 C,
          PA2261 D
    WHERE     B.EMP_TYPE != 'O'
          AND A.PAY_CALC_EXEC_YN != 'Y'
          AND A.C_CD = B.C_CD
          AND A.EMP_ID = B.EMP_ID
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN B.STA_YMD AND B.END_YMD
          AND B.LAST_YN = 'Y'
          AND B.STAT_CD LIKE '30'
          AND A.EMP_ID = C.EMP_ID(+)
          AND '2' = C.CLASS_CD(+)
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN C.STA_YMD(+)
                                                AND C.END_YMD(+)
          AND '005' = D.USE_SYS(+)
          AND A.EMP_ID = D.EMP_ID
          AND 1 =
                 (CASE
                     WHEN     B.EMP_TYPE IN ('8', 'O', '8H')
                          AND B.POST_CD NOT LIKE '3%'
                     THEN
                        0
                     ELSE
                        1
                  END)
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN D.STA_YMD AND D.END_YMD
          AND A.EMP_ID NOT IN ('201202978')
   -- UC사용가능 외주직원 처리
   UNION
   SELECT 'HE' COMPANYCD,
          'ko' LANGCD,
          A.EMP_ID SABUN,
          SUBSTR (A.EMP_ID, 3, 7) USERID,
          A.EMP_NM KNAME,
          A.ENG_EMP_NM ENAME,
          A.CHA_EMP_NM SNAME,
          B.POST_CD2 JIKWICD,                               -- hecos 직위 / 호칭직위
          B.WORK_LOC_ID BUSOCD,
          NULL TEAMCD,
          SUBSTR (A.EMP_ID, 3, 7) JUMINNO,
          A.WORK_LOC_TEL_NO TELOFFICE,
          A.MOBILE_NO TELHOME,
          A.WORK_LOC_FAX FAX,
          A.MAIL_ADDR EMAILID,
          A.VOIP VOIP_TEL,
          DECODE (D.EMP_ID, NULL, '0', '1') ISGROUPWARE,
          DECODE (A.MAIL_ADDR, NULL, '0', '1') ISEMAIL,
          NULL ISEIS,
          SYSDATE CREATEDATE,
          SYSDATE CHANGEDATE,
          C.JOB_TXT BUSINESS,
          F_ORG_NM (B.C_CD,
                    B.STA_YMD,
                    B.ORG_ID,
                    '1')
             ORGSAUP,
          DECODE (B.DUTY_CD, 'ZZ', '', B.DUTY_CD) SITEPOS,
          DECODE (B.DUTY_NM, '직책없음', '', B.DUTY_NM) SITEPOS_NM,
          F_ORG_ID (B.C_CD,
                    B.STA_YMD,
                    B.ORG_ID,
                    '1')
             ORGDEPT,
          SUBSTR (A.MAIL_ADDR, 1, INSTR (A.MAIL_ADDR, '@') - 1) MAILID,
          SUBSTR (A.MAIL_ADDR, INSTR (A.MAIL_ADDR, '@') + 1) MAILDOMAIN,
          NULL MODIFYINFODATE,
          '2' CHILDCOMPANYCD,
          CASE
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 4) = '2166'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 7) = '02-2166'
             THEN
                '2166'
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 4) = '2136'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 7) = '02-2136'
             THEN
                '2166'
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 9) = '82-2-2166'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 10) = '82-02-2166'
             THEN
                '2166'
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 4) = '2134'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 7) = '02-2134'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 6) = '022134'
             --               THEN '2134'
             THEN
                '8833'                    -- 계동사옥 전체 이전전까지 임시변경. 현대CnI 박재형 과장.
             WHEN    SUBSTR (A.WORK_LOC_TEL_NO, 1, 9) = '82-2-2134'
                  OR SUBSTR (A.WORK_LOC_TEL_NO, 1, 10) = '82-02-2134'
             --               THEN '2134'
             THEN
                '8833'                    -- 계동사옥 전체 이전전까지 임시변경. 현대CnI 박재형 과장.
          END
             EXTENSIONNUMBER,
          DECODE (SUBSTR (B.ORG_ID, 1, 2), 'OE', 'N', 'Y') DISPLAYYN -- 인재개발부 고문/자문 김동혁, 이평호 제외
     FROM PA1010# A,
          PA1020 B,
          PA2170 C,
          PA2261 D,
          PA2263 E
    WHERE     B.EMP_TYPE != 'O'
          AND A.C_CD = B.C_CD
          AND A.EMP_ID = B.EMP_ID
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN B.STA_YMD AND B.END_YMD
          AND B.LAST_YN = 'Y'
          AND B.STAT_CD = '10'
          AND A.EMP_ID = C.EMP_ID(+)
          AND '2' = C.CLASS_CD(+)
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN C.STA_YMD(+)
                                                AND C.END_YMD(+)
          AND '005' = D.USE_SYS(+)
          AND A.EMP_ID = D.EMP_ID(+)
          AND B.EMP_TYPE IN ('8', 'O', '8H')
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN D.STA_YMD(+)
                                                AND D.END_YMD(+)
          AND A.C_CD = E.C_CD
          AND A.EMP_ID = E.EMP_ID
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN E.STA_YMD AND E.END_YMD
/
