CREATE VIEW TP08SITE AS SELECT T1.WK_SITE AS CODEXCD, T1.OBJ_NM AS CODEXMY
     FROM (  SELECT C_CD,
                    OBJ_ID,
                    WK_SITE,
                    OBJ_NM,
                    MAX (STA_YMD) STA_YMD,
                    MAX (END_YMD) END_YMD
               FROM SY3010
              WHERE C_CD = 'HEC' AND OBJ_TYPE = 'WA' AND WK_SITE IS NOT NULL
           GROUP BY C_CD,
                    OBJ_ID,
                    WK_SITE,
                    OBJ_NM) T1,
          OM3010 T2
    WHERE     T1.C_CD = T2.C_CD
          AND T1.OBJ_ID = T2.WORK_LOC_ID(+)
          AND T1.STA_YMD BETWEEN T2.STA_YMD(+) AND T2.END_YMD(+)
/
