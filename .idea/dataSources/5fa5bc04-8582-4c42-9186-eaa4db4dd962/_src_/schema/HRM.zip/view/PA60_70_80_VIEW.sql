CREATE VIEW PA60_70_80_VIEW AS SELECT /*+ RULE */
           P1.SEQ,
            P1.EMP_ID,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0100' THEN TT.OLD_AMT END)
               AS OLD_BASE_MON                                       -- OLD기본급
                              ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0100' THEN TT.OLD_CURRENCY END)
               AS OLD_BASE_CURRENCY                                -- OLD기본급단위
                                   ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0100' THEN TT.NEW_AMT END)
               AS NEW_BASE_MON                                       -- NEW기본급
                              ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0100' THEN TT.NEW_CURRENCY END)
               AS NEW_BASE_CURRENCY                                -- NEW기본급단위
                                   ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0120' THEN TT.OLD_AMT END)
               AS OLD_OT_ALW                                      -- OLD 시간외수당
                            ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0120' THEN TT.OLD_CURRENCY END)
               AS OLD_OT_CURRENCY                                 -- OLD 시간외단위
                                 ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0120' THEN TT.NEW_AMT END)
               AS NEW_OT_ALW                                      -- NEW 시간외단위
                            ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0120' THEN TT.NEW_CURRENCY END)
               AS NEW_OT_CURRENCY                                 -- NEW 시간외단위
                                 ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0410' THEN TT.OLD_AMT END)
               AS OLD_IN_BASE_MON                           -- OLD 국내현장기본수당 수당
                                 ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0410' THEN TT.OLD_CURRENCY END)
               AS OLD_IN_BASE_CURRENCY                      -- OLD 국내현장기본수당 단위
                                      ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0410' THEN TT.NEW_AMT END)
               AS NEW_IN_BASE_MON                              -- NEW 국내현장기본수당
                                 ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0410' THEN TT.NEW_CURRENCY END)
               AS NEW_IN_BASE_CURRENCY                      -- NEW 국내현장기본수당 단위
                                      ,
            CASE
               WHEN WORK_YM <= '201303'
               THEN
                  MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0510' THEN TT.OLD_AMT END)
               ELSE                                          -- OLD 해외지원수당(지사)
                    NVL (
                       MAX (
                          CASE
                             WHEN TT.OLD_PAY_ITEM = 'P0560' THEN TT.OLD_AMT
                          END),
                       0)
                  -- OLD 해외지원수당(현장)
                  + NVL (
                       MAX (
                          CASE
                             WHEN TT.OLD_PAY_ITEM = 'P0550' THEN TT.OLD_AMT
                          END),
                       0)
                  -- OLD 해외근무수당
                  + NVL (
                       MAX (
                          CASE
                             WHEN TT.OLD_PAY_ITEM = 'P0551' THEN TT.OLD_AMT
                          END),
                       0)
            END
               AS OLD_OUT_BASE_ALW                               -- OLD 해외기본수당
                                  ,
            CASE
               WHEN WORK_YM <= '201303'
               THEN
                  MAX (
                     CASE
                        WHEN TT.OLD_PAY_ITEM = 'P0510' THEN TT.OLD_CURRENCY
                     END)
               ELSE                                              -- OLD 해외근무수당
                  MAX (
                     CASE
                        WHEN TT.OLD_PAY_ITEM = 'P0551' THEN TT.OLD_CURRENCY
                     END)
            END
               AS OLD_OUT_BASE_CURRENCY                       -- OLD 해외기본수당 단위
                                       ,
            CASE
               WHEN WORK_YM <= '201303'
               THEN
                  MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0510' THEN TT.NEW_AMT END)
               ELSE                                          -- OLD 해외지원수당(지사)
                    NVL (
                       MAX (
                          CASE
                             WHEN TT.NEW_PAY_ITEM = 'P0560' THEN TT.NEW_AMT
                          END),
                       0)
                  -- OLD 해외지원수당(현장)
                  + NVL (
                       MAX (
                          CASE
                             WHEN TT.NEW_PAY_ITEM = 'P0550' THEN TT.NEW_AMT
                          END),
                       0)
                  -- OLD 해외근무수당
                  + NVL (
                       MAX (
                          CASE
                             WHEN TT.NEW_PAY_ITEM = 'P0551' THEN TT.NEW_AMT
                          END),
                       0)
            END
               AS NEW_OUT_BASE_ALW                               -- NEW 해외기본수당
                                  ,
            CASE
               WHEN WORK_YM <= '201303'
               THEN
                  MAX (
                     CASE
                        WHEN TT.NEW_PAY_ITEM = 'P0510' THEN TT.NEW_CURRENCY
                     END)
               ELSE                                              -- NEW 해외근무수당
                  MAX (
                     CASE
                        WHEN TT.NEW_PAY_ITEM = 'P0551' THEN TT.NEW_CURRENCY
                     END)
            END
               AS NEW_OUT_BASE_CURRENCY                       -- NEW 해외기본수당 단위
                                       --,MAX(CASE WHEN TT.OLD_PAY_ITEM = 'P0510' THEN TT.OLD_AMT      END) AS OLD_OUT_BASE_ALW        -- OLD 해외기본수당
                                       --,MAX(CASE WHEN TT.OLD_PAY_ITEM = 'P0510' THEN TT.OLD_CURRENCY END) AS OLD_OUT_BASE_CURRENCY   -- OLD 해외기본수당 단위

                                       --,MAX(CASE WHEN TT.NEW_PAY_ITEM = 'P0510' THEN TT.NEW_AMT      END) AS NEW_OUT_BASE_ALW        -- NEW 해외기본수당
                                       --,MAX(CASE WHEN TT.NEW_PAY_ITEM = 'P0510' THEN TT.NEW_CURRENCY END) AS NEW_OUT_BASE_CURRENCY   -- NEW 해외기본수당단위



            ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P1207' THEN TT.OLD_AMT END)
               AS OLD_LOCAL_ALW                                   -- OLD 현지불수당
                               ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P1207' THEN TT.OLD_CURRENCY END)
               AS OLD_LOCAL_CURRENCY                            -- OLD 현지불수당단위
                                    ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P1207' THEN TT.NEW_AMT END)
               AS NEW_LOCAL_ALW                                   -- NEW 현지불수당
                               ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P1207' THEN TT.NEW_CURRENCY END)
               AS NEW_LOCAL_CURRENCY                            -- NEW 현지불수당단위
                                    -- P0805사용하면 않됨.... P1209사용해야함
            ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P1209' THEN TT.OLD_AMT END)
               AS OLD_OUT_SINGLE_SUB                              -- OLD해외단신부임
                                    ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P1209' THEN TT.OLD_CURRENCY END)
               AS OLD_OUT_SINGLE_CURRENCY                       -- OLD행회단신부임단위
                                         ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P1209' THEN TT.NEW_AMT END)
               AS NEW_OUT_SINGLE_SUB                              -- NEW해외단신부임
                                    ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P1209' THEN TT.NEW_CURRENCY END)
               AS NEW_OUT_SINGLE_CURRENCY                      -- NEW 행회단신부임단위
                                         ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0520' THEN TT.OLD_AMT END)
               AS OLD_LIMIT_OUT_ALW                              -- OLD 해외오지수당
                                   ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0520' THEN TT.OLD_CURRENCY END)
               AS OLD_LIMIT_OUT_CURRENCY                       -- OLD 해외오지수당단위
                                        ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0520' THEN TT.NEW_AMT END)
               AS NEW_LIMIT_OUT_ALW                              -- NEW 해외오지수당
                                   ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0520' THEN TT.NEW_CURRENCY END)
               AS NEW_LIMIT_OUT_CURRENCY                        -- NEW해외오지수당단위
                                        ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0769' THEN TT.OLD_AMT END)
               AS OLD_ETC_ALW                                      -- OLD 기타수당
                             ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0769' THEN TT.OLD_CURRENCY END)
               AS OLD_ETC_CURRENCY                               -- OLD 기타수당단위
                                  ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0769' THEN TT.NEW_AMT END)
               AS NEW_ETC_ALW                                      -- NEW 기타수당
                             ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0769' THEN TT.NEW_CURRENCY END)
               AS NEW_ETC_CURRENCY                               -- NEW 기타수당단위
                                  ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P9160' THEN TT.OLD_AMT END)
               AS OLD_SANG_PAY                                      -- OLD 상여금
                              ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P9160' THEN TT.OLD_CURRENCY END)
               AS OLD_SANG_PAY_CURRENCY                           -- OLD 상여금단위
                                       ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P9160' THEN TT.NEW_AMT END)
               AS NEW_SANG_PAY                                      -- NEW 상여금
                              ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P9160' THEN TT.NEW_CURRENCY END)
               AS NEW_SANG_PAY_CURRENCY                           -- NEW 상여금단위
                                       ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0804' THEN TT.OLD_AMT END)
               AS OLD_CR_DAN_ALW                                   -- OLD 위험수당
                                ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0804' THEN TT.OLD_CURRENCY END)
               AS OLD_CR_DAN_ALW_CURRENCY                        -- OLD 위험수당단위
                                         ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0804' THEN TT.NEW_AMT END)
               AS NEW_CR_DAN_ALW                                   -- NEW 위험수당
                                ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0804' THEN TT.NEW_CURRENCY END)
               AS NEW_CR_DAN_ALW_CURRENCY                        -- NEW 위험수당단위
                                         ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0560' THEN TT.OLD_AMT END)
               AS OLD_OUT_SUPG_ALW                           -- OLD 해외지원수당(지사)
                                  ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0560' THEN TT.OLD_CURRENCY END)
               AS OLD_OUT_SUPG_CURRENCY                   -- OLD 해외지원수당 단위(지사)
                                       ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0560' THEN TT.NEW_AMT END)
               AS NEW_OUT_SUPG_ALW                           -- NEW 해외지원수당(지사)
                                  ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0560' THEN TT.NEW_CURRENCY END)
               AS NEW_OUT_SUPG_CURRENCY                   -- NEW 해외지원수당 단위(지사)
                                       ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0550' THEN TT.OLD_AMT END)
               AS OLD_OUT_SUPH_ALW                           -- OLD 해외지원수당(현장)
                                  ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0550' THEN TT.OLD_CURRENCY END)
               AS OLD_OUT_SUPH_CURRENCY                   -- OLD 해외지원수당 단위(현장)
                                       ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0550' THEN TT.NEW_AMT END)
               AS NEW_OUT_SUPH_ALW                           -- NEW 해외지원수당(현장)
                                  ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0550' THEN TT.NEW_CURRENCY END)
               AS NEW_OUT_SUPH_CURRENCY                   -- NEW 해외지원수당 단위(현장)
                                       ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0551' THEN TT.OLD_AMT END)
               AS OLD_OUT_WORK_ALW                               -- OLD 해외근무수당
                                  ,
            MAX (CASE WHEN TT.OLD_PAY_ITEM = 'P0551' THEN TT.OLD_CURRENCY END)
               AS OLD_OUT_WORK_CURRENCY                        -- OLD 해외근무수당단위
                                       ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0551' THEN TT.NEW_AMT END)
               AS NEW_OUT_WORK_ALW                               -- NEW 해외근무수당
                                  ,
            MAX (CASE WHEN TT.NEW_PAY_ITEM = 'P0551' THEN TT.NEW_CURRENCY END)
               AS NEW_OUT_WORK_CURRENCY                        -- NEW 해외근무수당단위
       FROM PA6070 P1, PA6080 TT
      WHERE P1.C_CD = 'HEC'
        AND P1.EMP_ID LIKE '%'
        AND P1.WORK_YM LIKE '%'
        AND P1.SEQ = TT.MST_SEQ(+)
   GROUP BY P1.SEQ, P1.EMP_ID, P1.WORK_YM
/
