CREATE VIEW V_ABS_ORG AS SELECT T1.C_CD,
           T1.OBJ_TYPE,
           T1.OBJ_ID,
           T2.OBJ_NM,
           T1.PAR_OBJ_ID,
           T2.STA_YMD,
           T2.END_YMD,
           'Y' AS USE_YN,
           NULL,
           NULL
      FROM (SELECT LEVEL TLEVEL,
                   T1.OBJ_TYPE,
                   T1.OBJ_ID,
                   T1.PAR_OBJ_ID,
                   T1.C_CD,
                   ROWNUM SEQ
              FROM (SELECT T1.* FROM SY3020 T1 WHERE T1.OBJ_TYPE IN (SELECT A.OBJ_TYPE FROM SY3080 A WHERE A.OBJ_TREE_TYPE = 'ORGTREE') AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD AND T1.END_YMD) T1
             START WITH (T1.C_CD, T1.OBJ_TYPE, T1.OBJ_ID) IN
                   (SELECT C_CD,
                          ROOT_OBJ_TYPE,
                          ROOT_OBJ_ID
                     FROM SY3070
                    WHERE OBJ_TREE_TYPE = 'ORGTREE'
                      AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN STA_YMD AND END_YMD)
               AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD AND T1.END_YMD
           CONNECT BY PRIOR T1.C_CD = T1.C_CD
               AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
               AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
             ORDER SIBLINGS BY T1.SEQ_NO) T1,
           SY3010 T2
     WHERE T2.OBJ_TYPE = T1.OBJ_TYPE
       AND T2.OBJ_ID = T1.OBJ_ID
       AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD AND T2.END_YMD
   UNION
   SELECT   T1.C_CD,
            T1.OBJ_TYPE,
            T1.OBJ_ID,
            T1.OBJ_NM,
            T2.PAR_OBJ_ID,
            T1.STA_YMD,
            T1.END_YMD,
            'Y' AS USE_YN,
            T3.WORK_LOC_CLASS_CD,
            F_GET_CODENM (T3.C_CD, 'OM020', T3.WORK_LOC_CLASS_CD)
               WORK_LOC_CLASS_NM
     FROM   SY3010 T1, SY3020 T2, OM3010 T3
    WHERE       T1.C_CD = T2.C_CD
            AND T1.OBJ_TYPE = T2.OBJ_TYPE
            AND T1.OBJ_ID = T2.OBJ_ID
            AND T1.C_CD = T3.C_CD(+)
            AND T1.OBJ_ID = T3.WORK_LOC_ID
            AND T1.OBJ_TYPE = 'WA'
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                  AND  T1.END_YMD
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                  AND  T2.END_YMD
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T3.STA_YMD
                                                  AND  T3.END_YMD
/
COMMENT ON VIEW V_ABS_ORG IS '[ABS_IF용] (V_ABS_ORG)조직정보'
/
