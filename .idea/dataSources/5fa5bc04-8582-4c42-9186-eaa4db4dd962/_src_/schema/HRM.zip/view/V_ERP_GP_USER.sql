CREATE VIEW V_ERP_GP_USER AS SELECT T2.WORK_LOC_ID,
          T1.EMP_ID,
          DECODE (HRM.F_GET_COND_CD2 (T2.C_CD, '/GP18', T2.JOB_CD),
                  'Y', 'Indirect',
                  'Direct')
             EMP_TYPE_CD,
          T1.EMP_FIRST_NM,
          T1.EMP_LAST_NM,
          T1.GENDER_TYPE,
          T1.BIRTH_YMD,
          T2.AGENT_NO,
          T2.TEAM_CD,
          T2.PART_CD,
          T2.CATEGORY_CD,
          T2.JOB_CD,
          T1.NTNL_CD,
          T1.WORK_LOC_TEL_NO,
          (SELECT MIN (STA_YMD)
             FROM GP1020
            WHERE     C_CD = T2.C_CD
                  AND EMP_ID = T2.EMP_ID
                  AND WORK_LOC_ID = T2.WORK_LOC_ID)
             STA_YMD,
          (SELECT MAX (FINISH_YMD)
             FROM GP1020
            WHERE     C_CD = T2.C_CD
                  AND EMP_ID = T2.EMP_ID
                  AND WORK_LOC_ID = T2.WORK_LOC_ID)
             END_YMD,
          T1.PER_MAIL_ADDR,
          BASE64_DE (T1.LOC_ADDR_I18N) LOC_ADDR,
          T3.PSPT_NO, -- HRM.F_HEC_DEC_PSPT(T3.PSPT_NO) AS PSPT_NO -- 암호화 해제시 사용
          T3.STA_YMD PSPT_STA_YMD,
          T3.END_YMD PSPT_END_YMD,
          T4.VISA_TYPE,
          T4.VISA_NO,
          T4.STA_YMD VISA_STA_YMD,
          T4.END_YMD VISA_END_YMD,
          T5.PERMIT_NO,
          T5.STA_YMD PERMIT_STA_YMD,
          T5.END_YMD PERMIT_END_YMD,
          T2.FINISH_RSN,
          T1.INS_USER_ID,
          T1.INS_YMDHMS,
          T1.MOD_USER_ID,
          T1.MOD_YMDHMS
     FROM HRM.GP1010 T1,                                                 -- 인사
          HRM.GP1020 T2,                                                 -- 계약
          (SELECT *
             FROM HRM.GP2180 S1
            WHERE S1.STA_YMD =
                     (SELECT MAX (STA_YMD)
                        FROM HRM.GP2180
                       WHERE     C_CD = S1.C_CD
                             AND EMP_ID = S1.EMP_ID
                             AND STA_YMD <= TO_CHAR (SYSDATE, 'YYYYMMDD')))
          T3,                                                             --여권
          (SELECT *
             FROM HRM.GP2181 S1
            WHERE S1.STA_YMD =
                     (SELECT MAX (STA_YMD)
                        FROM HRM.GP2181
                       WHERE     C_CD = S1.C_CD
                             AND EMP_ID = S1.EMP_ID
                             AND STA_YMD <= TO_CHAR (SYSDATE, 'YYYYMMDD')))
          T4,                                                            -- 비자
          (SELECT *
             FROM HRM.GP2182 S1
            WHERE     S1.PERMIT_TYPE = 'GP'
                  AND S1.STA_YMD =
                         (SELECT MAX (STA_YMD)
                            FROM HRM.GP2182
                           WHERE     C_CD = S1.C_CD
                                 AND EMP_ID = S1.EMP_ID
                                 AND STA_YMD <= TO_CHAR (SYSDATE, 'YYYYMMDD')))
          T5
    WHERE     T1.C_CD = T2.C_CD
          AND T1.EMP_ID = T2.EMP_ID
          AND T2.STA_YMD =
                 (SELECT MAX (STA_YMD)
                    FROM HRM.GP1020
                   WHERE     C_CD = T2.C_CD
                         AND EMP_ID = T2.EMP_ID
                         AND STA_YMD <= TO_CHAR (SYSDATE, 'YYYYMMDD'))
          AND T1.C_CD = T3.C_CD(+)
          AND T1.EMP_ID = T3.EMP_ID(+)
          AND T1.C_CD = T4.C_CD(+)
          AND T1.EMP_ID = T4.EMP_ID(+)
          AND T1.C_CD = T5.C_CD(+)
          AND T1.EMP_ID = T5.EMP_ID(+)
/
COMMENT ON VIEW V_ERP_GP_USER IS 'HRM 해외노무인력 데이터 연계 (사원)'
/
