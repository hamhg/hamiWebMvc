CREATE VIEW V_EPMS_ORG AS SELECT T1.C_CD,
                     t1.obj_type,
                     T1.OBJ_ID,
                     (SELECT OBJ_NM
                        FROM SY3010
                       WHERE     OBJ_ID =
                                    NVL (
                                       (SELECT ORG_ID
                                          FROM OM3010
                                         WHERE     WORK_LOC_ID = T1.OBJ_ID
                                               AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN STA_YMD
                                                                                     AND END_YMD),
                                       T1.OBJ_ID)
                             AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN STA_YMD
                                                                   AND END_YMD)
                        AS OBJ_NM,
                     (SELECT SMR_OBJ_NM
                        FROM SY3010
                       WHERE     OBJ_ID =
                                    NVL (
                                       (SELECT ORG_ID
                                          FROM OM3010
                                         WHERE     WORK_LOC_ID = T1.OBJ_ID
                                               AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN STA_YMD
                                                                                     AND END_YMD),
                                       T1.OBJ_ID)
                             AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN STA_YMD
                                                                   AND END_YMD)
                        AS SMR_OBJ_NM,
                     T1.PAR_OBJ_ID,
                     'Y' AS USE_YN,
                     ROWNUM AS DP_ORDER
                FROM (SELECT T1.*
                        FROM SY3020 T1
                       WHERE     T1.OBJ_TYPE IN (SELECT A.OBJ_TYPE
                                                   FROM SY3080 A
                                                  WHERE A.OBJ_TREE_TYPE IN ('ORGTREE',
                                                                            'WATREE'))
                             AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                   AND T1.END_YMD) T1
          START WITH     1 = 1
                     AND (T1.C_CD, T1.OBJ_TYPE, T1.OBJ_ID) IN (SELECT C_CD,
                                                                      ROOT_OBJ_TYPE,
                                                                      ROOT_OBJ_ID
                                                                 FROM SY3070
                                                                WHERE     OBJ_TREE_TYPE IN ('ORGTREE',
                                                                                            'WATREE')
                                                                      AND TO_CHAR (
                                                                             SYSDATE,
                                                                             'YYYYMMDD') BETWEEN STA_YMD
                                                                                             AND END_YMD)
                     AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                           AND T1.END_YMD
          CONNECT BY     1 = 1
                     AND PRIOR T1.C_CD = T1.C_CD
                     AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
                     AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
   ORDER SIBLINGS BY T1.SEQ_NO
/
