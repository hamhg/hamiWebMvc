CREATE VIEW EMP_RETIRE AS SELECT   T1.EMP_ID EMPNO,
            T1.EMP_NM NAME_KO,
            F_GET_CODENM (T2.C_CD, '/SY04', T2.POST_CD) POSITION_NAME,
            F_GET_CODENM (T1.C_CD, '00090', T1.LOC_CD) WORK_SITE_LOCATION,
            '' G_NO,
            '' D_No,
            T2.POST_CD POSITION_CD,
            T2.WORK_LOC_ID WORK_SITE_CD,
            T1.TEL_NO TEL_RESIDENCE,
            T1.WORK_LOC_TEL_NO WORK_SITE_TEL,
            T1.MOBILE_NO TEL_CELLULARPHONE,
            '' HECOS_YN
     FROM   PA1010# T1,
            PA1020 T2,
            PA2010 T3,
            (  SELECT   C_CD, EMP_ID, MAX (END_YMD) MAX_END_YMD
                 FROM   PA2261
                WHERE   USE_SYS = '002'
             GROUP BY   C_CD, EMP_ID) T4
    WHERE   T2.C_CD = T1.C_CD AND T2.EMP_ID = T1.EMP_ID
            AND TO_CHAR (SYSDATE + 1, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                      AND  T2.END_YMD
            AND T2.STAT_CD LIKE '1%'
            AND T2.LAST_YN = 'Y'
            AND T3.C_CD(+) = T1.C_CD
            AND T3.EMP_ID(+) = T1.EMP_ID
            AND T3.ADDR_CD(+) = '003'
            AND T4.C_CD = T1.C_CD
            AND T4.EMP_ID = T1.EMP_ID
            AND T2.EMP_TYPE NOT IN ('O', 'P', '8', '8P', '8H')
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') > T4.MAX_END_YMD
/
COMMENT ON VIEW EMP_RETIRE IS '[HECOS_IF용] (EMP_RETIRE)인사정보(퇴직)'
/
