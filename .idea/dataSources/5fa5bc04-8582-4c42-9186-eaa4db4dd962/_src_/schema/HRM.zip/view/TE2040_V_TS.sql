CREATE VIEW TE2040_V_TS AS SELECT   (SELECT   HRM.F_TE_GET_CLASS (T1.C_CD, T1.EDU_GRP_ID, T1.STA_YMD)
               FROM   DUAL)
               AS IO_TYPE,
            T1.EDU_GRP_ID,
            T1.EDU_GRP_NM,
            T1.EDU_CURRI_ID,
            T1.EDU_CURRI_NM,
            T1.EMP_ID,
            T1.STA_YMD,
            T1.END_YMD,
            T2.EDU_PROJECT_CD,
            NVL(T2.EDU_MTH_CD, '0030')
     FROM   HRM.TE2040 T1, HRM.TE3020 T2
    WHERE   T1.C_CD = T2.C_CD(+) AND T1.EDU_CURRI_ID = T2.EDU_CURRI_ID(+)
/
COMMENT ON VIEW TE2040_V_TS IS '[구ERP/SAP_IF용] (TE2040_V_TS)'
/
