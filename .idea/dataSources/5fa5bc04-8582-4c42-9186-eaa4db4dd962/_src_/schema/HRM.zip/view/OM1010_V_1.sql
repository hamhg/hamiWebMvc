CREATE VIEW OM1010_V_1 AS SELECT T1.C_CD,
          T1.OBJ_ID ORG_ID,
          F_GET_OBJNM (T1.C_CD,
                       T1.OBJ_TYPE,
                       T1.OBJ_ID,
                       TO_CHAR (SYSDATE, 'YYYYMMDD'))
             ORG_NM,
          CASE T1.PAR_OBJ_TYPE WHEN 'O' THEN T1.PAR_OBJ_ID END UP_ORG_ID,
          CASE T1.PAR_OBJ_TYPE
             WHEN 'O'
             THEN
                F_GET_OBJNM (T1.C_CD,
                             T1.PAR_OBJ_TYPE,
                             T1.PAR_OBJ_ID,
                             TO_CHAR (SYSDATE, 'YYYYMMDD'))
          END
             UP_ORG_NM,
          T1.TLEVEL,
          T1.DP_ORDER,
          T1.STA_YMD,
          T1.END_YMD,
          T2.ORG_GRP_CD,
          T2.ORG_CLASS,
          T2.INOUT_CD,
          T2.DNIND_CLASS,
          T2.PAY_AREA_CD,
          T2.BIZPL_CD,
          T2.CC_CD,
          T2.LOC_CD,
          T3.EMP_ID,
          T3.MGR_CLASS
     FROM (           SELECT T1.C_CD,
                             T1.OBJ_TYPE,
                             T1.OBJ_ID,
                             T1.PAR_OBJ_TYPE,
                             T1.PAR_OBJ_ID,
                             T1.STA_YMD,
                             T1.END_YMD,
                             T1.SEQ_NO,
                             LEVEL AS TLEVEL,
                             ROWNUM AS DP_ORDER
                        FROM (SELECT T1.C_CD,
                                     T1.OBJ_TYPE,
                                     T1.OBJ_ID,
                                     T1.PAR_OBJ_TYPE,
                                     T1.PAR_OBJ_ID,
                                     T1.STA_YMD,
                                     T1.END_YMD,
                                     T1.SEQ_NO
                                FROM SY3020 T1
                               WHERE     (T1.C_CD, T1.OBJ_TYPE) IN
                                            (SELECT A.C_CD, A.OBJ_TYPE
                                               FROM SY3080 A
                                              WHERE A.OBJ_TREE_TYPE = 'ORGTREE')
                                     AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                           AND T1.END_YMD) T1
                  START WITH     1 = 1
                             AND (T1.C_CD, T1.OBJ_TYPE, T1.OBJ_ID) IN
                                    (SELECT A.C_CD, A.ROOT_OBJ_TYPE, A.ROOT_OBJ_ID
                                       FROM SY3070 A
                                      WHERE     1 = 1
                                            AND A.OBJ_TREE_TYPE = 'ORGTREE'
                                            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN A.STA_YMD
                                                                                  AND A.END_YMD)
                             AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                   AND T1.END_YMD
                             AND (T1.C_CD, T1.PAR_OBJ_TYPE) IN
                                    (SELECT A.C_CD, A.OBJ_TYPE
                                       FROM SY3080 A
                                      WHERE A.OBJ_TREE_TYPE = 'ORGTREE')
                  CONNECT BY     1 = 1
                             AND PRIOR T1.C_CD = T1.C_CD
                             AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
                             AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
                             AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                   AND T1.END_YMD
           ORDER SIBLINGS BY T1.C_CD, T1.SEQ_NO) T1,                   -- 조직관계
          OM0010 T2,                                                 -- 조직정보이력
          OM0020 T3                                                   -- 조직장이력
    WHERE     1 = 1
          AND T2.C_CD(+) = T1.C_CD
          AND T2.ORG_ID(+) = T1.OBJ_ID
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD(+)
                                                AND T2.END_YMD(+)
          AND T3.C_CD(+) = T1.C_CD
          AND T3.ORG_ID(+) = T1.OBJ_ID
          AND T3.ROLE_CD(+) = '01'
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T3.STA_YMD(+)
                                                AND T3.END_YMD(+)
/
COMMENT ON VIEW OM1010_V_1 IS '(OM1010_V_1)'
/
