CREATE VIEW INSACOMPANYTBL AS SELECT   '2' CompanyCD,
            'ko' LangCD,
            '현대엔지니어링(주)' CompanyNM,
            'HYUNDAI ENGINEERING CO,. LTD' CompanyENM,
            NULL CompanySNM,
            2 SortOrder
     FROM   DUAL
/
COMMENT ON VIEW INSACOMPANYTBL IS '[IM_IF용] (INSACOMPANYTBL)HEC회사정보'
/
