CREATE VIEW INSABOJIKTBL AS SELECT   'HE' CompanyCD,
              'ko' LangCD,
              CD SitePOS,
              CD_NM SitePos_NM,
              NULL ESitePos_NM,
              NULL SSitePos_NM,
              DP_ORDER SortOrder
       FROM   SY5020
      WHERE   IDX_CD = '/SY05' AND CD <> 'ZZ'
   ORDER BY   DP_ORDER
/
COMMENT ON VIEW INSABOJIKTBL IS '[IM_IF용] (INSABOJIKTBL)직책_코드테이블'
/
