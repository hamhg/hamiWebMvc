CREATE VIEW INSAEXTRAEMPLOYEETBL AS SELECT '2' CompanyCD,
          'ko' LangCD,
          a.emp_id Sabun,
          SUBSTR (a.emp_id, 3, 7) UserID,
          a.emp_nm KName,
          a.eng_emp_nm EName,
          NULL SName,
          e.cond_cd1 JikwiCD,
          B.WORK_LOC_ID BUSOCD,
          NULL TeamCD,
          SUBSTR (F_HEC_DEC_PER (a.per_no), 7) JuminNO,
          a.office_tel_no TelOffice,
          a.mobile_no TelHome,
          a.work_loc_fax Fax,
          a.mail_addr EmailID,
          a.voip VOIP_TEL,
          DECODE (d.emp_id, NULL, '0', '1') isGroupware,
          DECODE (d.emp_id, NULL, '0', '1') isEmail,
          NULL isEis,
          SYSDATE CreateDate,
          SYSDATE ChangeDate,
          c.job_txt Business,
          f_org_nm (b.c_cd,
                    b.sta_ymd,
                    b.org_id,
                    '1')
             OrgSaup,
          NULL SitePos,
          NULL SitePos_NM,
          f_org_id (b.c_cd,
                    b.sta_ymd,
                    b.org_id,
                    '1')
             OrgDept,
          SUBSTR (a.mail_addr, 1, INSTR (a.mail_addr, '@') - 1) MailID,
          SUBSTR (a.mail_addr, INSTR (a.mail_addr, '@') + 1) MailDomain,
          NULL MOdifyInfoDate,
          'HE' ChildCompanyCD,
          NULL ExtensionNumber,
          'Y' DisplayYN,
          SYSDATE UseEndDate,
          NULL ChangeFlagAD
     FROM pa1010# a,
          pa1020 b,
          pa2170 c,
          pa2261 d,
          sy5020 e
    WHERE     a.emp_type = 'O'
          AND a.c_cd = b.c_cd
          AND a.emp_id = b.emp_id
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN b.sta_ymd AND b.end_ymd
          AND b.last_yn = 'Y'
          AND b.stat_cd LIKE '1%'
          AND a.emp_id = c.emp_id(+)
          AND '2' = c.class_cd(+)
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN c.sta_ymd(+)
                                                AND c.end_ymd(+)
          AND '002' = d.use_sys(+)
          AND a.emp_id = d.emp_id(+)
          AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN d.sta_ymd(+)
                                                AND d.end_ymd(+)
          AND e.idx_cd = '/SY04'
          AND b.post_cd = e.cd(+)
/
COMMENT ON VIEW INSAEXTRAEMPLOYEETBL IS '[IM_IF용] (INSAEXTRAEMPLOYEETBL)예외자정보'
/
