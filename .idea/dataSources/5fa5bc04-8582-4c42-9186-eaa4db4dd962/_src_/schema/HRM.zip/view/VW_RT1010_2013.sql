CREATE VIEW VW_RT1010_2013 AS SELECT T1.C_CD,
          T1.PAYROLL_NO,
          T1.EMP_ID,
          SUBSTR (
             CASE WHEN T1.ADJ_TYPE = '1' THEN T1.END_YMD ELSE T1.ADJ_YMD END,
             1,
             4)
             AS ADJ_YY,   --정산년도 2013 수정 중간정산은 지급일기준, 퇴직정산은 퇴직일 기준 (HCG 패치 기준)
          T1.ADJ_YMD,                                       --정산일자 (HCG 패치 기준)
          --SUBSTR (T1.END_YMD, 1, 4) ADJ_YY,     --정산년도(HEC 자체수정 - 정산년도가 종료일기준. VW_RT1010)
          --T1.END_YMD,                           --정산일자(HEC 자체수정 - 정산일자가 종료일기준. VW_RT1010)
          'Y' CONF_YN,                                                  --확정여부
          --【소득자】
          T1.OFR_YN,                                                    --임원여부
          T1.TRANS_OFR_YN,  --#(HEC자체수정) [2015.03.07] 지급명세서 전용 (등기임원 또는 임원퇴직소득금액한도초과액 존재자에 한해)
          T1.RET_PNS_STA_YMD,                              --⑩확정급여형 퇴직연금제도 가입일
          T1.OFR_RET_MON_LIMIT_EXCE_MON,                      --⑪2011.12.31퇴직금
          -----------------
          GREATEST (
                SUBSTR (
                   CASE
                      WHEN T1.ADJ_TYPE = '1' THEN T1.END_YMD
                      ELSE T1.ADJ_YMD
                   END,
                   1,
                   4)
             || '0101',
             T1.STA_YMD)
             ORGN_STA_YMD,                                --귀속연도 시작연월일 2013 수정
          CASE WHEN T1.ADJ_TYPE = '1' THEN T1.END_YMD ELSE T1.ADJ_YMD END
             ORGN_END_YMD,                                --귀속연도 종료연월일 2013 수정
          --T1.RET_RSN_CD,                                              --퇴직사유코드
          F_GET_COND_CD2 (T1.C_CD, '00230', T1.RET_RSN_CD) AS RET_RSN_CD, --퇴직사유코드(HEC 자체수정)
          --【퇴직급여현황 - 최종분】
          T1.RET_MON,                                                  --⑮퇴직급여
          T1.NTAX_MON,                                             --16비과세퇴직급여
          T1.TAX_RET_MON,                                         --17과세대상퇴직급여
          --【근속연수-최종】
          T1.ENTER_YMD,                                                --18입사일
          T1.STA_YMD,                                                  --19기산일
          T1.END_YMD,                                                  --20퇴사일
          T1.PAY_YMD,                                                  --21지급일
          T1.SNRT_M_CNT,                                              --22근속월수
          T1.EXCE_M_CNT,                                              --23제외월수
          T1.GRT_ADD_M_CNT AS ADD_M_CNT,                              --24가산월수
          T1.SNRT_Y_CNT,                                              --26근속연수
          --【근속연수-정산】
          T1.ADJ_STA_YMD,                                              --19기산일
          T1.ADJ_END_YMD,                                              --20퇴사일
          T1.ADJ_SNRT_M_CNT,                                          --22근속월수
          T1.ADJ_EXCE_M_CNT,                                          --23제외월수
          T1.ADJ_ADD_M_CNT,                                           --24가산월수
          T1.ADJ_DUP_M_CNT,                                           --25중복월수
          T1.ADJ_SNRT_Y_CNT,                                          --26근속연수
          --【근속연수-안분-2012.12.31이전】
          T1.STA_YMD_12,                                               --19기산일
          T1.END_YMD_12,                                               --20퇴사일
          T1.SNRT_M_CNT_12,                                           --22근속월수
          T1.EXCE_M_CNT_12,                                           --23제외월수
          T1.ADD_M_CNT_12,                                            --24가산월수
          T1.SNRT_Y_CNT_12,                                           --26근속연수
          --【근속연수-안분-2013.1.1이후】
          T1.STA_YMD_13,                                               --19기산일
          T1.END_YMD_13,                                               --20퇴사일
          T1.SNRT_M_CNT_13,                                           --22근속월수
          T1.EXCE_M_CNT_13,                                           --23제외월수
          T1.ADD_M_CNT_13,                                            --24가산월수
          T1.SNRT_Y_CNT_13,                                           --26근속연수
          --【이연퇴직소득세액계산】
          T1.TAX_DEFER_BIZ_PER_NM,                                  -- 연금계좌취급자
          T1.TAX_DEFER_BIZ_NO,                                      -- 사업자등록번호
          T1.TAX_DEFER_ACC_NO,                      -- 계좌번호 (# [HEC]암호화된 컬럼 #)
          T1.TAX_DEFER_TRANS_YMD,                                        --입금일
          T1.ACC_DEFER_MON                                          --40계좌입금금액
     FROM RT1010# T1
    WHERE     T1.ADJ_TYPE IN ('1', '2')
          AND (T1.RET_MON > 0 OR T1.RET_PNS_TAX_ALLONE_MON > 0) --(HEC 자체수정. VW_RT1010) 퇴직금이 있는 대상자만 조회
          AND T1.COM_MOV_YN = 'N'         --(HEC 자체수정. VW_RT1010) 전출자는 대상에서 제외
          --===================================================================
          --//[2015.02.10] 임금피크제 적용 대상자 제외
          --    중간정산(ADJ_TYPE = '2')로 정산 진행한 대상 제외
          --===================================================================
          AND 1 = CASE
                     WHEN     T1.ADJ_TYPE = '2'
                          AND T1.END_YMD = '20141231'
                          AND T1.EMP_ID IN ('199933839'                  --김태봉
                                                       ,
                                            '200703063'                  --김원동
                                                       ,
                                            '199927379'                  --김장평
                                                       ,
                                            '201438253'                  --임종빈
                                                       ,
                                            '200704720'                  --한기창
                                                       ,
                                            '200704641'                  --양승철
                                                       ,
                                            '199926009'                  --최성현
                                                       ,
                                            '199923459'                  --정창용
                                                       ,
                                            '201000930'                  --손기택
                                                       ,
                                            '199910129'                  --이현식
                                                       ,
                                            '199936469'                  --최강진
                                                       ,
                                            '199911779'                  --김덕규
                                                       ,
                                            '201000952'                  --김익태
                                                       ,
                                            '200703932'                  --고광원
                                                       ,
                                            '201436554'                  --김완기
                                                       ,
                                            '201007390'                  --원영하
                                                       ,
                                            '201117875'                  --김종덕
                                                       ,
                                            '200500394'                  --손대익
                                                       )
                     THEN
                        0
                     ELSE
                        1
                  END
          --===================================================================
          -- 퇴직금이거나 동년 마지막중간정산인거
          AND (   T1.ADJ_TYPE = '1'
               OR NOT EXISTS
                     (SELECT 1
                        FROM RT1010# A
                       WHERE     A.C_CD = T1.C_CD
                             AND A.EMP_ID = T1.EMP_ID
                             AND A.ADJ_TYPE IN ('1', '2')
                             AND A.PAYROLL_NO <> T1.PAYROLL_NO
                             AND A.ADJ_YMD BETWEEN CASE
                                                      WHEN T1.ADJ_TYPE = '1'
                                                      THEN
                                                         T1.END_YMD
                                                      ELSE
                                                         T1.ADJ_YMD
                                                   END
                                               AND    SUBSTR (
                                                         CASE
                                                            WHEN T1.ADJ_TYPE =
                                                                    '1'
                                                            THEN
                                                               T1.END_YMD
                                                            ELSE
                                                               T1.ADJ_YMD
                                                         END,
                                                         1,
                                                         4)
                                                   /*
                                                      --(HEC 자체수정 - 정산년도가 종료일기준. VW_RT1010)
                                                      AND A.END_YMD BETWEEN T1.END_YMD AND SUBSTR(T1.END_YMD, 1, 4)
                                                   */
                                                   || '1231'))
/
