CREATE VIEW V_IM_USER_TEST AS SELECT 'HEC' COMPANY_CD                                             -- 회사코드
                          ,
          T1.EMP_ID EMP_ID                                               -- 사번
                          ,
          T1.EMP_NM EMP_NM                                              -- 사원명
                          ,
          T1.ENG_EMP_NM ENG_EMP_NM                                    -- 영문사원명
                                  ,
          T1.CHA_EMP_NM,
          T1.MOBILE_NO MOBILE_NO                                       -- 이동전화
                                ,
          T1.MAIL_ADDR MAIL_ADDR                                       -- 메일주소
                                ,
          T1.WORK_LOC_TEL_NO WORK_LOC_TEL_NO                          -- 근무지전화
                                            ,
          REGEXP_REPLACE (T1.WORK_LOC_FAX, '[[:cntrl:] ]', '') WORK_LOC_FAX -- 근무지FAX
                                                                           ,
          REGEXP_REPLACE (T1.TEL_NO, '[[:cntrl:] ]', '') TEL_NO,
          CASE
             WHEN T1.EMP_ID = '201443971'
             THEN
                '20150630'                    -- 15.06.30 송일영 과장 요청으로 퇴직발령전 처리
             WHEN     TO_CHAR (SYSDATE, 'YYYYMMDD') >
                         NVL (T8.RETIRE_YMD, '99991231')
                  AND T8.HOLD_TYPE = '09'
             THEN
                T8.RETIRE_YMD -- 퇴직예정일이 현재일보다 작으면 퇴직으로 처리. 2015.08.27 정보보안워킹그룸, 인력운영팁 협의
             WHEN T2.EMP_TYPE IN ('8','8H') AND T10.CNT = 0 AND NVL(T10.MAX_END_YMD,'99991231') < TO_CHAR(SYSDATE,'YYYYMMDD')
             THEN NVL(T1.RETIRE_YMD,T10.MAX_END_YMD)   -- 외주, 외주협력이고 현재 유효한계약 레코드가 없으면 최종계약종료일을 퇴사일로 넘긴다.
             ELSE
                T1.RETIRE_YMD
          END
             RETIRE_DATE,
          --  T1.RETIRE_YN RETIRE_YN                                 -- 퇴사여부
          CASE
             -- 재직상태가 퇴사인 경우
             WHEN T2.STAT_CD = '30'
             THEN
                'Y'
             -- 15.06.30 송일영 과장 요청으로 퇴직발령전 처리
             WHEN T1.EMP_ID IN ('201443971')
             THEN
                'Y' 
             -- 퇴직예정일이 현재일보다 작으면 퇴직으로 처리. 2015.08.27 정보보안워킹그룸, 인력운영팁 협의                          
             WHEN     TO_CHAR (SYSDATE, 'YYYYMMDD') >
                         NVL (T8.RETIRE_YMD, '99991231')
                  AND T8.HOLD_TYPE = '09'
             THEN
                'Y' 
             -- 외주/외주협력이면서 계약기간이 종료된 경우 퇴직 처리. 
             WHEN T2.EMP_TYPE IN ('8','8H') AND T10.CNT = 0 AND NVL(T10.MAX_END_YMD,'99991231') < TO_CHAR(SYSDATE,'YYYYMMDD') 
             THEN 'Y'
             ELSE
                'N'
          END
             RETIRE_YN,
          T2.DUTY_CD DUTY_CD                                           -- 직책코드
                            ,
          -- 직군통합에 따라 실제 직위코드 기준으로 송부. 2014.07.28 공인식 과장 확인
          --CASE WHEN T2.EMP_TYPE = 'M' THEN 'XX' ELSE T2.POST_CD END POST_CD -- 직위코드
          T2.POST_CD POST_CD,                                          -- 직위코드
          T2.POST_CD2 POST_CD2,                                      -- 호칭직위코드
          T2.WORK_LOC_ID WORK_LOC_ID                                -- 발령근무지ID
                                    ,
          T2.EMP_TYPE EMP_TYPE                                         -- 사원유형
                              ,
          NVL (
             (SELECT OBJ_NM
                FROM OM3010 S1, SY3010 S2
               WHERE     S1.C_CD = S2.C_CD
                     AND S1.ORG_ID = S2.OBJ_ID
                     AND S1.C_CD = T2.C_CD
                     AND S1.WORK_LOC_ID = T2.WORK_LOC_ID
                     AND S1.WORK_LOC_CLASS_CD = '1'
                     AND ROWNUM = 1),
             T2.WORK_LOC_NM)
             AS WORK_LOC_NM                                          -- 발령근무지명
                           ,
          CASE
             WHEN T1.EMP_ID LIKE 'AUDIT%' THEN T1.EMP_ID
             ELSE SUBSTR (T1.EMP_ID, 3)
          END
             EMP_ID7                                            -- 사용자 ID(7자리)
                    ,
          -- 직군통합에 따라 실제 직위코드 기준으로 송부. 2014.07.28 공인식 과장 확인
          --CASE WHEN T2.EMP_TYPE = 'M' THEN '' ELSE T2.POST_NM END POST_NM -- 직위명
          T2.POST_NM POST_NM                                            -- 직위명
                            ,
          F_GET_CODENM (T1.C_CD, '00090', T1.WORK_PLACE_NM) WORK_PLACE_NM -- 근무위치
                                                                         ,
          T1.WORK_PLACE_NM AS WORK_PLACE_CD,
          T2.DUTY_NM DUTY_NM                                            -- 직책명
                            --,HRM.F_ORG_CD(T2.C_CD, T2.STA_YMD, T2.ORG_ID, '1') ORG_ID1
          ,
          F_ORG_NM (
             T2.C_CD,
             DECODE (T2.APPNT_CD,
                     '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                     T2.STA_YMD),
             T2.ORG_ID,
             '6')
             ORG_ID1                                                   --본부 ID
                    ,
          -- T5.G_NAME_KO ORG_NM1
          HRM.F_ORG_NM (T2.C_CD,
                        T2.STA_YMD,
                        T2.ORG_ID,
                        '1')
             ORG_NM1,
          NVL (
             F_ORG_NM (
                T2.C_CD,
                DECODE (T2.APPNT_CD,
                        '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                        T2.STA_YMD),
                T2.ORG_ID,
                '7'),
             '')
             ORG_ID2,
          -- T5.B_NAME_KO ORG_NM2
          NVL (HRM.F_ORG_NM (T2.C_CD,
                             T2.STA_YMD,
                             T2.ORG_ID,
                             '2'),
               '')
             ORG_NM2,
          /*
                               CASE
             WHEN SUBSTR (T2.ORG_ID, 1, 2) = 'OE'
             THEN
                T2.ORG_ID
             WHEN T2.ORG_ID = 'O000001285' -- 제철사업관리실은 팀 ID도 관리실 ID로 리턴. 2014.04.18 김성관
             THEN
                T2.ORG_ID
             ELSE
                F_ORG_NM (
                   T2.C_CD,
                   DECODE (T2.APPNT_CD,
                           '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                           T2.STA_YMD),
                   T2.ORG_ID,
                   '8')
          END
          */
          -- ORG_ID3은 예외처리 없이 최종 노드 ID 리턴. 2015.10.08
          T2.ORG_ID ORG_ID3,
          --T5.D_NAME_KO ORG_NM3,
          CASE
             WHEN T2.ORG_ID = 'O000001285' -- 제철사업관리실은 팀 ID도 관리실 ID로 리턴. 2014.04.18 김성관
             THEN
                HRM.F_ORG_NM (T2.C_CD,
                              T2.STA_YMD,
                              T2.ORG_ID,
                              '2')
             ELSE
                NVL (HRM.F_ORG_NM (T2.C_CD,
                                   T2.STA_YMD,
                                   T2.ORG_ID,
                                   '3'),
                     T2.ORG_NM)
          END
             ORG_NM3,
          --(SELECT LPAD (TO_CHAR (DP_ORDER), 5, '0')
          --   FROM SY5020
          --  WHERE C_CD = T1.C_CD AND CD = T2.POST_CD2 AND IDX_CD = '00100') -- 호칭직위에 대한 정렬 제공
          --   POST_NO,
          LPAD (
             TO_CHAR (
                F_GET_EMP_LIST_DP_ORDER (T2.C_CD, T2.POST_CD2, T2.DUTY_CD)),
             5,
             '0')
             AS POST_NO,                       --//[2014.08.01] HECOS측 요청으로 변경
          F_GET_CODENM (T2.C_CD,
                        '00101',
                        F_GET_COND_CD1 (T2.C_CD, '00100', T2.POST_CD2))
             AS POST_NM_SMR,
          (SELECT ENG_NM
             FROM SY5020
            WHERE C_CD = T1.C_CD AND CD = T2.POST_CD2 AND IDX_CD = '00100') -- 호칭직위에 대한 영문제공
             POST_NM_EN,
          '' G_NO,
          '' B_NO,
          '' D_NO,
          /*
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        CASE
                            WHEN PAR_OBJ_ID IN ('WG00000003', 'WG00000004') THEN '현장'
                            ELSE '본사'
                         END AS WORK_GUBUN,
             */
          CASE
             WHEN T1.ENTER_YMD > TO_CHAR (SYSDATE, 'YYYYMMDD') -- AD 사전연동자들은 본사로 전달.
             THEN
                '본사'
             WHEN (SELECT ZZ.WORK_LOC_CLASS_CD
                     FROM OM3010 ZZ
                    WHERE     ZZ.WORK_LOC_ID = T2.WORK_LOC_ID
                          AND T2.STA_YMD BETWEEN ZZ.STA_YMD AND ZZ.END_YMD) IN ('3',
                                                                                '4')
             THEN
                '현장'
             ELSE
                '본사'
          END
             AS WORK_GUBUN,
          (SELECT MAX (A.STA_YMD) ORG_STA_YMD
             FROM SY3010 A
            WHERE     A.C_CD = T2.C_CD
                  AND A.OBJ_TYPE LIKE 'O%'
                  AND A.OBJ_ID = T2.ORG_ID
                  AND DECODE (T2.APPNT_CD,
                              '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                              T2.STA_YMD) BETWEEN A.STA_YMD
                                              AND A.END_YMD)
             AS ORG_STA_YMD,
          T6.POSTAL_CD,
          T6.ADDRESS,
          (SELECT MAX (A.STA_YMD) WORK_LOC_STA_YMD
             FROM SY3010 A
            WHERE     A.C_CD = T2.C_CD
                  AND A.OBJ_TYPE LIKE 'WA%'
                  AND A.OBJ_ID = T2.WORK_LOC_ID
                  AND DECODE (T2.APPNT_CD,
                              '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                              T2.STA_YMD) BETWEEN A.STA_YMD
                                              AND A.END_YMD)
             AS WORK_LOC_STA_YMD,
          T2.STAT_CD STAT_CD,
          CASE
             WHEN EXISTS
                     (SELECT 1
                        FROM PA2261
                       WHERE     C_CD = T2.C_CD
                             AND EMP_ID = T2.EMP_ID
                             AND USE_SYS = '003'
                             AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN STA_YMD
                                                                   AND END_YMD)
             THEN
                'Y'
             ELSE
                'N'
          END
             ERP_USE_YN,
          T7.ALTERNATE_KEY,
          CASE
             WHEN T2.STAT_CD = '30'
             THEN
                '4'
             WHEN     TO_CHAR (SYSDATE, 'YYYYMMDD') >
                         NVL (T8.RETIRE_YMD, '99991231')
                  AND T8.HOLD_TYPE = '09'
             THEN
                '4' -- 퇴직예정일이 현재일보다 작으면 퇴직으로 처리. 2015.08.27 정보보안워킹그룸, 인력운영팁 협의
             WHEN T2.STAT_CD = '13'
             THEN
                '2'
             WHEN T2.STAT_CD = '10' AND T8.EMP_ID IS NOT NULL
             THEN
                '5'
             WHEN T2.STAT_CD = '10'
             THEN
                '1'
             ELSE
                ''
          END
             EMP_STATUS,
          CASE
             WHEN T2.STAT_CD = '30'
             THEN
                '4'
             WHEN     TO_CHAR (SYSDATE, 'YYYYMMDD') >
                         NVL (T8.RETIRE_YMD, '99991231')
                  AND T8.HOLD_TYPE = '09'
             THEN
                '4' -- 퇴직예정일이 현재일보다 작으면 퇴직으로 처리. 2015.08.27 정보보안워킹그룸, 인력운영팁 협의
             WHEN T2.STAT_CD LIKE '1%' AND T8.EMP_ID IS NOT NULL
             THEN
                '5'
             WHEN T2.STAT_CD LIKE '1%'
             THEN
                '1'
             ELSE
                ''
          END
             RETIRE_STATUS,
          'HEC' COMPANY_NM,                                             -- 회사명
          OUT_MAIL_ADDR                                              -- 외부메일주소
                       ,
          F3.JOB_TXT JOB_NM
     FROM PA1010# T1,
          PA1020 T2,
          PA2010 T3,
          (SELECT T1.C_CD,
                  T1.EMP_ID,
                  T1.STA_YMD,
                  T1.END_YMD,
                  T1.JOB_TXT
             FROM PA2170 T1
            WHERE     T1.C_CD = 'HEC'
                  AND (   ('3' = '4')
                       OR (    '4' = '4'
                           AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                 AND T1.END_YMD))
                  AND T1.CLASS_CD = '2') F3,
          SY3020_WKSITE_V_HECOS T4,
          (  SELECT T5.C_CD,
                    T5.EMP_ID,
                    MIN (
                       CASE
                          WHEN T5.ADDR_CD = '003'
                          THEN
                                SUBSTR (T5.ZIP_NO, 1, 3)
                             || '-'
                             || SUBSTR (T5.ZIP_NO, 4, 3)
                       END)
                       POSTAL_CD,
                    MIN (CASE WHEN T5.ADDR_CD = '003' THEN T5.ADDR END) ADDRESS
               FROM PA2010 T5
              WHERE T5.ADDR_CD IN ('003')
           GROUP BY T5.C_CD, T5.EMP_ID) T6,
          (SELECT *
             FROM (SELECT RANK ()
                          OVER (
                             PARTITION BY EMP_ID
                             ORDER BY
                                INS_YMDHMS DESC, MOD_YMDHMS DESC, SEQ_NO DESC)
                             AS RK,
                          F.*
                     FROM PA9080# F) FF
            WHERE FF.RK = 1) T7,
          PY8010 T8,
          PA9090 T9,
          ( SELECT C_CD
                 , EMP_ID
                 , COUNT(CASE WHEN TO_CHAR(SYSDATE,'yyyymmdd') BETWEEN STA_YMD AND END_YMD THEN 1 END) CNT
                 , MAX(CASE WHEN END_YMD <= TO_CHAR(SYSDATE,'yyyymmdd') THEN END_YMD END) MAX_END_YMD
              FROM PA2065
          GROUP BY C_CD, EMP_ID
          ) T10
    WHERE     T2.C_CD = T1.C_CD
          AND T2.EMP_ID = T1.EMP_ID
          AND T9.C_CD(+) = T1.C_CD
          AND T9.EMP_ID(+) = T1.EMP_ID
          AND T10.C_CD(+) = T1.C_CD
          AND T10.EMP_ID(+) = T1.EMP_ID
          AND CASE
                 WHEN     T9.EMP_ID IS NOT NULL
                      AND T9.ENTER_YMD > TO_CHAR (SYSDATE, 'YYYYMMDD')
                 THEN
                    T9.ENTER_YMD -- 사전연동 대상자의 경우 입사일로 가정하여 연동, 아닌경우는 오늘날짜의 발령으로 연동한다.
                 ELSE
                    TO_CHAR (SYSDATE, 'YYYYMMDD')
              END BETWEEN T2.STA_YMD
                      AND T2.END_YMD
          --  채병석 상무님 입사전 시스템 사용위해 예외처리. 2013.12.31 김성관 대리
          --                        AND TO_CHAR (CASE WHEN T1.EMP_ID = '201400021' THEN SYSDATE+1 ELSE SYSDATE END, 'YYYYMMDD') BETWEEN T2.STA_YMD
          --                                                              AND  T2.END_YMD
          --  원병각 외주 입사전 시스템 사용위해 예외처리. 2014.10.08 김성관 대리
          --          AND TO_CHAR (
          --                 CASE
          --                    WHEN T1.EMP_ID = '201443688' THEN SYSDATE + 8
          --                    ELSE SYSDATE
          --                 END,
          --                 'YYYYMMDD') BETWEEN T2.STA_YMD
          --                                 AND T2.END_YMD
          --  김기룡 외주 입사전 시스템 사용위해 예외처리. 2014.10.29 김성관 대리
          --          AND TO_CHAR (
          --                 CASE
          --                    WHEN T1.EMP_ID = '201444688' THEN SYSDATE + 1
          --                    ELSE SYSDATE
          --                 END,
          --                 'YYYYMMDD') BETWEEN T2.STA_YMD
          --                                 AND T2.END_YMD
          --  정승철 외주 입사전 시스템 사용위해 예외처리. 2014.10.31 김성관 대리
          --AND TO_CHAR (
          --       CASE
          --          WHEN T1.EMP_ID = '201444378' THEN SYSDATE + 4
          --          ELSE SYSDATE
          --       END,
          --       'YYYYMMDD') BETWEEN T2.STA_YMD
          --                       AND T2.END_YMD
          --  유민성 PJT사원 입사전 시스템 사용위해 예외처리. 2014.11.18 김성관 대리
          --          AND TO_CHAR (
          --                 CASE
          --                    WHEN T1.EMP_ID = '201446772' THEN SYSDATE + 1
          --                    ELSE SYSDATE
          --                 END,
          --                 'YYYYMMDD') BETWEEN T2.STA_YMD
          --                                 AND T2.END_YMD
          --AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD AND T2.END_YMD
          AND T2.LAST_YN = 'Y'
          AND T3.C_CD(+) = T1.C_CD
          AND T3.EMP_ID(+) = T1.EMP_ID
          AND T3.ADDR_CD(+) = '003'
          AND T4.OBJ_ID(+) = T2.WORK_LOC_ID
          --AND T2.EMP_TYPE NOT IN ('O')
          AND T2.C_CD = F3.C_CD(+)
          AND T2.EMP_ID = F3.EMP_ID(+)
          AND T2.C_CD = T6.C_CD(+)
          AND T2.EMP_ID = T6.EMP_ID(+)
          AND T2.C_CD = T7.C_CD(+)
          AND T2.EMP_ID = T7.EMP_ID(+)
          AND T2.C_CD = T8.C_CD(+)
          AND T2.EMP_ID = T8.EMP_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMM') BETWEEN T8.STA_YM(+)
                                              AND T8.END_YM(+)
/
