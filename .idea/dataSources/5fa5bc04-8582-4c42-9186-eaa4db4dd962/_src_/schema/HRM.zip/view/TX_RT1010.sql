CREATE VIEW TX_RT1010 AS SELECT T2.C_CD C_CD,
          T2.EMP_ID EMP_ID,
          SUBSTR (T1.PAYROLL_YMD, 1, 6) TAX_ORGN_YM,
          T3.ORG_ID ORG_ID,                                               --??
          T2.BIZPL_CD BIZPL_CD,
          T2.TAX_LOC_CD LOC_CD,                                           --??
          FLOOR (T2.RET_MON + T2.VOL_MON) TOT_PAY_MON,
          0 NTAX_MON,
          T2.INCM_TAX_MON INCM_TAX_MON,
          T2.RESI_TAX_MON RESI_TAX_MON,
          T2.FAM_TAX_MON FAM_TAX_MON
     FROM PY0300 T1, RT1010# T2, PA1020 T3
    WHERE     1 = 1
          AND T2.C_CD = T1.C_CD
          AND T2.PAYROLL_NO = T1.PAYROLL_NO
          AND T2.ADJ_TYPE IN ('1', '2')
          AND T3.C_CD = T2.C_CD
          AND T3.EMP_ID = T2.EMP_ID
          AND T1.PAYROLL_YMD BETWEEN T3.STA_YMD AND T3.END_YMD
          AND T3.LAST_YN = 'Y'
/
