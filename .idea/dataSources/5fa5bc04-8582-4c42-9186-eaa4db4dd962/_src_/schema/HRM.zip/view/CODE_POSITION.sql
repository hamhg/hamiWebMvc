CREATE VIEW CODE_POSITION AS SELECT a.cd,
            a.cd_nm,
            a.eng_nm,
            a.smr_cd_nm,
            F_GET_CODENM(B.C_CD, '00101', B.COND_CD1) POSITION_NAME2,
            DECODE (a.USE_YN, 'Y', '1', '0'),
            TO_CHAR (b.dp_order)
       FROM (SELECT *
               FROM sy5020
              WHERE idx_cd = '/SY04') a,
            (SELECT *
               FROM sy5020
              WHERE idx_cd = '00100') b
      WHERE a.c_cd = b.c_cd AND a.cd = b.cd
   ORDER BY b.dp_order
/
COMMENT ON VIEW CODE_POSITION IS '[HECOS/DRM_IF용] (CODE_POSITION)직위/HECOS직위_코드테이블'
/
