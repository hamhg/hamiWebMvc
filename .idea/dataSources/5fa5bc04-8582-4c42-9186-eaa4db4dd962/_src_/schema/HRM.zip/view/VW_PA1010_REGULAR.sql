CREATE VIEW VW_PA1010_REGULAR AS SELECT T1.C_CD,
          T1.EMP_ID,
          T1.EMP_NM,
          T2.ORG_ID,
          F_GET_OBJNM (T1.C_CD,
                       'O',
                       T2.ORG_ID,
                       T2.STA_YMD)
             ORG_NM,
          T3.WK_SITE ORG_WK_SITE,
          T2.WORK_LOC_ID,
          F_GET_OBJNM (T1.C_CD,
                       'WA',
                       T2.WORK_LOC_ID,
                       T2.STA_YMD)
             WORK_LOC_NM,
          T4.WK_SITE WORK_LOC_WK_SITE,
          T1.EMP_TYPE,
          F_GET_CODENM (T1.C_CD, '/SY01', T1.EMP_TYPE) EMP_TYPE_NM,
          T2.STAT_CD,
          F_GET_CODENM (T1.C_CD, '/SY02', T2.STAT_CD) STAT_NM,
          T2.STAT_CLASS,
          F_GET_CODENM (T2.C_CD, '/SY66', T2.STAT_CLASS) STAT_CLASS_NM,
          T2.NOTE
     FROM PA1010# T1,
          PA1020 T2,
          OM0010 T3,
          OM3010 T4
    WHERE     T2.C_CD = T1.C_CD
          AND T2.EMP_ID = T1.EMP_ID
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD AND T2.END_YMD
          AND T2.LAST_YN = 'Y'
          AND T2.EMP_TYPE IN ('A',
                              'B',
                              'C',
                              'D',
                              'G')
          AND (T1.PAY_CALC_EXEC_YN IS NULL OR T1.PAY_CALC_EXEC_YN = 'N')
          AND T3.C_CD(+) = T2.C_CD
          AND T3.ORG_ID(+) = T2.ORG_ID
          AND T2.STA_YMD BETWEEN T3.STA_YMD(+) AND T3.END_YMD(+)
          AND T4.C_CD(+) = T2.C_CD
          AND T4.ORG_ID(+) = T2.ORG_ID
          AND T2.STA_YMD BETWEEN T4.STA_YMD(+) AND T4.END_YMD(+)
/
