CREATE VIEW INSABUSOTBL2 AS SELECT 'HE' COMPANYCD,
            'ko' LANGCD,
            T1.OBJ_ID BUSOCD,
            --NVL (T4.OBJ_NM, T3.OBJ_NM) AS BUSONM,     -- 원소속명칭이 없는 경우 근무지 명칭 기표
            CASE WHEN T4.OBJ_NM IS NULL THEN T3.OBJ_NM
                 WHEN TRIM(F_ORG_NM(T2.C_CD, TO_CHAR(SYSDATE,'YYYYMMDD'), T2.ORG_ID, '4D')) <> TRIM(T3.OBJ_NM) THEN T3.OBJ_NM
                 ELSE T4.OBJ_NM
             END AS BUSONM, 
            NVL (NVL (T4.ENG_OBJ_NM, T3.ENG_OBJ_NM), T4.OBJ_NM) AS EBUSONM -- 원소속명칭이 없는 경우 근무지 명칭 기표
                                                                          ,
            NULL AS SBUSONM,
            '1' AS BUSOGB,
            '1' AS BONSAGB,
            T1.PAR_OBJ_ID AS ROOTCD,
            T1.STA_YMD AS CREATEDATE,
            T1.END_YMD AS DELETEDATE,
            'Y' AS DISPLAYYN,
            '대한민국' AS NATIONALNM,
            'KR' AS NATIONALCD,
            NULL AS AREA,
            T1.SEQ SORTORDER
       FROM (           SELECT LEVEL TLEVEL,
                               T1.OBJ_TYPE,
                               T1.OBJ_ID,
                               T1.PAR_OBJ_TYPE,
                               T1.PAR_OBJ_ID,
                               T1.STA_YMD,
                               T1.END_YMD,
                               ROWNUM SEQ
                          FROM (SELECT T1.*
                                  FROM SY3020 T1
                                 WHERE     T1.C_CD = 'HEC'
                                       AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN T1.STA_YMD
                                                                             AND T1.END_YMD)
                               T1
                    START WITH     (T1.C_CD, T1.OBJ_TYPE, T1.OBJ_ID) IN (SELECT C_CD,
                                                                                ROOT_OBJ_TYPE,
                                                                                ROOT_OBJ_ID
                                                                           FROM SY3070
                                                                          WHERE     C_CD =
                                                                                       'HEC'
                                                                                AND OBJ_TREE_TYPE =
                                                                                       'WATREE'
                                                                                AND TO_CHAR (
                                                                                       SYSDATE,
                                                                                       'YYYYMMDD') BETWEEN STA_YMD
                                                                                                       AND END_YMD)
                               AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                     AND T1.END_YMD
                    CONNECT BY     PRIOR T1.C_CD = T1.C_CD
                               AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
                               AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
             ORDER SIBLINGS BY T1.SEQ_NO) T1,
            OM3010 T2,
            SY3010 T3,
            SY3010 T4
      WHERE     T2.C_CD(+) = 'HEC'
            AND T2.WORK_LOC_ID(+) = T1.OBJ_ID
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD(+)
                                                  AND T2.END_YMD(+)
            AND T3.C_CD(+) = 'HEC'
            AND T3.OBJ_ID(+) = T1.OBJ_ID
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T3.STA_YMD
                                                  AND T3.END_YMD
            AND T4.OBJ_ID(+) = T2.ORG_ID
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T4.STA_YMD(+)
                                                  AND T4.END_YMD(+)
   ORDER BY SORTORDER
/
COMMENT ON VIEW INSABUSOTBL2 IS '[IM_IF용] (INSABUSOTBL2)근무지_체계도2'
/
