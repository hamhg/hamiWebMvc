CREATE VIEW SY5020_V_ITSM AS SELECT   T1.C_CD,
              T1.IDX_CD,
              T1.CD,
              T1.CD_NM,
              --T1.DP_ORDER,
              --T1.SMR_CD_NM,
              CASE
                 WHEN T1.IDX_CD = '/SY04'
                 THEN
                    F_GET_CODE_ORDER (T1.C_CD, '00100', T1.CD)
                 ELSE
                    T1.DP_ORDER
              END
                 AS DP_ORDER, --[2012.12.11] IDX_CD가 '/SY04'인 경우, HECOS용 직위 정렬순서 반환
              CASE
                 WHEN T1.IDX_CD = '/SY04'
                 THEN
                    F_GET_COND_CODENM (T1.C_CD,
                                       '00100',
                                       T1.CD,
                                       '1')
                 ELSE
                    T1.SMR_CD_NM
              END
                 AS SMR_CD_NM, --[2012.12.11] IDX_CD가 '/SY04'인 경우, HECOS용 직위명 반환
              T1.ENG_NM,
              T1.CNVT_CD,
              T1.STA_YMD,
              T1.END_YMD,
              T1.USE_YN
       FROM   SY5020 T1
      WHERE   T1.C_CD = 'HEC'
              AND T1.IDX_CD IN ('/SY04', '/SY05', 'OM020', '00090' )
              AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                    AND  T1.END_YMD
   ORDER BY   T1.IDX_CD, T1.CD
/
COMMENT ON VIEW SY5020_V_ITSM IS '[ITSM_IF용] (SY5020_V_ITSM)코드테이블'
/
COMMENT ON COLUMN SY5020_V_ITSM.C_CD IS '회사코드'
/
COMMENT ON COLUMN SY5020_V_ITSM.IDX_CD IS '인덱스코드'
/
COMMENT ON COLUMN SY5020_V_ITSM.CD IS '코드'
/
COMMENT ON COLUMN SY5020_V_ITSM.CD_NM IS '코드명'
/
COMMENT ON COLUMN SY5020_V_ITSM.DP_ORDER IS '조회순서'
/
COMMENT ON COLUMN SY5020_V_ITSM.SMR_CD_NM IS '약어코드명'
/
COMMENT ON COLUMN SY5020_V_ITSM.ENG_NM IS '영문명'
/
COMMENT ON COLUMN SY5020_V_ITSM.CNVT_CD IS '변환코드'
/
COMMENT ON COLUMN SY5020_V_ITSM.STA_YMD IS '시작일'
/
COMMENT ON COLUMN SY5020_V_ITSM.END_YMD IS '종료일'
/
COMMENT ON COLUMN SY5020_V_ITSM.USE_YN IS '사용여부'
/
