CREATE VIEW HRM_EMPLOYEES_V_SAP AS SELECT A.EMP_ID,                                                      -- 사번
          B.ORG_NM,                                                      -- 소속
          A.EMP_NM,
          F_ORG_NM (A.C_CD,
                    B.STA_YMD,
                    B.ORG_ID,
                    '2')
             BUMUN_NM,                                                   -- 성명
          A.ENG_EMP_NM,                                               -- 성명(영)
          B.POST_CD,                                                     -- 직위
          CAST (F_GET_CODENM (B.C_CD, '00100', B.POST_CD2) AS VARCHAR2 (100))
             AS POST_NM,                                                -- 직위명
          B.WORK_LOC_ID,                                                -- 근무지
          CAST (
             F_GET_OBJNM (B.C_CD,
                          'WA',
                          B.WORK_LOC_ID,
                          NVL (A.RETIRE_YMD, B.END_YMD)) AS VARCHAR2 (200))
             AS WORK_LOC_NM,                                           -- 근무지명
          A.WORK_LOC_TEL_NO,                                 -- 전화 (우선 근무지 전화)
          A.ENTER_YMD,                                                  -- 입사일
          A.RETIRE_YMD,                                                 -- 퇴사일
          CAST (F_ORG_NM (B.C_CD,
                          NVL (A.RETIRE_YMD, B.STA_YMD),
                          B.ORG_ID,
                          '1') AS VARCHAR2 (200))
             AS DIVISION_NM,                       -- 본부 객체명별 200BYTE씩 추가해야 함.
          CAST (F_ORG_NM (A.C_CD,
                          NVL (A.RETIRE_YMD, b.STA_YMD),
                          b.ORG_ID,
                          '3D') AS VARCHAR2 (200))
             AS ORG_NM,
          -- 팀명 객체명별 200BYTE씩 추가해야 함.
          --   SUBSTR (F_HEC_DEC_PER (A.PER_NO), 1, 6)
          --|| CASE
          --      WHEN B.EMP_TYPE = 'P' THEN SUBSTR (A.EMP_ID, 3, 6) || '9'
          --      ELSE SUBSTR (A.EMP_ID, 3, 7)
          --   -- 일용직의 경우 SAP 연동시 주민번호 체크 validation 문제발생하여, 9로 변경하여 송부. 2014.02.28 이명욱 과장 요청
          --   END
          A.PER_NO AS ID_NO,                                           -- 주민번호
          B.ORG_ID,                                                     -- 팀코드
          CAST (F_ORG_NM (B.C_CD,
                          NVL (A.RETIRE_YMD, B.STA_YMD),
                          B.ORG_ID,
                          '3D') AS VARCHAR2 (200))
             AS ORG_SHORT_NM,                -- 소속명(짧은)  객체명별 200BYTE씩 추가해야 함.
          A.WORK_LOC_FAX,                                                -- 팩스
          A.MOBILE_NO,                                                 -- 휴대전화
          CAST (
             F_GET_CODENM (A.C_CD, '00090', A.WORK_PLACE_NM) AS VARCHAR2 (100))
             AS WORK_PLACE_NM,                                         -- 근무위치
          A.MAIL_ADDR,                                                  -- 이메일
          RETIRE_YN,                                                   -- 퇴사구분
          CAST (
             F_GET_CODE_SHORTNM (B.C_CD, '00100', B.POST_CD2) AS VARCHAR2 (100))
             AS POST_SHORT_NM,                                       -- 직위(짧은)
          F_GET_OBJ_STA_YMD2 (A.C_CD,
                              A.EMP_ID,
                              'WA',
                              B.WORK_LOC_ID,
                              TO_CHAR (SYSDATE, 'YYYYMMDD'))
             LAST_MOVE_YMD,                                    -- 최종발령일(최종이동일)
          B.DUTY_CD,                                                   -- 직책코드
          C.ZIP_NO,                                               -- 우편번호(현주소)
          C.ADDR,                                                  -- 동주소(현주소)
          C.DTL_ADDR                                              -- 세부주소(현주소)
     FROM HRM.PA1010# A, HRM.PA1020 B, HRM.PA2010 C
    WHERE     A.C_CD = B.C_CD
          AND A.EMP_ID = B.EMP_ID
          AND B.LAST_YN = 'Y'
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN B.STA_YMD AND B.END_YMD
          AND A.C_CD = C.C_CD(+)
          AND A.EMP_ID = C.EMP_ID(+)
          AND C.ADDR_CD(+) = '003'
          -- 2012/10/04 일용직 직원 추가 by 최영배 차장
          -- 2012/12/13 직책코드, 현주소 (우편번호, 동주소, 세부주소 추가)
          --            외주파견직원 추가
          -- 2015.01.19 외주직원 추가 by 김성관 과장.(김곤수 과장 협의 완료)
          AND 1 =
                 CASE
                    WHEN B.EMP_TYPE IN ('O', '8H')
                    THEN
                       (CASE
                           WHEN     B.ORG_NM LIKE '%현대건설%'
                                AND B.EMP_TYPE = 'O'
                                AND B.EMP_ID LIKE '%C'
                           THEN
                              1
                        END)
                    ELSE
                       1
                 END
-- GHRM 직원 추가. 2016.05.03 정보보안WG 협의 결과 GHRM사번은 전체 넘겨주고 권한 부여는 SAP기준에 의거 선택적 부여   
UNION ALL
         SELECT T1.EMP_ID AS EMP_ID
              , NULL AS ORG_FULL_NM
              , T1.EMP_FIRST_NM || ' ' || T1.EMP_LAST_NM AS EMP_NM
              , NULL AS BUMUN_NM
              , T1.EMP_FIRST_NM || ' ' || T1.EMP_LAST_NM AS ENG_EMP_NM
              , T1.CATEGORY_CD AS POST_CD
              , F_GET_CODENM('HEC', '/GP01', T1.CATEGORY_CD) AS POST_NM
              , T1.WORK_LOC_ID AS WORK_LOC_ID
              ,(SELECT OBJ_NM FROM SY3010 WHERE OBJ_ID = T1.WORK_LOC_ID AND OBJ_TYPE IN ('WA','WG')) AS WORK_LOC_NM
              , NULL AS WORK_LOC_TEL_NO
              ,(SELECT MIN(STA_YMD) FROM GP1020
                 WHERE C_CD = 'HEC'
                   AND EMP_ID = T1.EMP_ID) AS ENTER_YMD
              , CASE WHEN
                           (SELECT MAX(LEAST(END_YMD, NVL(FINISH_YMD, '99991231'))) FROM GP1020
                             WHERE C_CD = 'HEC'
                               AND EMP_ID = T1.EMP_ID
                               AND STA_YMD < TO_CHAR(SYSDATE,'YYYYMMDD'))
                           > TO_CHAR(SYSDATE,'YYYYMMDD')
                           THEN NULL
                     ELSE
                           (SELECT MAX(LEAST(END_YMD, NVL(FINISH_YMD, '99991231'))) FROM GP1020
                             WHERE C_CD = 'HEC'
                               AND EMP_ID = T1.EMP_ID
                               AND STA_YMD < TO_CHAR(SYSDATE,'YYYYMMDD'))
                  END AS RETIRE_YMD
              , NULL AS DIVISION_NM
              , NULL AS ORG_NM
              , F_HEC_ENC_PER(EMP_ID) AS ID_NO
              , NULL AS ORG_ID
              , NULL AS ORG_SHORT_NM
              , NULL AS WORK_LOC_FAX
              , NULL AS MOBILE_NO
              , '해외현장' AS WORK_PLACE_NM
              , NULL AS MAIL_ADDR
              , CASE WHEN
                           (SELECT MAX(LEAST(END_YMD, NVL(FINISH_YMD, '99991231'))) FROM GP1020
                             WHERE C_CD = 'HEC'
                               AND EMP_ID = T1.EMP_ID
                               AND STA_YMD < TO_CHAR(SYSDATE,'YYYYMMDD'))
                           >= TO_CHAR(SYSDATE,'YYYYMMDD')
                           THEN 'N'
                     ELSE
                           'Y'
                  END AS RETIRE_YN
              , F_GET_CODENM('HEC', '/GP01', T1.CATEGORY_CD) AS POST_SHORT_NM
              ,(SELECT MIN(STA_YMD) FROM GP1020
                 WHERE C_CD = 'HEC'
                   AND EMP_ID = T1.EMP_ID) AS LAST_MOVE_YMD
              , NULL AS DUTY_CD
              , NULL AS ZIP_NO
              , NULL AS ADDR
              , NULL AS DTL_ADDR
          FROM (
                SELECT A1.C_CD
                      ,A1.EMP_ID
                      ,A1.EMP_FIRST_NM
                      ,A1.EMP_LAST_NM
                      ,A1.GENDER_TYPE
                      ,A1.NTNL_CD
                      ,A1.BIRTH_YMD
                      ,A1.LOC_ADDR
                      ,A1.REENTER_TYPE
                      ,A1.EXPT_PROB_END_YMD
                      ,A2.SEQ_NO
                      ,A2.STA_YMD
                      ,A2.END_YMD
                      ,A2.FINISH_YMD              
                      ,A2.WORK_LOC_ID
                      ,A2.CATEGORY_CD
                      ,A2.FOREIGN_EMP_TYPE
                      ,A2.AGENT_NO
                      ,A2.PART_CD
                      ,A2.JOB_CD
                      --
                      ,(SELECT COUNT(*)
                          FROM GP1020 S1
                         WHERE S1.C_CD = A1.C_CD
                           AND S1.EMP_ID = A1.EMP_ID
                           AND STA_YMD < TO_CHAR(SYSDATE,'YYYYMMDD')) AS PRE_CONTRACT_CNT 
                  FROM GP1010 A1
                      ,GP1020 A2
                 WHERE A1.C_CD = 'HEC'
                   --
                   AND A2.CATEGORY_CD = 'S'     -- Staff에 한함
                   AND A2.C_CD(+) = A1.C_CD
                   AND A2.EMP_ID(+) = A1.EMP_ID
                   AND (A2.END_YMD IS NULL OR A2.END_YMD = (SELECT MAX(END_YMD) FROM GP1020 WHERE EMP_ID = A1.EMP_ID))
               ) T1
             WHERE TO_CHAR(SYSDATE,'YYYYMMDD') BETWEEN T1.STA_YMD AND NVL(T1.FINISH_YMD,'99991231')
   WITH READ ONLY
/
COMMENT ON VIEW HRM_EMPLOYEES_V_SAP IS '[SAP_IF용] (HRM_EMPLOYEES_V_SAP)인사정보'
/
