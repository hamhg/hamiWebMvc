CREATE VIEW VW_SY4310 AS SELECT C_CD,
          PROFILE_ID,
          PROFILE_NM,
          EXPL,
          GEN_YN,
          ADM_YN,
          ALL_OPEN_YN,
          GRP_ALL_SCH_YN,
         EMP_SCH_AUTH_CD,
          READ_AUTH_YN,
          WRITE_AUTH_YN,
          PRT_AUTH_YN,
          USE_YN,
          DP_ORDER,
          MOD_USER_ID,
          MOD_YMDHMS
     FROM SY4310
/
