CREATE VIEW TEMPUSER_HEC_INFO AS SELECT   "SEQ_NO",
            "USER_ID",
            "USER_NAME",
            "GROUP_ID",
            "DUTY_ID",
            "COMPANY_ID",
            "COMPANY_TYPE",
            "COMPANY_NAME",
            "USER_NAME_ENG",
            "RETIRE_STATUS",
            "EMP_TYPE",
            "WORK_GUBUN",
            "HQ_ORG_ID",
            "HQ_ORG_NM",
            "SECTOR_ORG_ID",
            "SECTOR_ORG_NM",
            "TEAM_ORG_ID",
            "TEAM_ORG_NM"
     FROM   (SELECT   ROW_NUMBER ()
                         OVER (ORDER BY T3.DP_ORDER, T1.EMP_ID, T1.EMP_NM)
                         AS SEQ_NO,
                      SUBSTR (T1.EMP_ID, 3, 7) AS USER_ID              -- 사번
                                                         ,
                      T1.EMP_NM AS USER_NAME                           -- 성명
                                            --, T2.ORG_ID AS GROUP_ID                -- 원소속
                      ,
                      T2.WORK_LOC_ID AS GROUP_ID                     -- 원소속
                                                ,
                      T2.POST_CD AS DUTY_ID                            -- 직위
                                           ,
                      NULL AS COMPANY_ID                           -- 회사코드
                                        ,
                      NULL AS COMPANY_TYPE                     -- 법인구분코드
                                          ,
                      NULL AS COMPANY_NAME                       -- 회사법인명
                                          ,
                      T1.ENG_EMP_NM AS USER_NAME_ENG               -- 영문이름
                                                    ,
                      NULL AS RETIRE_STATUS                        -- 퇴사여부
                                           ,
                      T2.EMP_TYPE                  -- 직원구분 2012/11/09 추가
                                 ,
                      CASE
                         WHEN PAR_OBJ_ID IN ('WG00000003', 'WG00000004')
                         THEN
                            '현장'
                         ELSE
                            '본사'
                      END
                         AS WORK_GUBUN                             -- 현장구분
                                      --//
                                      --, F_ORG_ID(T2.C_CD, TO_CHAR(SYSDATE, 'YYYYMMDD'), T2.ORG_ID, '1') AS HQ_ORG_ID       -- (소속)본부ID
                      ,
                      F_ORG_NM (T2.C_CD,
                                TO_CHAR (SYSDATE, 'YYYYMMDD'),
                                T2.ORG_ID,
                                '6')
                         AS HQ_ORG_ID                          -- (소속)본부ID
                                     ,
                      F_ORG_NM (T2.C_CD,
                                TO_CHAR (SYSDATE, 'YYYYMMDD'),
                                T2.ORG_ID,
                                '1')
                         AS HQ_ORG_NM                          -- (소속)본부명
                                     --//
                                     --, F_ORG_ID(T2.C_CD, TO_CHAR(SYSDATE, 'YYYYMMDD'), T2.ORG_ID, '2') AS SECTOR_ORG_ID   -- (소속)부문ID
                      ,
                      F_ORG_NM (T2.C_CD,
                                TO_CHAR (SYSDATE, 'YYYYMMDD'),
                                T2.ORG_ID,
                                '7')
                         AS SECTOR_ORG_ID                      -- (소속)부문ID
                                         ,
                      F_ORG_NM (T2.C_CD,
                                TO_CHAR (SYSDATE, 'YYYYMMDD'),
                                T2.ORG_ID,
                                '2')
                         AS SECTOR_ORG_NM                      -- (소속)부문명
                                         --//
                                         --, F_ORG_ID(T2.C_CD, TO_CHAR(SYSDATE, 'YYYYMMDD'), T2.ORG_ID, '3') AS TEAM_ORG_ID     -- (소속)팀ID
                      ,
                      F_ORG_NM (T2.C_CD,
                                TO_CHAR (SYSDATE, 'YYYYMMDD'),
                                T2.ORG_ID,
                                '8')
                         AS TEAM_ORG_ID                          -- (소속)팀ID
                                       ,
                      F_ORG_NM (T2.C_CD,
                                TO_CHAR (SYSDATE, 'YYYYMMDD'),
                                T2.ORG_ID,
                                '3')
                         AS TEAM_ORG_NM                          -- (소속)팀명
               FROM   PA1010# T1,
                      PA1020 T2,
                      SY5020 T3,
                      SY3020_WKSITE_V_HECOS T4
              WHERE       T1.C_CD = 'HEC'
                      AND T1.EMP_ID NOT IN ('201202978')  -- 공정위 예외처리;;
                      --//
                      AND T2.C_CD = T1.C_CD
                      AND T2.EMP_ID = T1.EMP_ID
                      AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                            AND  T2.END_YMD
                      AND T2.LAST_YN = 'Y'
                      AND T2.STAT_CD LIKE '1%'
                      AND T2.EMP_TYPE IN
                               ('A', 'B', 'C', 'D', 'G', 'I', '8', '8P', 'P','8H') -- 일용직 추가 '2013.03.22 최영배 차장
                      --//
                      AND T3.C_CD(+) = T2.C_CD
                      AND T3.CD(+) = T2.POST_CD
                      AND T3.IDX_CD(+) = '00100'
                      --//
                      AND T4.OBJ_ID = T2.WORK_LOC_ID)
/
COMMENT ON VIEW TEMPUSER_HEC_INFO IS '[HECOS/DRM_IF용] (TEMPUSER_HEC_INFO)'
/
