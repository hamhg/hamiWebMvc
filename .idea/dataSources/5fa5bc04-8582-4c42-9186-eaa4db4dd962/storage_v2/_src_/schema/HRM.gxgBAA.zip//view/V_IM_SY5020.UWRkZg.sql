CREATE VIEW V_IM_SY5020 AS SELECT   C_CD,
              IDX_CD,
              CD,
              CD_NM,
              CASE
                 WHEN IDX_CD = '/SY04'
                 THEN
                    F_GET_CODE_ORDER (C_CD, '00100', CD)
                 ELSE
                    DP_ORDER
              END
                 AS DP_ORDER, --[2012.12.31] IDX_CD가 '/SY04'인 경우, HECOS용 직위 정렬순서 반환. 김성관 대리 작업
              SMR_CD_NM,
              CASE
                 WHEN IDX_CD = '/SY04'
                 THEN
                    F_GET_COND_CODENM (C_CD,
                                       '00100',
                                       CD,
                                       '1')
                 ELSE
                    SMR_CD_NM
              END
                 CD_NM_DP,
              ENG_NM,
              CNVT_CD,
              STA_YMD,
              END_YMD,
              USE_YN
       FROM   SY5020
      WHERE   IDX_CD IN
                    ('/SY01',
                     '/SY02',
                     '/SY04',
                     '/SY05',
                     'OM010',
                     'OM020',
                     '00090',
                     '00100')
   ORDER BY   IDX_CD, DP_ORDER
/
COMMENT ON VIEW V_IM_SY5020 IS '[IM_IF용] (V_IM_SY5020)코드테이블'
/
