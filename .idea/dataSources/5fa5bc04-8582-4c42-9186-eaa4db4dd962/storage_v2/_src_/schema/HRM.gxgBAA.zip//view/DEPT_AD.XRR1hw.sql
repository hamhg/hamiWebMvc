CREATE VIEW DEPT_AD AS SELECT   OBJ_ID ORG_ID,
            F_GET_RELOBJID (T1.C_CD,
                            'U',
                            'O',
                            T1.OBJ_ID,
                            'O',
                            TO_CHAR (SYSDATE, 'YYYYMMDD'))
               PAR_ORG_ID,
            OBJ_NM ORG_NM,
            SMR_OBJ_NM,
            WK_SITE
     FROM   SY3010 T1
    WHERE   T1.C_CD = 'HEC' AND T1.OBJ_TYPE = 'O'
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                  AND  T1.END_YMD
/
COMMENT ON VIEW DEPT_AD IS '[AD_IF용] (DEPT_AD)조직정보'
/
