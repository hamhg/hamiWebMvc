CREATE PROCEDURE     P_BE_CRE_LOAN_SCHE_HRM(
  I_C_CD IN VARCHAR2,
  I_DATA_ID IN VARCHAR2,
  I_MOD_USER_ID IN VARCHAR2,
  O_ERRORCODE OUT VARCHAR2,
  O_ERRORMESG OUT VARCHAR2) IS
  /***********************************************************************
   Program Name   : P_BE_CRE_LOAN_SCHE
   Description    : 대출상환일정생성
   Author         : 박영규
   History        : 2007-11-21 신규개발
  ***********************************************************************/
  M GAIS.BEL220#%ROWTYPE := NULL;
  S GAIS.BEL240%ROWTYPE := NULL;
  V_MAX_SEQ_NO GAIS.BEL240.SEQ_NO%TYPE;
  V_ONLY_INTER_YMD VARCHAR2(8);   --거치종료일
  V_PREV_REFUND_YMD GAIS.BEL240.REFUND_YMD%TYPE;   -- 이전상환일자
  V_PREV_BLN_MON GAIS.BEL240.BLN_MON%TYPE;   -- 이전잔액
  V_DD VARCHAR2(20) := '25';   -- 시스템변수에서 가져오도록 수정
  V_TOT_REFUND_MON NUMBER := 0;   -- 원리금균등상환에서 월상환금액(원금+이자)
  V_ONE_REFUND_MON NUMBER := 0;   -- 월상환금액
BEGIN
  -- 대부신청마스터 정보
  SELECT T1.*
    INTO M
    FROM GAIS.BEL220# T1
   WHERE T1.C_CD = I_C_CD
     AND T1.DATA_ID = I_DATA_ID;
  IF M.ONE_REFUND_MON <= 0 THEN
    O_ERRORCODE := -2000;
    O_ERRORMESG := '회당상환금액이 0 입니다.';
    RETURN;
  END IF;
  -- 상환안된 항목 삭제
  DELETE FROM GAIS.BEL240
        WHERE C_CD = I_C_CD
          AND DATA_ID = I_DATA_ID
          AND REFUND_YN <> 'Y';
  -- 대부상환일정 MAX SEQ_NO
  SELECT NVL(MAX(SEQ_NO), 0)
    INTO V_MAX_SEQ_NO
    FROM GAIS.BEL240 T1
   WHERE T1.C_CD = I_C_CD
     AND T1.DATA_ID = I_DATA_ID;
  -- 이전상환일, 이전잔액 가져오기
  IF V_MAX_SEQ_NO = 0 THEN
    -- 상환마스터에서 가져오기
    V_PREV_REFUND_YMD := TO_CHAR(TO_DATE(M.PAY_YMD) - 1, 'YYYYMMDD');   -- 처음엔 빌린날도 이자계산
    V_PREV_BLN_MON := M.LOAN_MON;
  ELSE
    -- 이전상환내역에서 가져오기
    SELECT T1.REFUND_YMD,
           T1.BLN_MON
      INTO V_PREV_REFUND_YMD,
           V_PREV_BLN_MON
      FROM GAIS.BEL240 T1
     WHERE T1.C_CD = I_C_CD
       AND T1.DATA_ID = I_DATA_ID
       AND T1.SEQ_NO = V_MAX_SEQ_NO;
  END IF;
  IF V_PREV_BLN_MON <= 0 THEN
    O_ERRORCODE := 0;
    O_ERRORMESG := '';
    RETURN;
  END IF;
  V_ONLY_INTER_YMD := TO_CHAR(ADD_MONTHS(TO_DATE(M.PAY_YMD, 'YYYYMMDD'), M.DEFM_M_CNT), 'YYYYMMDD');   -- 거치기간
  /*
  원리균등상환 100
  원리금균등상환 200
  만기일시상환 300
  */
  IF M.REFUND_TYPE = '200' THEN
    --var 월상환액 = (대출금*연이율나누기12*Math.pow(1+연이율나누기12,월수))/(Math.pow(1+연이율나누기12,월수)-1);
    V_TOT_REFUND_MON := (M.LOAN_MON * M.INTER_RATE / 100 / 12 * POWER(1 + M.INTER_RATE / 100 / 12, M.REFUND_M_CNT)) /(POWER(1 + M.INTER_RATE / 100 / 12, M.REFUND_M_CNT) - 1);
  END IF;
  -- 상환일정생성
  FOR V_SEQ_NO IN V_MAX_SEQ_NO + 1 ..(M.DEFM_M_CNT + M.REFUND_M_CNT) LOOP
    S.SEQ_NO := V_SEQ_NO;
    -- S.REFUND_YMD := TO_CHAR(ADD_MONTHS(TO_DATE(V_PREV_REFUND_YMD, 'YYYYMMDD'), 1), 'YYYYMMDD');-- 상환일은 이전상환일 + 한달후
    IF SUBSTR(V_PREV_REFUND_YMD, 7, 2) < V_DD THEN
      S.REFUND_YMD := SUBSTR(V_PREV_REFUND_YMD, 1, 6) || V_DD;
    ELSE
      S.REFUND_YMD := TO_CHAR(ADD_MONTHS(TO_DATE(SUBSTR(V_PREV_REFUND_YMD, 1, 6) || V_DD, 'YYYYMMDD'), 1), 'YYYYMMDD');
    END IF;
    S.REFUND_YM := SUBSTR(S.REFUND_YMD, 1, 6);   -- 상환월은 상환일의 월
    S.REFUND_CNT := S.SEQ_NO;   -- 모름
    S.INTER_D_CNT := TO_DATE(S.REFUND_YMD, 'YYYYMMDD') - TO_DATE(V_PREV_REFUND_YMD, 'YYYYMMDD');   --이자일수
    S.INTER_MON := FLOOR((V_PREV_BLN_MON * M.INTER_RATE / 100 / 365 * S.INTER_D_CNT));   -- 이자
    V_ONE_REFUND_MON := CASE
                         WHEN M.REFUND_TYPE = '100' THEN M.ONE_REFUND_MON
                         WHEN M.REFUND_TYPE = '200' THEN FLOOR(V_TOT_REFUND_MON - S.INTER_MON)
                         WHEN M.REFUND_TYPE = '300' THEN V_PREV_BLN_MON
                       END;
    -- 거치기간 까지는 상환금액이 0
    S.REFUND_MON := CASE
                     WHEN S.REFUND_YMD <= V_ONLY_INTER_YMD THEN 0
                     ELSE LEAST(V_ONE_REFUND_MON, V_PREV_BLN_MON)
                   END;
    S.BLN_MON := V_PREV_BLN_MON - S.REFUND_MON;   -- 잔액
    S.REFUND_YN := 'N';
    S.REFUND_TYPE := NULL;
    S.PAYROLL_NO := NULL;
    INSERT INTO GAIS.BEL240
                (C_CD,
                 DATA_ID,
                 SEQ_NO,
                 REFUND_YMD,
                 REFUND_YM,
                 REFUND_CNT,
                 INTER_MON,
                 INTER_D_CNT,
                 REFUND_MON,
                 BLN_MON,
                 REFUND_YN,
                 REFUND_TYPE,
                 PAYROLL_NO,
                 MOD_USER_ID,
                 MOD_YMDHMS,
                 INS_USER_ID,
                 INS_YMDHMS)
         VALUES (I_C_CD,
                 I_DATA_ID,
                 S.SEQ_NO,
                 S.REFUND_YMD,
                 S.REFUND_YM,
                 S.REFUND_CNT,
                 S.INTER_MON,
                 S.INTER_D_CNT,
                 S.REFUND_MON,
                 S.BLN_MON,
                 S.REFUND_YN,
                 S.REFUND_TYPE,
                 S.PAYROLL_NO,
                 I_MOD_USER_ID,
                 SYSDATE,
                 I_MOD_USER_ID,
                 SYSDATE);
    V_PREV_REFUND_YMD := S.REFUND_YMD;
    V_PREV_BLN_MON := S.BLN_MON;
    IF S.BLN_MON <= 0 THEN
      EXIT;
    END IF;
  END LOOP;
  O_ERRORCODE := 0;
  O_ERRORMESG := '';
EXCEPTION
  WHEN OTHERS THEN
    O_ERRORCODE := SQLCODE;
    O_ERRORMESG := SQLERRM;
END;
/
