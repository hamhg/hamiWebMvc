CREATE VIEW PR_BAS_POST_CD AS SELECT CD,
          CD_NM,
          (CASE
              WHEN CD IN ('11', '31') THEN '11'
              WHEN CD IN ('12', '32') THEN '12'
              WHEN CD IN ('13', '33') THEN '13'
              WHEN CD IN ('14', '34') THEN '14'
              WHEN CD IN ('15', '35') THEN '15'
              WHEN CD IN ('16', '36') THEN '16'
              WHEN CD IN ('17', '37') THEN '17'
              WHEN CD IN ('18', '38') THEN '18'
           END)
             COND_CD1,
           (CASE
              WHEN CD BETWEEN '11' AND '18' THEN 'A'
              WHEN CD BETWEEN '31' AND '38' THEN 'C'
           END) COND_CD2,
          DP_ORDER
     FROM SY5020
    WHERE C_CD = 'HEC' AND IDX_CD = '/SY04'
          AND CD IN
                 ('11',
                  '12',
                  '13',
                  '14',
                  '15',
                  '16',
                  '17',
                  '18',
                  '31',
                  '32',
                  '33',
                  '34',
                  '35',
                  '36',
                  '37',
                  '38')
/
