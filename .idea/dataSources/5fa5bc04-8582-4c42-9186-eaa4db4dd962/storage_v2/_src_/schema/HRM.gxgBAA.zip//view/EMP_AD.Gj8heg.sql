CREATE VIEW EMP_AD AS SELECT                                          -- 감사 예외처리 2014.01.20
         CASE
               WHEN t1.emp_id IN
                          ('AUDIT01',
                           'AUDIT02',
                           'AUDIT03',
                           'AUDIT04',
                           'AUDIT05',
                           'AUDIT06',
                           'AUDIT07',
                           'AUDIT08',
                           'AUDIT09',
                           'AUDIT10',
                           'AUDIT11',
                           'AUDIT12',
                           'AUDIT13')
               THEN
                  t1.emp_id
               ELSE
                  SUBSTR (T1.EMP_ID, 3, 7)
            END
               EMPNO,
            T1.EMP_NM NAME_KO,
            T2.ORG_ID ORG_ID,
            T2.EMP_TYPE,
            T2.POST_CD POSITION_CD,
            F_GET_CODENM (T2.C_CD, '/SY04', T2.POST_CD) POSITION_NM,
            NVL (F_GET_CODENM (T1.C_CD, '00090', T1.LOC_CD), '') OFFICD_NM,
            T1.WORK_LOC_TEL_NO PHONE_OFFICE,
            T1.MOBILE_NO PHONE_MOBILE,
            T1.TEL_NO PHONE_HOME,
            T1.WORK_LOC_FAX FAX_OFFICE,
            T1.MAIL_ADDR MAIL_ADDRESS,
            CASE
               WHEN T2.STAT_CD = '30' THEN '4'
               WHEN T2.STAT_CD = '13' THEN '2'
               WHEN T2.STAT_CD = '10' AND T3.EMP_ID IS NOT NULL THEN '5'
               WHEN T2.STAT_CD = '10' THEN '1'
               ELSE ''
            END
               EMP_STATUS,
            CASE
               WHEN T2.STAT_CD = '30' THEN '4'
               WHEN T2.STAT_CD LIKE '1%' AND T3.EMP_ID IS NOT NULL THEN '5'
               WHEN T2.STAT_CD LIKE '1%' THEN '1'
               ELSE ''
            END
               RETIRE_STATUS
     FROM   PA1010# T1, PA1020 T2, PY8010 T3
    WHERE   T1.C_CD = 'HEC' AND T2.C_CD = T1.C_CD AND T2.EMP_ID = T1.EMP_ID
            --  채병석 상무(201400021)님 입사전 시스템 사용위해 예외처리. 2013.12.31 김성관 대리
            -- 정규임원->전문임원, 전문임원->전문위원, 정규임원->전문임원 변경자 선작업 처리. 김장호 대리 요청. 2013.12.31 김성관 대리
            --            AND TO_CHAR (CASE WHEN T1.EMP_ID IN ('201400021'
            --                                               , '201402194'
            --                                               , '201402102','201402113','201402124','201402146','201402150','201402161','201402183','201402172' )
            --                            THEN SYSDATE+1 ELSE SYSDATE END, 'YYYYMMDD') BETWEEN T2.STA_YMD
            --                                                                               AND T2.END_YMD
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                  AND  T2.END_YMD
            AND T2.LAST_YN = 'Y'
            -- 2013/12/09 외주협력 직원도 I/F 대상에 포함 수정 by 김성관 대리 요청
            --AND T2.EMP_TYPE NOT IN ('8H')  -- 외주협력 직원은 AD사용안됨
            AND T3.C_CD(+) = T1.C_CD
            AND T3.EMP_ID(+) = T1.EMP_ID
            AND TO_CHAR (SYSDATE, 'YYYYMM') BETWEEN T3.STA_YM(+)
                                                AND  T3.END_YM(+)
/
COMMENT ON VIEW EMP_AD IS '[AD/SEP_IF용] (EMP_AD)인사정보'
/
