CREATE VIEW V_HDECLAW_WORKLOC AS SELECT T1.C_CD,
            T1.OBJ_ID AS WORK_LOC_ID,
            T1.OBJ_NM AS WORK_LOC_NM,
            T2.BONBU_ID AS HQ_ID,
            F_GET_OBJNM (T1.C_CD,
                         'O',
                         T2.BONBU_ID,
                         T1.STA_YMD)
               AS HQ_NM,
            T2.ETC8_CD AS NTNL_CD,
            (SELECT S.EMP_ID
               FROM PA1020_V_1 S
              WHERE     S.C_CD = T1.C_CD
                    AND S.WORK_LOC_ID = T1.OBJ_ID
                    AND S.EMP_TYPE NOT IN ('8',
                                           '8P',
                                           'P',
                                           '8H',
                                           'O')
                    AND S.STAT_CD LIKE '1%'
                    AND S.DUTY_CD IN ('BG', 'FG'))
               AS HQ_EMP_ID
       FROM SY3010 T1, OM3010 T2
      WHERE     T1.C_CD = T2.C_CD
            AND T1.OBJ_ID = T2.WORK_LOC_ID
            AND T1.C_CD = 'HEC'
            AND T1.OBJ_TYPE = 'WA'
            AND '20161102' BETWEEN T1.STA_YMD AND T1.END_YMD
            AND T1.OBJ_NM IS NOT NULL
   ORDER BY T1.C_CD, T1.OBJ_NM
/
