CREATE PROCEDURE     P_BE_CHECKUP_COPY_MEDICAL_ITEM(I_C_CD            IN VARCHAR2,
                                                           I_YY              IN VARCHAR2,
                                                           I_HOSPITAL_CD     IN VARCHAR2,
                                                           I_TRG_GRP_CD      IN VARCHAR2,
                                                           I_FAM_CD          IN VARCHAR2,
                                                           I_CRE_YY          IN VARCHAR2,
                                                           I_CRE_HOSPITAL_CD IN VARCHAR2,
                                                           I_CRE_TRG_GRP_CD  IN VARCHAR2,
                                                           I_CRE_FAM_CD      IN VARCHAR2,
                                                           I_MOD_USER_ID     IN VARCHAR2,
                                                           O_ERRORCODE       OUT VARCHAR2,
                                                           O_ERRORMESG       OUT VARCHAR2) IS
    /***********************************************************************
     Program Name   : P_BE_CHECKUP_COPY_MEDICAL_ITEM
     Description    : 건강검진항목 기준 복사
     Author         : 정명주
     History        : 2013.03.07 신규생성
    ***********************************************************************/

V_LOOP_CNT NUMBER := 0;
V_COPIED_STD_TXT VARCHAR2(4000) := '';
NL VARCHAR2(2) := CHR(13)||CHR(10);

BEGIN

    -- 검진지급기준(년도,병원,대상그룹,가족관계)별 LOOP 돌면서 복사
    FOR C IN (SELECT T1.*
                    ,T2.CD_NM AS TRG_GRP_NM
                    ,T3.CD_NM AS HOSPITAL_NM
                    ,F_GET_CODENM(T1.C_CD, '00030', T1.FAM_CD) AS FAM_CD_NM
                FROM GAIS.BEH110 T1 -- 검진 지급기준(MASTER)
                    ,SY5020 T2 -- 대상그룹
                    ,SY5020 T3 -- 병원
               WHERE T1.C_CD = I_C_CD
                 AND T1.YY = I_CRE_YY
                 AND T1.HOSPITAL_CD = I_CRE_HOSPITAL_CD
                 AND (I_CRE_TRG_GRP_CD IS NULL OR T1.TRG_GRP_CD = I_CRE_TRG_GRP_CD) -- 대상그룹조건이고..
                 AND (I_CRE_FAM_CD IS NULL OR T1.FAM_CD = I_CRE_FAM_CD) -- 가족관계조건이고..
                    --
                 AND T2.C_CD = I_C_CD
                 AND T2.IDX_CD = 'BE590'
                 AND T2.CD = T1.TRG_GRP_CD
                 AND T3.C_CD = I_C_CD
                 AND T3.IDX_CD = 'BE600'
                 AND T3.CD = T1.HOSPITAL_CD
               ORDER BY T3.DP_ORDER
                       ,T2.DP_ORDER
                       ,T1.FAM_CD)
    LOOP
    
        -- SOURCE 기준은 통과
        IF C.YY = I_YY AND C.HOSPITAL_CD = I_HOSPITAL_CD AND C.TRG_GRP_CD = I_TRG_GRP_CD AND C.FAM_CD = I_FAM_CD THEN
            CONTINUE;
        END IF;
    
        -- 복사시 항목이 있다가 없어져야 될 경우가 있으므로..  일단 지움
        DELETE FROM GAIS.BEH130 T1
         WHERE T1.C_CD = C.C_CD
           AND T1.YY = C.YY
           AND T1.HOSPITAL_CD = C.HOSPITAL_CD
           AND T1.TRG_GRP_CD = C.TRG_GRP_CD
           AND T1.FAM_CD = C.FAM_CD;
    
        INSERT INTO GAIS.BEH130
            (C_CD, YY, TRG_GRP_CD, HOSPITAL_CD, FAM_CD, MEDI_ITEM, NOTE, INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS, MEDI_ITEM_GRP_CD, GRP_MAX_SEL_CNT)
            SELECT C_CD
                  ,C.YY
                  ,C.TRG_GRP_CD
                  ,C.HOSPITAL_CD
                  ,C.FAM_CD
                  ,MEDI_ITEM
                  ,NOTE
                  ,I_MOD_USER_ID
                  ,SYSDATE
                  ,I_MOD_USER_ID
                  ,SYSDATE
                  ,MEDI_ITEM_GRP_CD
                  ,GRP_MAX_SEL_CNT
              FROM GAIS.BEH130 T1
             WHERE T1.C_CD = I_C_CD
               AND T1.YY = I_YY
               AND T1.HOSPITAL_CD = I_HOSPITAL_CD
               AND T1.TRG_GRP_CD = I_TRG_GRP_CD
               AND T1.FAM_CD = I_FAM_CD;
                      
        V_LOOP_CNT := V_LOOP_CNT + 1;
        V_COPIED_STD_TXT := V_COPIED_STD_TXT || C.YY || '년  ' || C.HOSPITAL_NM || '  ' || C.TRG_GRP_NM || '  ' || C.FAM_CD_NM || NL;
    
        DBMS_OUTPUT.PUT_LINE(I_C_CD || ',' || C.YY || ',' || C.HOSPITAL_CD || ',' || C.TRG_GRP_CD || ',' || C.FAM_CD || ',' || SQL%ROWCOUNT || '건 복사');
    
    END LOOP;
    
    IF V_LOOP_CNT = 0 THEN
       RAISE_APPLICATION_ERROR(-20000, '복사된 기준이 하나도 없습니다.');       
    END IF;    
    
    V_COPIED_STD_TXT := V_COPIED_STD_TXT || NL || '* ' || V_LOOP_CNT || '건 복사 완료';


    O_ERRORCODE := '0';
    O_ERRORMESG := V_COPIED_STD_TXT;
EXCEPTION
    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE;
        O_ERRORMESG := SQLERRM;
END;
/
