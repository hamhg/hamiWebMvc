CREATE VIEW EMP_EP AS SELECT   T1.EMP_ID EMPNO,
            SUBSTR (T1.EMP_ID, 3, 7) EMPNO_SHORT,
            '0' DUP_DUTY_NO,
            T2.DUTY_CD DUTY_CD,
            T1.MAIL_ADDR EMAIL,
            T5.G_NO G_NO,
            T5.B_NO B_NO,
            T5.D_NO D_NO,
            T5.T_NO T_NO,
            T5.G_NAME_KO,
            T5.B_NAME_KO,
            T5.D_NAME_KO,
            T5.T_NAME_KO,
            T1.EMP_NM NAME_KO,
            T1.ENG_EMP_NM NAME_EN,
            T2.POST_CD POSITION_CD,
            F_GET_CODENM (T2.C_CD,
                          '00101',
                          F_GET_COND_CD1 (T2.C_CD, '00100', T2.POST_CD2))
               AS POSITION_NM,
            /*
            CASE
               WHEN T2.EMP_ID IN
                          ('201205698',
                           '201120998',
                           '201119968',
                           '201204098',
                           '201204078',
                           '201204068',
                           '201204938',
                           '201204058',
                           '201209028',
                           '201211448',
                           '201302288',
                           '201302298')
               THEN
                  ''
               -- 김민지, 서미애 드림투어 담당이라 예외로 처리 (헤코스 O, 결재 X) 김장호 대리 2012/08/02
               -- 추명희(201119968) 인프라 서비스라운지 담당자 예외로 처리 (헤코스 O, 결재 X) 김장호 대리 2012/08/06
               -- '201204098', '201204078', '201204068', '201204938', '201204058' '임시태', '박성군', '이성철', '나승욱', '유종익' 감사실직원 예외 처리 (헤코스 O, 메일 O, 결재 X) 김장호 대리 2012/08/08
               -- 자버 사원(1209028) UC, HECOS, 이메일 사용 가능  서이준 사원 0212/08/22
               -- 이윤희 사원(1211448) HECOS 사용 가능. 서이준 사원 2012/10/11
               -- 황희수, 김종회 현대건설 전출자 HECOS 사용자 계정추가. 최정환 과장 2013/01/02
            ELSE
                  T1.PER_NO
            END
            */
            '' RESIDENT_REGISTRATION_NO,
            TO_DATE (T1.ENTER_YMD, 'YYYYMMDD') EMPLOYMENT_DATE_COMPANY,
            T3.ADDR || T3.DTL_ADDR ADDRESS_CARD,
            T1.TEL_NO TEL_RESIDENCE,
            T1.MOBILE_NO TEL_CELLULARPHONE,
            F_GET_CODENM (T1.C_CD, '00090', T1.WORK_PLACE_NM)
               WORK_SITE_LOCATION,
            T1.WORK_LOC_TEL_NO WORK_SITE_TEL,
            T1.WORK_LOC_FAX WORK_SITE_FAX,
            T1.HOMEP_ADDR HOMEPAGE,
            F_GET_CODENM (T2.C_CD, '/SY05', T2.DUTY_CD) DUTY_NAME,
            (SELECT   ENG_NM
               FROM   SY5020
              WHERE   C_CD = T1.C_CD AND CD = T2.POST_CD AND IDX_CD = '/SY04')
               POSITION_NAME_EN,
            (SELECT                        --LPAD (TO_CHAR (DP_ORDER), 3, '0')
                   LPAD (TO_CHAR (DP_ORDER), 5, '0')
               FROM   SY5020
              WHERE   C_CD = T1.C_CD AND CD = T2.POST_CD AND IDX_CD = '00100')
               POSITION_SORT,
            CASE
               WHEN t2.EMP_ID IN ('201209028')
               THEN
                  '1' -- 자버 사원(1209028) UC, HECOS, 이메일 사용 가능  서이준 사원 0212/08/22
               WHEN t2.EMP_ID IN
                          ('200200098',
                           '201115438',
                           '199905739',
                           '200905558',
                           '200905568')
               THEN
                  '1'-- 정일룡, 조남규 수리실 김성일 과장 복사실, 김도형, 김변호 통신실  예외로 처리 (헤코스 O, 결재 O) 김장호 대리 2012/08/02
               WHEN T2.EMP_ID IN
                          ('201205698',
                           '201120998',
                           '201119968',
                           '201204098',
                           '201204078',
                           '201204068',
                           '201204938',
                           '201204058',
                           '201209918',
                           '201210378',  -- 인사팀 이승미 사원 요청 2013/01/09
                           '201303628', -- 김찬미 인사팀 방진주 사원 요청 2013/01/28
                           '201402208',        -- 서이준 대리 요청. 2014/01/20
                           '201406078', -- 김정현. 박종오 대리 요청. 2014/03/26
                           '201406088', -- 서석주. 박종오 대리 요청. 2014/03/26
                           '201406098', -- 고병국. 박종오 대리 요청. 2014/03/26
                           '201406108', -- 윤다은. 박종오 대리 요청. 2014/03/26
                           '201406118', -- 김단비. 박종오 대리 요청. 2014/03/26
                           '201406128', -- 최지연. 박종오 대리 요청. 2014/03/26
                           '201406138', -- 전혜인. 박종오 대리 요청. 2014/03/26
                           '201406148' -- 장동준. 박종오 대리 요청. 2014/03/26
                                      )
               THEN
                  '1'
               -- 김민지, 서미애 드림투어 담당이라 예외로 처리 (헤코스 O, 결재 X) 김장호 대리 2012/08/02
               -- 추명희(201119968) 인프라 서비스라운지 담당자 예외로 처리 (헤코스 O, 결재 X) 김장호 대리 2012/08/06
               -- '201204098', '201204078', '201204068', '201204938', '201204058' '임시태', '박성군', '이성철', '나승욱', '유종익' 감사실직원 예외 처리 (헤코스 O, 메일 O, 결재 X) 김장호 대리 2012/08/08
               --  '201209918' 추가(헤코스 O, 결재 O) . 서이준 사원 2012.09.21
            WHEN T2.EMP_TYPE IN ('8', '8H', '8P', 'P', 'O')
               THEN
                  '0'
               ELSE
                  '1'
            END
               EMP_TYPE_CD,
            --T1.WELFARE_CARD_YN
            CASE
               WHEN EXISTS
                       (SELECT   1
                          FROM   BEC220# S1
                         WHERE       S1.C_CD = T1.C_CD
                                 AND S1.EMP_ID = T1.EMP_ID
                                 AND S1.ISSUE_YN = 'Y'
                                 AND S1.CARD_USE_YN = 'Y')
               THEN
                  'Y'
               ELSE
                  'N'
            END
               AS WELFARE_CARD_YN,
            F.ALTERNATE_KEY                                      --대체KEY추가
     FROM   PA1010# T1,
            PA1020 T2,
            PA2010 T3,
            (SELECT   A.C_CD,
                      A.OBJ_ID ORG_ID,
                      A.WK_SITE,
                      A.STA_YMD,
                      A.END_YMD,
                      B.G_NO,
                      B.G_NAME_KO,
                      B.G_NAME_KO_SHORT,
                      B.D_NO,
                      B.D_NAME_KO,
                      B.D_NAME_KO_SHORT,
                      B.T_NO,
                      B.T_NAME_KO,
                      B.T_NAME_KO_SHORT,
                      B.B_NO,
                      B.B_NAME_KO,
                      B.B_NAME_KO_SHORT
               FROM   SY3010 A, OM0010_ALL_VW B
              WHERE   A.obj_id = B.org_id
                      AND (A.OBJ_TYPE = 'O'
                           OR A.obj_id IN
                                   (SELECT   codexcd FROM HRworksiteexception)))
            T5,
            PA2261 T6,
            -- 대체KEY추가
            (SELECT   *
               FROM   (SELECT   RANK ()
                                   OVER (
                                      PARTITION BY EMP_ID
                                      ORDER BY
                                         ins_ymdhms DESC,
                                         mod_ymdhms DESC,
                                         seq_no DESC
                                   )
                                   AS rk,
                                F.*
                         FROM   PA9080# F) FF
              WHERE   FF.RK = 1) F
    WHERE       T2.C_CD = T1.C_CD
            AND T2.EMP_ID = T1.EMP_ID  -- 조직변경적용위해 임시 변경(20110614)
            -- 대체KEY 추가
            AND T1.EMP_ID = F.EMP_ID(+)
            --  채병석 상무님 입사전 시스템 사용위해 예외처리. 2013.12.31 김성관 대리
            --            AND TO_CHAR (CASE WHEN T1.EMP_ID = '201400021' THEN SYSDATE+1 ELSE SYSDATE END, 'YYYYMMDD') BETWEEN T2.STA_YMD
            --                                                  AND  T2.END_YMD
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                  AND  T2.END_YMD
            AND T1.EMP_ID NOT IN ('201303628')
            -- 현대건설 인턴메일 계정 생성위해 임시 방편
            -- AND T2.STAT_CD LIKE '1%'
            AND (T2.STAT_CD LIKE '1%'
                 /*
                 OR T6.EMP_ID IN
                         ('201117638',
                          '201117648',
                          '201117658',
                          '201117668',
                          '201117678',
                          '201117688',
                          '201117698',
                          '201117708',
                          '201117718',
                          '201117728',
                          '201117738',
                          '201117748',
                          '201117788',
                          '201117758',
                          '201117768',
                          '201117778',
                          '201117628',
                          '201304238',
                          '201203722'-- 2012/02/27이용훈 요청 입사일은 3월 1일자이나 현재 출근하며 업무 인수인계를 받고 있는 상황이므로 헤코스 계정은 살아있는 상태에서 입사일 변경 부탁드립니다.
                                     )
                   */
                  )
            ----------------------------------------------------------------------------------
            AND T2.LAST_YN = 'Y'
            AND T3.C_CD(+) = T1.C_CD
            AND T3.EMP_ID(+) = T1.EMP_ID
            AND T3.ADDR_CD(+) = '003'
            AND T5.C_CD(+) = T2.C_CD
            AND T5.ORG_ID(+) = T2.ORG_ID
            AND DECODE (T2.APPNT_CD,
                        '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                        T2.STA_YMD) BETWEEN T5.STA_YMD(+)
                                        AND  T5.END_YMD(+)
            AND T6.C_CD = T1.C_CD
            AND T6.EMP_ID = T1.EMP_ID
            AND T6.USE_SYS = '002'
            -- 조직변경적용위해 임시 변경(20110614)
            --  채병석 상무님 입사전 시스템 사용위해 예외처리. 2013.12.31 김성관 대리
            --         AND TO_CHAR (CASE WHEN T1.EMP_ID = '201400021' THEN SYSDATE+1 ELSE SYSDATE END, 'YYYYMMDD') BETWEEN T6.STA_YMD
            --                                               AND  T6.END_YMD
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T6.STA_YMD
                                                  AND  T6.END_YMD
            AND T2.EMP_ID NOT IN ('20100852P', '20080624P')-- 담당자 퇴사 처리가 지연되어 헤코스연동을위해 임시로제거. 퇴사 확인되면 이 구문은 삭제해야함. 2011.08.04
            AND 1 =
                  (CASE
                      WHEN T2.EMP_ID LIKE '%C'
                      THEN
                         1                                  -- 전자조달 사용자
                      WHEN t2.EMP_ID IN ('201209028')
                      THEN
                         1
                      -- 자버 사원(1209028) UC, HECOS, 이메일 사용 가능  서이준 사원 0212/08/22
                   WHEN t2.EMP_ID IN
                              ('200200098',
                               '201115438',
                               '199905739',
                               '200905558',
                               '200905568')
                      THEN
                         1-- 정일룡, 조남규 수리실 김성일 과장 복사실, 김도형, 김변호 통신실  예외로 처리 (헤코스 O, 결재 O) 김장호 대리 2012/08/02
                      WHEN T2.EMP_ID IN
                                 ('201205698',
                                  '201120998',
                                  '201119968',
                                  '201204098',
                                  '201204078',
                                  '201204068',
                                  '201204938',
                                  '201204058',
                                  '201209918',
                                  '201210378' -- 인사팀 이승미 사원 요청 2013/01/09
                                             ,
                                  '201211448',
                                  '201303628', -- 김찬미 인사팀 방진주 사원 요청 2013/01/28
                                  '201214458', -- 인사운영팀 방진주 사원 요청 2013/12/20
                                  '201402208' -- 서이준 대리요청. 드림타워 직원. 2014/01/20
                                             )
                      THEN
                         1
                      -- 김민지, 서미애 드림투어 담당이라 예외로 처리 (헤코스 O, 결재 X) 김장호 대리 2012/08/02
                      -- 추명희(201119968) 인프라 서비스라운지 담당자 예외로 처리 (헤코스 O, 결재 X) 김장호 대리 2012/08/06
                      -- '201204098', '201204078', '201204068', '201204938', '201204058' '임시태', '박성군', '이성철', '나승욱', '유종익' 감사실직원 예외 처리 (헤코스 O, 메일 O, 결재 X) 김장호 대리 2012/08/08
                      --  '201209918' 추가(헤코스 O, 결재 O) . 서이준 사원 2012.09.21
                   WHEN T2.EMP_ID IN ('201302288', '201302298')
                      THEN
                         1 -- 황희수, 김종회 현대건설 전출자 HECOS 사용자 계정추가. 최정환 과장 2013/01/02
                      WHEN T2.EMP_ID IN
                                 ('201212888', '201212878', '201212898')
                      THEN
                         1-- 전진홍(201212898), 최광윤(201212878), 이하영(201212888) 모의해킹용 관리자 및 사용자 계정추가. 허강녕 과장 2012/08/02
                      WHEN T2.EMP_TYPE IN ('8', 'O', '8H')
                           AND T2.POST_CD NOT LIKE '3%'
                      THEN
                         0
                      ELSE
                         1
                   END)
   /*
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    UNION ALL
      SELECT   T1.SABUNCD EMPNO,
               T1.SABUN2 EMPNO_SHORT,
               TO_CHAR(RANK ()
                          OVER (PARTITION BY T1.SABUNCD
                                ORDER BY T1.STA_YMD, T1.JIKCHCD, T1.ORG_ID))
                  DUP_DUTY_NO,
               T1.JIKCHCD DUTY_CD,
               T1.GUNMAIL EMAIL,
               T1.SOSOKCD G_NO,
               T1.B_NO B_NO,
               T1.BUSEOCD D_NO,
               T1.TEAMSCD T_NO,
               T1.G_NAME_KO G_NAME_KO,
               T1.B_NAME_KO B_NAME_KO,
               T1.D_NAME_KO D_NAME_KO,
               T1.T_NAME_KO T_NAME_KO,
               T1.SMHANMY NAME_KO,
               T1.SMENGMY NAME_EN,
               T1.JIKWICD POSITION_CD,
               T1.JIKWIMY POSITION_NM,
               T1.JUMINNO RESIDENT_REGISTRATION_NO,
               T1.IPSA1DT EMPLOYMENT_DATE_COMPANY,
               T1.JUSO1MY ADDRESS_CARD,
               T1.JUNWAID TEL_RESIDENCE,
               T1.HUDEJID TEL_CELLULARPHONE,
               T1.WORK_SITE_LOCATION WORK_SITE_LOCATION,
               T1.GUNTELE WORK_SITE_TEL,
               T1.GUNFAX WORK_SITE_FAX,
               T1.HOMEPAGE HOMEPAGE,
               F_GET_CODENM (T1.C_CD, '/SY05', T1.JIKCHCD) DUTY_NAME,
               (SELECT   ENG_NM
                  FROM   SY5020
                 WHERE   C_CD = T1.C_CD AND CD = T1.POST_CD AND IDX_CD = '/SY04')
                  POSITION_NAME_EN,
               (SELECT   TO_CHAR (DP_ORDER)
                  FROM   SY5020
                 WHERE   C_CD = T1.C_CD AND CD = T1.POST_CD AND IDX_CD = '00100')
                  POSITION_SORT,
               CASE
                  WHEN T1.EMP_TYPE IN ('8', '8H', '8P', 'P', 'O') THEN '0'
                  ELSE '1'
               END
                  EMP_TYPE_CD,
               '' WELFARE_CARD_YN
        FROM   TP02KIBO T1
       WHERE   T1.SABUNCD NOT IN ('199923909', '199906479')
   */
   UNION ALL
   -- 퇴직자  예외처리
   SELECT   T1.EMP_ID EMPNO,
            SUBSTR (T1.EMP_ID, 3, 7) EMPNO_SHORT,
            '0' DUP_DUTY_NO,
            'ZZ' DUTY_CD,
            T1.MAIL_ADDR EMAIL,
            T5.G_NO G_NO,
            T5.B_NO B_NO,
            T5.D_NO D_NO,
            T5.T_NO T_NO,
            T5.G_NAME_KO,
            T5.B_NAME_KO,
            T5.D_NAME_KO,
            T5.T_NAME_KO,
            T1.EMP_NM NAME_KO,
            T1.ENG_EMP_NM NAME_EN,
            T2.POST_CD POSITION_CD,
            F_GET_CODENM (T2.C_CD,
                          '00101',
                          F_GET_COND_CD1 (T2.C_CD, '00100', T2.POST_CD2))
               POSITION_NM,
            --T1.PER_NO RESIDENT_REGISTRATION_NO,
            '' RESIDENT_REGISTRATION_NO,
            TO_DATE (T1.ENTER_YMD, 'YYYYMMDD') EMPLOYMENT_DATE_COMPANY,
            T3.ADDR || T3.DTL_ADDR ADDRESS_CARD,
            T1.TEL_NO TEL_RESIDENCE,
            T1.MOBILE_NO TEL_CELLULARPHONE,
            F_GET_CODENM (T1.C_CD, '00090', T1.LOC_CD) WORK_SITE_LOCATION,
            T1.WORK_LOC_TEL_NO WORK_SITE_TEL,
            T1.WORK_LOC_FAX WORK_SITE_FAX,
            T1.HOMEP_ADDR HOMEPAGE,
            F_GET_CODENM (T2.C_CD, '/SY05', T2.DUTY_CD) DUTY_NAME,
            (SELECT   ENG_NM
               FROM   SY5020
              WHERE   C_CD = T1.C_CD AND CD = T2.POST_CD AND IDX_CD = '/SY04')
               POSITION_NAME_EN,
            (SELECT   LPAD (TO_CHAR (DP_ORDER), 3, '0')
               FROM   SY5020
              WHERE   C_CD = T1.C_CD AND CD = T2.POST_CD AND IDX_CD = '00100')
               POSITION_SORT,
            CASE
               WHEN T2.EMP_TYPE IN ('8', '8H', '8P', 'P', 'O') THEN '0'
               ELSE '1'
            END
               EMP_TYPE_CD,
            T1.WELFARE_CARD_YN,
            F.ALTERNATE_KEY                                      --대체KEY추가
     FROM   PA1010# T1,
            PA1020 T2,
            PA2010 T3,
            (SELECT   A.C_CD,
                      A.OBJ_ID ORG_ID,
                      A.WK_SITE,
                      A.STA_YMD,
                      A.END_YMD,
                      B.G_NO,
                      B.G_NAME_KO,
                      B.G_NAME_KO_SHORT,
                      B.D_NO,
                      B.D_NAME_KO,
                      B.D_NAME_KO_SHORT,
                      B.T_NO,
                      B.T_NAME_KO,
                      B.T_NAME_KO_SHORT,
                      B.B_NO,
                      B.B_NAME_KO,
                      B.B_NAME_KO_SHORT
               FROM   SY3010 A, OM0010_ALL_VW B
              WHERE   A.obj_id = B.org_id
                      AND (A.OBJ_TYPE = 'O'
                           OR A.obj_id IN
                                   (SELECT   codexcd FROM HRworksiteexception)))
            T5,
            PA2261 T6,
            -- 대체KEY추가
            (SELECT   *
               FROM   (SELECT   RANK ()
                                   OVER (
                                      PARTITION BY EMP_ID
                                      ORDER BY
                                         ins_ymdhms DESC,
                                         mod_ymdhms DESC,
                                         seq_no DESC
                                   )
                                   AS rk,
                                F.*
                         FROM   PA9080# F) FF
              WHERE   FF.RK = 1) F
    WHERE       T2.C_CD = T1.C_CD
            AND T2.EMP_ID = T1.EMP_ID                          -- 대체KEY 추가
            AND T1.EMP_ID = F.EMP_ID(+)
            -- 조직변경적용위해 임시 변경(20110614)
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD -- AND TO_CHAR (SYSDATE + 2, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                  AND  T2.END_YMD
            AND T2.STAT_CD = '30'
            AND T2.EMP_TYPE IN ('A', 'B', 'C', 'D', 'G', 'I','N','M')
            AND T1.EMP_ID NOT IN ('201303628')
            AND T2.LAST_YN = 'Y'
            AND T3.C_CD(+) = T1.C_CD
            AND T3.EMP_ID(+) = T1.EMP_ID
            AND T3.ADDR_CD(+) = '003'
            AND T5.C_CD(+) = T2.C_CD
            AND T5.ORG_ID(+) = T2.ORG_ID
            AND DECODE (T2.APPNT_CD,
                        '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                        T2.STA_YMD) BETWEEN T5.STA_YMD(+)
                                        AND  T5.END_YMD(+)
            AND T6.C_CD = T1.C_CD
            AND T6.EMP_ID = T1.EMP_ID
            AND T6.USE_SYS = '002'
            -- 조직변경적용위해 임시 변경(20110614)
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T6.STA_YMD --             AND TO_CHAR (SYSDATE + 3, 'YYYYMMDD') BETWEEN T6.STA_YMD
                                                  AND  T6.END_YMD
/
COMMENT ON VIEW EMP_EP IS '[HECOS_IF용] (EMP_EP)인사정보'
/
