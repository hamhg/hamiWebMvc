CREATE VIEW EMP_RETIRE_ITSM AS SELECT   T1.EMP_ID,                                           -- 사번 9자리
            SUBSTR (T1.EMP_ID, 3, 7) EMP_ID7,                     --사번 7자리
            NULL EXPT_RETIRE_YMD,                                -- 퇴사예정일
            T2.STA_YMD RETIRE_YMD                                      -- 퇴사
     FROM   PA1010# T1, PA1020 T2
    WHERE   T1.C_CD = 'HEC' AND T2.C_CD = T1.C_CD AND T2.EMP_ID = T1.EMP_ID
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                  AND  T2.END_YMD
            AND T2.LAST_YN = 'Y'
            AND T2.APPNT_CD = '60'
/
COMMENT ON VIEW EMP_RETIRE_ITSM IS '[ITSM_IF용] (EMP_RETIRE_ITSM)인사정보(퇴직)'
/
