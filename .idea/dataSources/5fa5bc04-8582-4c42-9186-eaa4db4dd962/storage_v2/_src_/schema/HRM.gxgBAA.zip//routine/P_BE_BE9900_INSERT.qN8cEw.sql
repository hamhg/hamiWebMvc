CREATE PROCEDURE     P_BE_BE9900_INSERT
(
  I_C_CD IN VARCHAR2,
  I_REQ_TITLE IN VARCHAR2,
  I_REQ_CONTENT IN CLOB,
  I_REQ_EMP_ID IN VARCHAR2,
  I_FILE_NM IN VARCHAR2,
  O_ERRORCODE OUT VARCHAR2,
  O_ERRORMESG OUT VARCHAR2
)
IS

BEGIN


    INSERT INTO BE9900(C_CD
                    , SEQ_NO
                    , REQ_TITLE
                    , REQ_CONTENT
                    , REQ_EMP_ID
                    , REQ_YMDHMS
                    , FILE_NM
                    , STAT_CD
                    , INS_USER_ID
                    , INS_YMDHMS
                    , MOD_USER_ID
                    , MOD_YMDHMS
                    )
            VALUES
                ( I_C_CD
                , NVL((SELECT MAX(SEQ_NO)+1 FROM BE9900 WHERE C_CD = I_C_CD), 0)
                , I_REQ_TITLE
                , I_REQ_CONTENT
                , I_REQ_EMP_ID
                , SYSDATE
                , I_FILE_NM
                , '10'      -- 초기값은 접수(10)
                , I_REQ_EMP_ID
                , SYSDATE
                , I_REQ_EMP_ID
                , SYSDATE
                );

EXCEPTION
WHEN OTHERS THEN
  O_ERRORCODE := SQLCODE;                
  O_ERRORMESG := SQLERRM;

END;
/
