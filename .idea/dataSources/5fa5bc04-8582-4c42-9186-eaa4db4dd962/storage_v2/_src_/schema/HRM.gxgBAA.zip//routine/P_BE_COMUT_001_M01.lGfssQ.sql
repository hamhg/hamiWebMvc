CREATE PROCEDURE     P_BE_COMUT_001_M01(
                            I_C_CD        IN  VARCHAR2,     --회사코드 
                            I_STA_YM   IN VARCHAR2,
                            I_END_YM IN VARCHAR2,
                            I_MOD_USER_ID IN  VARCHAR2,
                            O_ERRORCODE   OUT VARCHAR2,
                            O_ERRORMESG   OUT VARCHAR2
)
IS
/***********************************************************************
 Program Name   : P_BE_COMUT_001_M01
 Description    : 통근버스등록 및 정류장 정보 전월 복사 
 Author         : 윤병근 
 History        : 2010-08-19 신규개발
***********************************************************************/

V_STD_YN VARCHAR2(2);
V_CH_YN VARCHAR2(2);

BEGIN
   
    BEGIN 

       V_STD_YN := 'N';
       V_CH_YN := 'N';

        SELECT  CASE WHEN EXISTS(
                      SELECT 'X'
                        FROM BET120
                      WHERE C_CD = I_C_CD
                           AND STD_YM = I_END_YM)
                    THEN 'Y' ELSE 'N' END
        INTO V_CH_YN
        FROM DUAL;

        SELECT  CASE WHEN EXISTS(
                      SELECT 'X'
                        FROM BET120
                      WHERE C_CD = I_C_CD
                           AND STD_YM = I_STA_YM)
                    THEN 'Y' ELSE 'N' END
        INTO V_STD_YN
        FROM DUAL;

        IF V_STD_YN = 'Y' AND V_CH_YN = 'N' THEN

            BEGIN

                INSERT INTO BET120
                  SELECT I_C_CD,
                              SEQ_NO,
                              I_END_YM,
                              ROUTE_CD,
                              ADM_EMP_ID,
                              MOVE_DTC,
                              ROUTE_UCOST,
                              MOVE_D_CNT,
                              APPL_PERIOD_FR,
                              APPL_PERIOD_TO,
                              FILE_NO,
                              NOTE,
                              I_MOD_USER_ID,
                              SYSDATE,
                              I_MOD_USER_ID,
                              SYSDATE
                    FROM BET120
                  WHERE C_CD = I_C_CD
                       AND STD_YM = I_STA_YM
                     ;
                EXCEPTION WHEN OTHERS THEN       
                    O_ERRORCODE := SQLCODE;
                    O_ERRORMESG := 'P_BE_COMUT_001_M01( BE0001 ), '|| SQLERRM;
                RETURN;        

            END;

        END IF;

    END;


   
    BEGIN 

       V_STD_YN := 'N';
       V_CH_YN := 'N';

        SELECT  CASE WHEN EXISTS(
                      SELECT 'X'
                        FROM BET130
                      WHERE C_CD = I_C_CD
                           AND STD_YM = I_END_YM)
                    THEN 'Y' ELSE 'N' END
        INTO V_CH_YN
        FROM DUAL;

        SELECT  CASE WHEN EXISTS(
                      SELECT 'X'
                        FROM BET120
                      WHERE C_CD = I_C_CD
                           AND STD_YM = I_STA_YM)
                    THEN 'Y' ELSE 'N' END
        INTO V_STD_YN
        FROM DUAL;

        IF V_STD_YN = 'Y' AND V_CH_YN = 'N' THEN

            BEGIN

                INSERT INTO BET130
                  SELECT I_C_CD,
                              SEQ_NO,
                              I_END_YM,
                              ROUTE_CD,
                              STATION_SEQ_NO,
                              STATION_NM,
                              STATION_TIME,
                              FILE_NO,
                              NOTE,
                              I_MOD_USER_ID,
                              SYSDATE,
                              I_MOD_USER_ID,
                              SYSDATE
                    FROM BET130
                  WHERE C_CD = I_C_CD
                       AND STD_YM = I_STA_YM
                     ;
                EXCEPTION WHEN OTHERS THEN       
                    O_ERRORCODE := SQLCODE;
                    O_ERRORMESG := 'P_BE_COMUT_001_M01( BE0002 ), '|| SQLERRM;
                RETURN;        

            END;

        END IF;

    END;
    
    
/*
    MERGE INTO BET120 T1
    USING (
            SELECT T1.C_CD,          
                   T1.SEQ_NO,        
                   TO_CHAR(SYSDATE,'YYYYMM') AS STD_YM,        
                   T1.ROUTE_CD,      
                   T1.ADM_EMP_ID,    
                   T1.MOVE_DTC,      
                   T1.ROUTE_UCOST,   
                   T1.MOVE_D_CNT,    
                   T1.APPL_PERIOD_FR,
                   T1.APPL_PERIOD_TO,
                   T1.FILE_NO,       
                   T1.NOTE,          
                   I_MOD_USER_ID  AS INS_USER_ID,   
                   SYSDATE        AS INS_YMDHMS,    
                   I_MOD_USER_ID  AS MOD_USER_ID,  
                   SYSDATE        AS MOD_YMDHMS 
              FROM BET120 T1
             WHERE T1.C_CD   = I_C_CD 
               AND T1.STD_YM = TO_CHAR(TRUNC(ADD_MONTHS(SYSDATE, -1),'MM'), 'YYYYMM')
          ORDER BY T1.STD_YM    
    ) T2   
    ON (
            T1.C_CD     = T2.C_CD
        AND T1.SEQ_NO   = T2.SEQ_NO
        AND T1.STD_YM   = T2.STD_YM 
        AND T1.ROUTE_CD = T2.ROUTE_CD
        )
     WHEN MATCHED THEN UPDATE SET        
       T1.MOD_USER_ID   = I_MOD_USER_ID,
       T1.MOD_YMDHMS    = SYSDATE         
     WHEN NOT MATCHED THEN INSERT
     (
       T1.C_CD,          
       T1.SEQ_NO,        
       T1.STD_YM,        
       T1.ROUTE_CD,      
       T1.ADM_EMP_ID,    
       T1.MOVE_DTC,      
       T1.ROUTE_UCOST,   
       T1.MOVE_D_CNT,   
       T1.APPL_PERIOD_FR,
       T1.APPL_PERIOD_TO,
       T1.FILE_NO,       
       T1.NOTE,          
       T1.INS_USER_ID,   
       T1.INS_YMDHMS,    
       T1.MOD_USER_ID,   
       T1.MOD_YMDHMS    
     )
     VALUES
     (
       T2.C_CD,          
       T2.SEQ_NO,        
       T2.STD_YM,        
       T2.ROUTE_CD,      
       T2.ADM_EMP_ID,    
       T2.MOVE_DTC,      
       T2.ROUTE_UCOST,   
       T2.MOVE_D_CNT,   
       T2.APPL_PERIOD_FR,
       T2.APPL_PERIOD_TO,
       T2.FILE_NO,       
       T2.NOTE,          
       T2.INS_USER_ID,   
       T2.INS_YMDHMS,    
       T2.MOD_USER_ID,   
       T2.MOD_YMDHMS   
     );
     
  IF O_ERRORCODE <> '0' THEN
     O_ERRORCODE := -2000;
     O_ERRORMESG := '노선 정보 전월분 복사 오류: 당월('||TO_CHAR(SYSDATE,'YYYYMM')||')';
     RETURN;
  ELSE 
  
  
      MERGE INTO BET130 T1
    USING (
            SELECT T1.C_CD,          
                   T1.SEQ_NO,        
                   TO_CHAR(SYSDATE,'YYYYMM') AS STD_YM,
                   T1.ROUTE_CD,      
                   T1.STATION_SEQ_NO,
                   T1.STATION_NM,    
                   T1.STATION_TIME,  
                   T1.FILE_NO,       
                   T1.NOTE,          
                   I_MOD_USER_ID  AS INS_USER_ID,   
                   SYSDATE        AS INS_YMDHMS,    
                   I_MOD_USER_ID  AS MOD_USER_ID,  
                   SYSDATE        AS MOD_YMDHMS 
              FROM BET130 T1
             WHERE T1.C_CD   = I_C_CD 
               AND T1.STD_YM = TO_CHAR(TRUNC(ADD_MONTHS(SYSDATE, -1),'MM'), 'YYYYMM')
          ORDER BY T1.STD_YM    
    ) T2   
    ON (
            T1.C_CD           = T2.C_CD
        AND T1.SEQ_NO         = T2.SEQ_NO
        AND T1.STD_YM         = T2.STD_YM 
        AND T1.ROUTE_CD       = T2.ROUTE_CD
        AND T1.STATION_SEQ_NO = T2.STATION_SEQ_NO
        )
     WHEN MATCHED THEN UPDATE SET        
       T1.MOD_USER_ID   = I_MOD_USER_ID,
       T1.MOD_YMDHMS    = SYSDATE         
     WHEN NOT MATCHED THEN INSERT
     (
       T1.C_CD,          
       T1.SEQ_NO,        
       T1.STD_YM,
       T1.ROUTE_CD,      
       T1.STATION_SEQ_NO,
       T1.STATION_NM,    
       T1.STATION_TIME,  
       T1.FILE_NO,       
       T1.NOTE,          
       T1.INS_USER_ID,   
       T1.INS_YMDHMS,    
       T1.MOD_USER_ID,   
       T1.MOD_YMDHMS  
     )
     VALUES
     (
       T2.C_CD,          
       T2.SEQ_NO,        
       T2.STD_YM,
       T2.ROUTE_CD,      
       T2.STATION_SEQ_NO,
       T2.STATION_NM,    
       T2.STATION_TIME,  
       T2.FILE_NO,       
       T2.NOTE,          
       T2.INS_USER_ID,   
       T2.INS_YMDHMS,    
       T2.MOD_USER_ID,   
       T2.MOD_YMDHMS  
     );   
     
     IF O_ERRORCODE <> '0' THEN
        O_ERRORCODE := -2000;
        O_ERRORMESG := '정류장 정보 전월분 복사 오류: 당월('||TO_CHAR(SYSDATE,'YYYYMM')||')';
        RETURN;     
     END IF;   
  END IF;

  O_ERRORCODE := '0';
  O_ERRORMESG := '성공';
  */

  O_ERRORCODE := 0;
  O_ERRORMESG := '';
  
EXCEPTION
  WHEN OTHERS
  THEN
        O_ERRORCODE := SQLCODE;
        O_ERRORMESG := 'P_BE_COMUT_001_M01( PM9999 ), '|| SQLERRM;
END;
/
