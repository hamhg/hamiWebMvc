CREATE VIEW ORG_V_GUCC_20151016 AS SELECT 'H139' AS COMPANY_CODE,
            U1.OBJ_ID AS ORG_CODE,
            F_GET_OBJNM (U1.C_CD,
                         U1.OBJ_TYPE,
                         U1.OBJ_ID,
                         TO_CHAR (SYSDATE, 'YYYYMMDD'))
               AS ORG_NAME,
            F_ORG_ENG_NM (U1.C_CD,
                          TO_CHAR (SYSDATE, 'YYYYMMDD'),
                          U1.OBJ_ID,
                          '4')
               AS ORG_ENG_NAME,
            CASE
               WHEN U1.PAR_OBJ_ID = '0000000000' THEN NULL
               ELSE U1.PAR_OBJ_ID
            END
               AS HI_ORG_CODE,
            U2.ORG_CLASS AS ORG_HD_ASGN_CODE,
            F_GET_CODENM (U2.C_CD, 'OM010', U2.ORG_CLASS) AS ORG_HD_ASGN_NAME,
            SUBSTR (U3.EMP_ID, 3, 7) AS ORG_HD_ID,
            U4.EMP_NM AS ORG_HD_NAME,
            NULL AS ORG_HD_ENG_NAME,
            U3.DUTY_CD AS ORG_GRADE_CODE,
            F_GET_CODENM (U3.C_CD, '/SY05', U3.DUTY_CD) AS ORG_GRADE_NAME,
            NULL AS COMPANY_GRP_CODE,
            NULL AS COMPANY_DET_CODE,
            NULL AS ING_ORG_FLAG,
            '1' AS WP_CODE,
            '본사' AS WP_NAME,
            NULL AS WP_ENG_NAME,
            NULL AS SUB_ORG_FLAG,
            NULL AS EX_ORG_FLAG,
            TO_CHAR (
               CASE WHEN U1.OBJ_ID = 'O000000001' THEN 1 ELSE U1.SEQ_NO END,
               '00000')
               AS SORT_NO,
            TO_NUMBER (U2.ORG_CLASS) AS ORG_RANK,
            TO_CHAR (
               CASE WHEN U1.OBJ_ID = 'O000000001' THEN 1 ELSE U1.SEQ_NO END,
               '00000')
               AS ORG_PRT_ORDER,
            'Y' AS USE_FLAG,
            NULL AS DELETE_DATE,
            NULL AS COMM_ORG_CODE,
            NULL AS CUSTOM_ATTR1,
            NULL AS CUSTOM_ATTR2,
            NULL AS CUSTOM_ATTR3,
            NULL AS CUSTOM_ATTR4,
            NULL AS CUSTOM_ATTR5,
            NULL AS WORK_TYPE,
            NULL AS WORK_DATE
       FROM (           SELECT LEVEL AS LEVEL_NO, T1.*
                          FROM (SELECT T1.*
                                  FROM SY3020 T1
                                 WHERE     T1.OBJ_TYPE IN (SELECT A.OBJ_TYPE
                                                             FROM SY3080 A
                                                            WHERE A.OBJ_TREE_TYPE =
                                                                     'ORGTREE')
                                       AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                             AND T1.END_YMD)
                               T1
                    START WITH     1 = 1
                               AND (T1.C_CD, T1.OBJ_TYPE, T1.OBJ_ID) IN (SELECT C_CD,
                                                                                ROOT_OBJ_TYPE,
                                                                                ROOT_OBJ_ID
                                                                           FROM SY3070
                                                                          WHERE     OBJ_TREE_TYPE =
                                                                                       'ORGTREE'
                                                                                AND TO_CHAR (
                                                                                       SYSDATE,
                                                                                       'YYYYMMDD') BETWEEN STA_YMD
                                                                                                       AND END_YMD)
                               AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                     AND T1.END_YMD
                    CONNECT BY     1 = 1
                               AND PRIOR T1.C_CD = T1.C_CD
                               AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
                               AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
             ORDER SIBLINGS BY T1.SEQ_NO) U1,
            OM0010 U2,
            OM0020 U3,
            PA1010# U4
      WHERE     U1.C_CD = U2.C_CD(+)
            AND U1.OBJ_ID = U2.ORG_ID(+)
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN U2.STA_YMD(+)
                                                  AND U2.END_YMD(+)
            AND U1.C_CD = U3.C_CD(+)
            AND U1.OBJ_ID = U3.ORG_ID(+)
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN U3.STA_YMD(+)
                                                  AND U3.END_YMD(+)
            AND U3.C_CD = U4.C_CD(+)
            AND U3.EMP_ID = U4.EMP_ID(+)
            --AND U3.ORG_ID(+) NOT IN ('O000000928','OAMCQ11211','O000001017','OAMCO11211','O000001290','O000001291')  -- 인사팀 배치대기 조직은 제외
            AND U1.OBJ_ID NOT IN ('O000000928',
                                  'OAMCQ11211',
                                  'O000001017',
                                  'OAMCO11211',
                                  'O000001290',
                                  'O000001291')             -- 인사팀 배치대기 조직은 제외
   ORDER BY U1.SEQ_NO
/
COMMENT ON VIEW ORG_V_GUCC_20151016 IS 'GUCC 연동용 조직뷰'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.COMPANY_CODE IS '회사코드(GMDM)'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.ORG_CODE IS '부서(조직)코드'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.ORG_NAME IS '부서(조직) 명'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.ORG_ENG_NAME IS '부서(조직) 영문명'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.HI_ORG_CODE IS '상위부서(조직) 코드'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.ORG_HD_ASGN_CODE IS '부서(조직) 등급'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.ORG_HD_ASGN_NAME IS '부서(조직) 등급 명'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.ORG_HD_ID IS '조직장 사번'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.ORG_HD_NAME IS '조직장 이름'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.ORG_HD_ENG_NAME IS '조직장 영문이름'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.ORG_GRADE_CODE IS '조직장 호칭'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.ORG_GRADE_NAME IS '조직장 호칭 명'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.WP_CODE IS '소재지역'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.WP_NAME IS '소재지역 명'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.WP_ENG_NAME IS '소재지역 영문 명'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.SORT_NO IS '조직순서'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.ORG_RANK IS '조직레벨'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.ORG_PRT_ORDER IS '출력순서'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.USE_FLAG IS '사용여부'
/
COMMENT ON COLUMN ORG_V_GUCC_20151016.DELETE_DATE IS '폐지일자'
/
