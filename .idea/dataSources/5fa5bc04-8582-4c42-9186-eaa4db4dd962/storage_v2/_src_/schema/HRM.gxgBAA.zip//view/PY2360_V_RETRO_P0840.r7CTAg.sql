CREATE VIEW PY2360_V_RETRO_P0840 AS SELECT   T0.C_CD,
              T0.PAYROLL_NO,
              T2.EMP_ID,
              'P0840' AS PAYITEM                                   -- 급여소급
                                ,
              '급여소급' AS PAYITEM_NM,
              SUM (T2.LAST_MON) AS LAST_MON,
              '1' AS PAYITEM_TYPE,
              998 AS ORDER_NO
       FROM   PY0300 T0                                         -- 현 급여정보
                       ,
              PY0990 T1                                        -- 소급적용기준
                       ,
              PY2360 T2                                     -- 소급용 계산결과
                       ,
              PY0300 T3                                   -- 소급용 급여일정보
      WHERE       1 = 1
              AND T1.C_CD = T0.C_CD
              AND T1.ORGN_YM = T0.ORGN_YM
              AND T1.PAYROLL_TYPE = T0.PAYROLL_TYPE
              AND T2.C_CD = T1.C_CD
              AND T2.PAYROLL_NO = T1.PAYROLL_NO                -- 소급계산번호
              AND T2.LAST_MON <> 0
              AND T3.C_CD = T2.C_CD
              AND T3.PAYROLL_NO = T2.ORGN_PAYROLL_NO  -- 소급결과의 원계산번호
              AND T3.PAYROLL_TYPE = '01'
   GROUP BY   T0.C_CD, T0.PAYROLL_NO, T2.EMP_ID
    --// [2012.06.07] PY2360_V_ERP 내에서 이용되었으나, 성능 개선을 위해 제거
    --   : 다른 곳에서 사용되는지 확인이 요구됨 
/
