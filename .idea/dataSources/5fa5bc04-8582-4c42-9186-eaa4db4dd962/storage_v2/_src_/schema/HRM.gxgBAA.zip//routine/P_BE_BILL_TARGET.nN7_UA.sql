CREATE PROCEDURE     P_BE_BILL_TARGET(
                            I_C_CD         IN  VARCHAR2, --회사코드 
                            I_EMP_ID       IN  VARCHAR2, --사번
                            I_SEQ_NO       IN  NUMBER,   --순번  
                            I_FAM_PER_NO   IN  VARCHAR2, --부모님주민번호
                            I_CR_BIRTH_YMD IN  VARCHAR2, --부모님생신일 
                            I_BILL_YMD     IN  VARCHAR2, --증빙일 
                            I_MOD_USER_ID  IN  VARCHAR2, --로그인유저 아이디 
                            O_ERRORCODE    OUT VARCHAR2,
                            O_ERRORMESG    OUT VARCHAR2,
                            O_SEQ_NO       OUT VARCHAR2
)
IS
/***********************************************************************
 Program Name   : P_BE_BILL_TARGET
 Description    : 복리후생 전표대상 프로시져 
 Author         : 윤병근 
 History        : 2010-10-25
***********************************************************************/

  R1 BEPBILL_TEMP#%ROWTYPE;
  --V_SEQ_NO NUMBER; 
BEGIN

/*
  --=================================  
  --== BEPBILL_TEMP# 순번           ==
  --=================================
  BEGIN 
  
      SELECT NVL(MAX(SEQ_NO)+1, 1)
        INTO V_SEQ_NO
        FROM BEPBILL_TEMP#; 
  EXCEPTION
     WHEN OTHERS THEN 
          RAISE_APPLICATION_ERROR( -20000, 'BEPBILL_TEMP# 순번 채번 ERROR');
          RETURN;                         
   
  END; 
*/
  --===================================================
  --== BEPBILL_TEMP#  ( 전표대상 테이블 구성 작업     ==
  --=================================================== 
  
  FOR CUR1 IN(
               SELECT T1.C_CD,
                      T1.EMP_ID,
                      T1.FAM_PER_NO,  
                      T1.CR_BIRTH_YMD,
                      T1.GFT_CD,
                      T3.EVIDENCECODE,              
                      T1.ACCOUNT_ID, 
                      T1.PAY_YMD,                      
                      SUM(T3.GFT_MON) AS GFT_MON,
                      SUM(T3.GFT_VAT) AS GFT_VAT
                 FROM BEP200#     T1,
                      PA1020_V_1 T2,
                      BEP110     T3
                WHERE T1.C_CD       = T2.C_CD
                  AND T1.EMP_ID     = T2.EMP_ID 
                  AND T1.ACCOUNT_ID = T3.ACCOUNT_ID
                  AND T1.GFT_CD     = T3.GFT_CD 
                  AND T1.C_CD         = I_C_CD
                  AND T1.EMP_ID       = I_EMP_ID
                  AND T1.FAM_PER_NO   = F_HEC_ENC_PER(I_FAM_PER_NO)
                  AND T1.CR_BIRTH_YMD = I_CR_BIRTH_YMD
                  AND T1.PAY_YN = 'Y'
                 -- AND NVL(T1.BILL_SEQ_NO,0) = 0
               GROUP BY T1.C_CD,   T1.EMP_ID,       T1.FAM_PER_NO, T1.CR_BIRTH_YMD, 
                        T1.GFT_CD, T3.EVIDENCECODE, T1.ACCOUNT_ID, T1.PAY_YMD
                             
            )
            LOOP
              
              --=================================  
              --== 저장 변수 셋팅              ==
              --=================================              
              
              R1.C_CD         := CUR1.C_CD;
              R1.EMP_ID       := CUR1.EMP_ID;
              R1.FAM_PER_NO   := CUR1.FAM_PER_NO;
              R1.CR_BIRTH_YMD := CUR1.CR_BIRTH_YMD;
              R1.GFT_CD       := CUR1.GFT_CD;
              R1.EVIDENCECODE := CUR1.EVIDENCECODE;
              R1.ACCOUNT_ID   := CUR1.ACCOUNT_ID;
              R1.GFT_MON      := CUR1.GFT_MON;
              R1.GFT_VAT      := CUR1.GFT_VAT; 
              R1.PAY_YMD      := CUR1.PAY_YMD;
              R1.BILL_YMD     := I_BILL_YMD;
              R1.INS_USER_ID  := I_MOD_USER_ID;
              R1.INS_YMDHMS   := SYSDATE;
              R1.MOD_USER_ID  := I_MOD_USER_ID;
              R1.MOD_YMDHMS   := SYSDATE;
              
              BEGIN
                 
                  INSERT INTO BEPBILL_TEMP#
                            (
                               C_CD,          SEQ_NO,       EMP_ID,        FAM_PER_NO,  
                               CR_BIRTH_YMD,  GFT_CD,       EVIDENCECODE,  ACCOUNT_ID,  
                               GFT_MON,       GFT_VAT,      PAY_YMD,       BILL_YMD,    
                               BILL_SEQ_NO,   INS_USER_ID,  INS_YMDHMS,    MOD_USER_ID, 
                               MOD_YMDHMS  
                            )
                      VALUES
                           (
                               R1.C_CD,         I_SEQ_NO,        R1.EMP_ID,        R1.FAM_PER_NO,  
                               R1.CR_BIRTH_YMD, R1.GFT_CD,       R1.EVIDENCECODE,  R1.ACCOUNT_ID,  
                               R1.GFT_MON,      R1.GFT_VAT,      R1.PAY_YMD,       R1.BILL_YMD,    
                               R1.BILL_SEQ_NO,  R1.INS_USER_ID,  R1.INS_YMDHMS,    R1.MOD_USER_ID,   
                               R1.MOD_YMDHMS   
                           );
               EXCEPTION
                  WHEN OTHERS THEN         
                       RAISE_APPLICATION_ERROR( -20000, 'BEPBILL_TEMP# 저장 ERROR');
                       RETURN;                         
               END;        
            END LOOP;
      
  O_ERRORCODE := '0';
  
  O_SEQ_NO := I_SEQ_NO;
   

--COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    O_ERRORCODE := SQLCODE;
    O_ERRORMESG := SQLERRM;
END;
/
