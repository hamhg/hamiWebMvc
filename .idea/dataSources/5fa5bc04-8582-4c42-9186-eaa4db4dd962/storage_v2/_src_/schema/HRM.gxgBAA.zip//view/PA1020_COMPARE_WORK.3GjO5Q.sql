CREATE VIEW PA1020_COMPARE_WORK AS SELECT   T1.EMP_ID,
              T2.EMP_NM,
              t1.sta_ymd,
              t1.sch_end_ymd,
              T1.APPNT_CD,
              T1.APPNT_NM,
              T1.ORG_ID,
              t1.ORG_ID_LEG,
              T1.ORG_NM,
              T1.WORK_LOC_ID,
              T1.WORK_LOC_NM,
              T1.POST_CD,
              T1.POST_NM,
              (SELECT   WK_SITE
                 FROM   SY3010
                WHERE       C_cD = T1.C_CD
                        AND OBJ_TYPE = 'WA'
                        AND OBJ_ID = T1.WORK_LOC_ID
                        AND T1.STA_YMD BETWEEN STA_YMD AND END_YMD)
                 CUR_WK_SITE,
              (SELECT   WK_SITE
                 FROM   SY3010
                WHERE       C_CD = T1.C_CD
                        AND OBJ_TYPE LIKE 'O%'
                        AND OBJ_ID = T1.ORG_ID
                        AND T1.STA_YMD BETWEEN STA_YMD AND END_YMD
                        AND ROWNUM = 1)
                 CUR_ORG_ID_LEG
       FROM   PA1020 T1, PA1010# T2
      WHERE       T1.C_CD = 'HEC'
              AND T2.C_CD = T1.C_CD
              AND T2.EMP_ID = T1.EMP_ID
              AND T2.STAT_CD LIKE '1%'
              AND T2.EMP_TYPE NOT IN ('P', '8', 'O', '8P', '8H')
              AND T1.APPNT_CD <> '60'
   ORDER BY   T1.EMP_ID, T1.STA_YMD, T1.SEQ_NO
/
