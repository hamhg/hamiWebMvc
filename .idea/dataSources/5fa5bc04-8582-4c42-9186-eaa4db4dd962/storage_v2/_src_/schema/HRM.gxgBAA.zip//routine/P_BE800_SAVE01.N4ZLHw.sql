CREATE PROCEDURE P_BE800_SAVE01( I_C_CD         IN VARCHAR2 --
                                           ,I_IUD          IN VARCHAR2 --
                                           ,I_EMP_ID       IN VARCHAR2 --
                                           ,I_STA_YMD      IN VARCHAR2 -- 시작일
                                           ,I_END_YMD      IN VARCHAR2 -- 종료일
                                           ,I_CARD_NO      IN VARCHAR2 -- 카드번호
                                           ,I_RES_TYPE     IN VARCHAR2 -- 구분(분실유형)
                                           ,I_REC_YMD      IN VARCHAR2 -- 회수일자
                                           ,I_NOTE         IN VARCHAR2 -- 비고
                                           ,I_MOD_USER_ID  IN VARCHAR2 --
                                           ,O_ERRORCODE   OUT VARCHAR2
                                           ,O_ERRORMESG   OUT VARCHAR2
                                           )
IS
/***********************************************************************
 Program Name   : P_BE800_SAVE01
 Description    : 인사기본 외주 전직경력tab 출입증번호 update 로직
 Author         :  
 History        : 
***********************************************************************/

   AV_CNT      NUMBER :=0;
   AV_EMP_TYPE VARCHAR2(1000);
   
BEGIN
   
   -- 직원구분 가져오기 
/*  
   SELECT EMP_TYPE
     INTO AV_EMP_TYPE
     FROM PA1020
    WHERE EMP_ID  = I_EMP_ID
      AND LAST_YN = 'Y'
      AND I_END_YMD  BETWEEN STA_YMD AND END_YMD;
*/
   
   -- 일용직 DEFAULT
   AV_EMP_TYPE := 'P';
   
   -- 외주
   IF INSTR(I_EMP_ID,'P') = 0 THEN 
      AV_EMP_TYPE := '8';
   END IF;
       
   
   -- 출입증이력 변경시 종료일 기준으로 관련 계약정보가 존재하는지 확인       
   -- 일용직 계약정보
   IF AV_EMP_TYPE IN ('P') THEN
      SELECT COUNT(EMP_ID)
        INTO AV_CNT
        FROM PA2271
       WHERE EMP_ID = I_EMP_ID
         AND I_END_YMD  BETWEEN STA_YMD AND END_YMD;
   -- 외주계약정보  
   ELSIF AV_EMP_TYPE IN ('8','8P','8H') THEN
         SELECT COUNT(EMP_ID)
           INTO AV_CNT
           FROM PA2065
          WHERE EMP_ID = I_EMP_ID
            AND I_END_YMD  BETWEEN STA_YMD AND END_YMD;
   -- 일용직, 외주가 아니면 에러
   ELSE
      RAISE_APPLICATION_ERROR(-20000, '사번:' || I_EMP_ID  || CHR(13) || '발령 오류사항이 존재합니다.' || CHR(13) || '정보기술지원팀에 문의 바랍니다.');
      RETURN;
   
   END IF;
       
         
   -- 계약존재여부 체크
   IF AV_CNT = 0 THEN
      RAISE_APPLICATION_ERROR(-20000, '사번:' || I_EMP_ID  || CHR(13) || '계약정보가 존재하지 않습니다.' || CHR(13) || '계약정보 확인 바랍니다.');
      RETURN;
   END IF;
   
   
   
   
   -- 출입증 이력정보 INSERT, UPDATE, DELETE
   -- BEE300 
   IF AV_CNT > 0 AND I_IUD IN ('I') THEN
      INSERT INTO BEE300
      SELECT  I_C_CD        --회사코드
             ,I_EMP_ID      --사번
             ,I_STA_YMD     --출입증사용시작일
             ,I_END_YMD     --출입증사용종료일
             ,I_CARD_NO     --출입증번호
             ,I_RES_TYPE    --사유
             ,I_REC_YMD     --회수일자
             ,I_NOTE        --비고
             ,I_MOD_USER_ID --입력자ID
             ,SYSDATE       --입력일시
             ,I_MOD_USER_ID --작업자ID
             ,SYSDATE       --수정일시
        FROM DUAL;
        
        
    ELSIF AV_CNT > 0 AND I_IUD IN ('U') THEN  
          UPDATE BEE300
             SET END_YMD     = I_END_YMD    --출입증사용종료일
                ,CARD_NO     = I_CARD_NO    --출입증번호
                ,RES_TYPE    = I_RES_TYPE   --사유
                ,REC_YMD     = I_REC_YMD    --회수일자
                ,NOTE        = I_NOTE       --비고
                ,MOD_USER_ID = I_MOD_USER_ID--작업자ID
                ,MOD_YMDHMS  = SYSDATE      --수정일시
           WHERE C_CD    = I_C_CD
             AND EMP_ID  = I_EMP_ID
             AND STA_YMD = I_STA_YMD ;
        
             
    ELSIF AV_CNT > 0 AND I_IUD IN ('D') THEN  
          DELETE BEE300
           WHERE C_CD    = I_C_CD
             AND EMP_ID  = I_EMP_ID
             AND STA_YMD = I_STA_YMD ;              
    END IF;
   
   
   
   
   
   -- 이력정보 DELETE할때가 문제임.....
   
   --계약이 존재하고 INSERT, UPDATE이고 일용직 이면   
   IF AV_CNT > 0 AND I_IUD IN ('I','U') AND AV_EMP_TYPE IN ('P') THEN
      -- 일용직
      UPDATE PA2271
         SET ACCESS_CARD_NO = I_CARD_NO 
       WHERE EMP_ID         = I_EMP_ID
         AND I_END_YMD  BETWEEN STA_YMD AND END_YMD;
         
   -- INSERT, UPDATE이면   
   ELSIF AV_CNT > 0 AND I_IUD IN ('I','U') AND AV_EMP_TYPE IN ('8','8P','8H') THEN
     -- 외주직
      UPDATE PA2065
         SET ENTERID = I_CARD_NO 
       WHERE EMP_ID  = I_EMP_ID
         AND I_END_YMD  BETWEEN STA_YMD AND END_YMD;
           
   -- DELETE로직 없음. 
   ELSIF AV_CNT > 0 AND I_IUD IN ('D')  AND AV_EMP_TYPE IN ('P')  THEN
         -- 일용직
         UPDATE PA2271
            SET ACCESS_CARD_NO = '' 
          WHERE EMP_ID         = I_EMP_ID
            AND I_END_YMD  BETWEEN STA_YMD AND END_YMD;
   
   ELSIF AV_CNT > 0 AND I_IUD IN ('D')  AND AV_EMP_TYPE IN ('8','8P','8H') THEN
         -- 외주직
         UPDATE PA2065
            SET ENTERID = '' 
          WHERE EMP_ID  = I_EMP_ID
            AND I_END_YMD  BETWEEN STA_YMD AND END_YMD;
   
   END IF;
   
   
   O_ERRORCODE := '0';
   O_ERRORMESG := '성공';

EXCEPTION
  WHEN OTHERS
  THEN
    O_ERRORCODE := SQLCODE; 
    O_ERRORMESG := SQLERRM;   
END;

/
