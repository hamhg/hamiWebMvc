CREATE VIEW EMP_V_GUCC_BAK AS SELECT   T1.EMP_ID,
            T1.EMP_NM,
            T1.ENG_EMP_NM,
            T2.ORG_ID,
            F_ORG_NM (T2.C_CD,
                      TO_CHAR (SYSDATE, 'YYYYMMDD'),
                      T2.ORG_ID,
                      '4')
               ORG_NM,
            F_ORG_ENG_NM (T2.C_CD,
                          TO_CHAR (SYSDATE, 'yyyymmdd'),
                          T2.ORG_ID,
                          '4')
               ENG_ORG_NM,
            T1.WORK_LOC_TEL_NO,
            T1.MOBILE_NO,
            T1.WORK_LOC_FAX,
            T1.MAIL_ADDR,
            T2.WORK_LOC_ID,
            F_GET_OBJNM (T2.C_CD,
                         'WA',
                         T2.WORK_LOC_ID,
                         TO_CHAR (SYSDATE, 'YYYYMMDD'))
               WORK_LOC_NM,
            F_GET_CODENM (T3.C_CD, 'OM010', T3.ORG_CLASS) ORG_CLASS_NM,
            T3.ORG_CLASS,
            T4.DP_ORDER,
            T2.EMP_GRADE_CD,
            F_GET_CODENM (T2.C_CD, '/SY03', T2.EMP_GRADE_CD) EMP_GRADE_NM,
            T2.EMP_TYPE
     FROM   PA1010# T1,
            PA1020 T2,
            OM0010 T3,
            SY5020 T4
    WHERE   T1.C_CD = T2.C_CD(+) AND T1.EMP_ID = T2.EMP_ID(+)
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD(+)
                                                  AND  T2.END_YMD(+)
            AND T2.LAST_YN(+) = 'Y'
            AND T2.C_CD = T3.C_CD(+)
            AND T2.ORG_ID = T3.ORG_ID(+)
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T3.STA_YMD(+)
                                                  AND  T3.END_YMD(+)
            AND T2.C_CD = T4.C_CD(+)
            AND T4.IDX_CD(+) = '/SY04'
            AND T2.POST_CD = T4.CD(+)
            AND T2.STAT_CD LIKE '1%'
/
COMMENT ON VIEW EMP_V_GUCC_BAK IS 'GUCC 연동용 인사뷰'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.EMP_NO IS '사번'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.EMP_NAME IS '성명'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.EMP_ENG_NAME IS '영문성명'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.ORG_CODE IS '부서코드'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.ORG_NAME IS '부서명'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.ORG_ENG_NAME IS '영문부서명'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.CORP_TEL_NO IS '회사전화번호'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.MOBILE IS '핸드폰'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.FAX IS '팩스'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.EMAIL IS '이메일'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.WP_CODE IS '근무지코드'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.WP_NAME IS '근무지명'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.ORG_GRD_NAME IS '주직등급명'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.ORG_GRD_CODE IS '조직등급코드'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.POS_LEVEL IS '직위레벨'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.GRADE_CODE IS '직급코드'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.GRADE_NAME IS '직급명'
/
COMMENT ON COLUMN EMP_V_GUCC_BAK.USER_TYPE IS '사용자구분'
/
