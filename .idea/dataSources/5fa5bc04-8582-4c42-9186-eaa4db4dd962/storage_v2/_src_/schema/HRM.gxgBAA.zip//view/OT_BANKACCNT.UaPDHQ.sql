CREATE VIEW OT_BANKACCNT AS SELECT EMP_ID,
          BANK_CD,
          F_HEC_DEC_ACC(ACC_NO) AS ACC_NO,
          STA_YMD,
          END_YMD,
          ACC_TYPE
     FROM PY2060#
    WHERE C_CD = 'HEC'
      AND EMP_ID LIKE '%'
      AND ACC_TYPE = 'JAN' 
      AND END_YMD = '99991231'
/
