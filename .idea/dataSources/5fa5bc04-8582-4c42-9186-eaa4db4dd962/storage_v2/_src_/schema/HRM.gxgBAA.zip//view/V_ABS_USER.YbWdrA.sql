CREATE VIEW V_ABS_USER AS SELECT T1.EMP_ID,
          T1.EMP_NM,
          T2.ORG_ID,
          F_ORG_NM (T2.C_CD,
                    TO_CHAR (SYSDATE, 'YYYYMMDD'),
                    T2.ORG_ID,
                    4)
             AS ORG_NM,
          T2.WORK_LOC_ID,
          F_GET_OBJNM (T2.C_CD,
                       'WA',
                       T2.WORK_LOC_ID,
                       TO_CHAR (SYSDATE, 'YYYYMMDD'))
             AS WORK_LOC_NM,
          -- 직군통합에 따른 수정. 2014.08.18
          T2.POST_CD2 AS POST_CD,
          F_GET_CODENM (T2.C_CD, '00100', T2.POST_CD2) AS POST_NM,
          --            T2.POST_CD,
          --            F_GET_CODENM (T2.C_CD, '/SY04', T2.POST_CD) AS POST_NM,
          T2.DUTY_CD,
          F_GET_CODENM (T2.C_CD, '/SY05', T2.DUTY_CD) AS DUTY_NM,
          T1.WORK_LOC_TEL_NO,
          T1.TEL_NO,
          T1.MOBILE_NO,
          T1.MAIL_ADDR,
          (SELECT S1.JOB_TXT
             FROM PA2170 S1
            WHERE     S1.C_CD = T1.C_CD
                  AND S1.EMP_ID = T1.EMP_ID
                  AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN S1.STA_YMD
                                                            AND S1.END_YMD
                  AND ROWNUM = 1)
             AS JOB_TXT,
          T1.ENTER_YMD,
          T1.RETIRE_YMD,
          T2.EMP_TYPE,
          F_GET_CODENM (T2.C_CD, '/SY01', T2.EMP_TYPE) AS EMP_TYPE_NM,
          NVL (T3.OTP_YN, 'N')
     FROM PA1010# T1, PA1020 T2, OTP_USE T3
    WHERE     T1.C_CD = T2.C_CD
          AND T1.EMP_ID = T2.EMP_ID
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                    AND T2.END_YMD
          AND T1.RETIRE_YMD IS NULL         --// (금일 기준) 재직자만 조회 (미래 퇴직발령자 제외)
          AND T2.LAST_YN = 'Y'
          AND T2.STAT_CD LIKE '1%'
          AND T2.EMP_TYPE NOT IN ('O', 'H')
          AND T1.EMP_ID = T3.USER_ID(+)
   UNION
   --===========================================
   --== 퇴사자만 조회 (TODO : 외주인 경우, 일괄/대량으로 퇴직발령 발생 가능성 있으므로, 별도 Query 고려할 것)
   --===========================================
   SELECT T1.EMP_ID,
          T1.EMP_NM,
          T2.ORG_ID,
          F_ORG_NM (T2.C_CD,
                    TO_CHAR (SYSDATE, 'YYYYMMDD'),
                    T2.ORG_ID,
                    4)
             AS ORG_NM,
          T2.WORK_LOC_ID,
          F_GET_OBJNM (T2.C_CD,
                       'WA',
                       T2.WORK_LOC_ID,
                       TO_CHAR (SYSDATE, 'YYYYMMDD'))
             AS WORK_LOC_NM,
          -- 직군통합에 따른 수정. 2014.08.18
          T2.POST_CD2 AS POST_CD,
          F_GET_CODENM (T2.C_CD, '00100', T2.POST_CD2) AS POST_NM,
          --            T2.POST_CD,
          --            F_GET_CODENM (T2.C_CD, '/SY04', T2.POST_CD) AS POST_NM,
          T2.DUTY_CD,
          F_GET_CODENM (T2.C_CD, '/SY05', T2.DUTY_CD) AS DUTY_NM,
          T1.WORK_LOC_TEL_NO,
          T1.TEL_NO,
          T1.MOBILE_NO,
          T1.MAIL_ADDR,
          (SELECT S1.JOB_TXT
             FROM PA2170 S1
            WHERE     S1.C_CD = T1.C_CD
                  AND S1.EMP_ID = T1.EMP_ID
                  AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN S1.STA_YMD
                                                            AND S1.END_YMD
                  AND ROWNUM = 1)
             AS JOB_TXT,
          T1.ENTER_YMD,
          T1.RETIRE_YMD,
          T2.EMP_TYPE,
          F_GET_CODENM (T2.C_CD, '/SY01', T2.EMP_TYPE) AS EMP_TYPE_NM,
          NVL (T3.OTP_YN, 'N')
     FROM PA1010# T1, PA1020 T2, OTP_USE T3
    WHERE     T1.C_CD = T2.C_CD
          AND T1.EMP_ID = T2.EMP_ID
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                    AND T2.END_YMD
          AND T2.LAST_YN = 'Y'
          AND T1.RETIRE_YMD IS NOT NULL
          AND T1.RETIRE_YMD BETWEEN TO_CHAR (SYSDATE - 14, 'YYYYMMDD')
                                AND TO_CHAR (SYSDATE, 'YYYYMMDD') --//(금일 기준) 2주 이전 퇴사일 등록자 조회
          AND T2.EMP_TYPE NOT IN ('O', 'H')
          AND T1.EMP_ID = T3.USER_ID(+)
/
COMMENT ON VIEW V_ABS_USER IS '[ABS_IF용] (V_ABS_USER)인사정보'
/
