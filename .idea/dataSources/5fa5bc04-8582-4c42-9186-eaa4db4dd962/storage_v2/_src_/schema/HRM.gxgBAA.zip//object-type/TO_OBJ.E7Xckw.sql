CREATE TYPE "TO_OBJ"                                                                                                                                                                                                     AS OBJECT
    (
      OBJ_TYPE VARCHAR2(20),
      OBJ_ID  VARCHAR2(50),
      DP_LEVEL INT,  
      DP_ORDER INT
    );
/
