CREATE VIEW PM2130_V_02 AS SELECT   'HEC' AS C_CD,
            -- SEQ_PM2130.NEXTVAL,
            '201007290001' AS EVU_STD_ID,
            T2.EMP_ID,
            (CASE WHEN T1.E_NO IS NOT NULL THEN 'Y' ELSE 'N' END) AS USE_YN,
            (SELECT   ORG_ID
               FROM   PA1020
              WHERE   C_CD = T2.C_CD AND EMP_ID = T2.EMP_ID
                      AND '20091109' BETWEEN STA_YMD
                                         AND  NVL (END_YMD, '29991231'))
               AS SUPER_ORG_ID,
            (SELECT   F_ORG_ID (C_CD,
                                '20091109',
                                ORG_ID,
                                '1')
               FROM   PA1020
              WHERE   C_CD = T2.C_CD AND EMP_ID = T2.EMP_ID
                      AND '20091109' BETWEEN STA_YMD
                                         AND  NVL (END_YMD, '29991231'))
               AS ORG_ID,
            T2.EMP_TYPE,
            T1.E_POS_CD,
            T1.E_DUTY_CD,
            (CASE
                WHEN DECODE (T1.e_subgroup,
                             NULL, T1.e_group,
                             T1.e_group || '-' || T1.e_subgroup) = '1'
                THEN
                   '110'
                WHEN DECODE (T1.e_subgroup,
                             NULL, T1.e_group,
                             T1.e_group || '-' || T1.e_subgroup) = '2'
                THEN
                   '120'
                WHEN DECODE (T1.e_subgroup,
                             NULL, T1.e_group,
                             T1.e_group || '-' || T1.e_subgroup) = '3'
                THEN
                   '130'
                WHEN DECODE (T1.e_subgroup,
                             NULL, T1.e_group,
                             T1.e_group || '-' || T1.e_subgroup) = '4-1'
                THEN
                   '140'
                WHEN DECODE (T1.e_subgroup,
                             NULL, T1.e_group,
                             T1.e_group || '-' || T1.e_subgroup) = '4-2'
                THEN
                   '150'
                WHEN DECODE (T1.e_subgroup,
                             NULL, T1.e_group,
                             T1.e_group || '-' || T1.e_subgroup) = '4-3'
                THEN
                   '160'
                WHEN DECODE (T1.e_subgroup,
                             NULL, T1.e_group,
                             T1.e_group || '-' || T1.e_subgroup) = '5-1'
                THEN
                   '170'
                WHEN DECODE (T1.e_subgroup,
                             NULL, T1.e_group,
                             T1.e_group || '-' || T1.e_subgroup) = '5-2'
                THEN
                   '180'
                ELSE
                   ''
             END)
               AS EVU_T_GRP_CD
     FROM   HECLEG.EV_PEMP T1,
            (SELECT   T2.*
               FROM   PA1010# T1, PA1020 T2
              WHERE       T1.C_CD = 'HEC'
                      AND T1.C_CD = T2.C_CD
                      AND T1.EMP_ID = T2.EMP_ID
                      AND '20091109' BETWEEN T1.ENTER_YMD
                                         AND  NVL (T1.RETIRE_YMD, '99991231')
                      AND '20091109' BETWEEN T2.STA_YMD
                                         AND  NVL (T2.END_YMD, '99991231'))
            T2
    WHERE       T2.EMP_ID = T1.E_NO(+)
            AND T1.YEAR(+) = '2009'
            AND T1.TERM(+) = '2'
/
