CREATE VIEW VI1050_V_HMGWARN AS SELECT T1.GROUP_VISIT_ID + T1.VISIT_ID + TO_NUMBER (T1.VIST_YMD)
             AS LOG_SEQ                                                -- 일련번호
                       ,
          T1.C_CD AS COMPANY_CD                                          -- 회사
                               ,
          T1.VIST_YMD AS DATE_VISIT                                      -- 방문일
                               ,
          SUBSTR (T2.EMP_ID, 3) AS EMP_ID                            -- 접견인원정보
                                         ,
          T3.POST_NM AS GRADE_NAME                                    -- 방문자직급
                                  ,
          (SELECT LISTAGG (S1.CD_NM, ',') WITHIN GROUP (ORDER BY S1.CD) CD_NM
             FROM GAIS.SY5020 S1
            WHERE     S1.IDX_CD = 'VI060'
                  AND S1.C_CD = T1.C_CD
                  AND INSTR (T1.VIST_PLACE, S1.CD) > 0
                  AND S1.USE_YN = 'Y')
             AS V_AREA                                                 -- 방문위치
                      ,
          T1.VIST_YMD || T1.STR_TIME AS V_ENTERDATE        -- 입문일시(방문일 + 방문시간)
                                                   ,
             CASE
                WHEN T1.END_TIME IS NOT NULL
                THEN
                   CASE
                      WHEN T1.END_TIME_GUBUN = '20'
                      THEN
                         TO_CHAR (TO_DATE (T1.VIST_YMD, 'YYYYMMDD') + 1,
                                  'YYYYMMDD')
                      ELSE
                         T1.VIST_YMD
                   END
             END
          || T1.END_TIME
             AS V_LEAVEDATE                                -- 출문일시(방문일 + 종료시간)
                           ,
          T3.COMPANY_NM AS V_COMPANY_NAME                              -- 방문업체
                                         ,
          T3.VIST_NM AS V_EMP_NAME                                   -- 방문자 이름
                                  ,
          T3.BIRTH_DT AS V_SSN                                     -- 방문자 생년월일
                              ,
          T3.PHONE_NO AS V_TELNO                              -- 방문자 연락처 (암호화)
                                ,
          GAIS.F_GET_CODENM (T3.C_CD, 'VI010', T3.VIST_TYPE) AS V_PURPOSE -- 방문목적(방문자 분류)
                                                                         ,
          T3.CAR_TYPE AS CAR_NM                                    -- 방문자 차량종류
                               ,
          T3.CAR_NUMBER AS CAR_NO                                  -- 방문자 차량번호
                                 ,
          T4.THING_TC1                                                -- 반입물품명
                      ,
          T4.THING_NM1                                             -- 반입물품 모델명
                      ,
          T4.SERIAL_NO1                                         -- 반입물품 시리얼 번호
                       ,
          T4.THING_TC2,
          T4.THING_NM2,
          T4.SERIAL_NO2,
          T4.THING_TC3,
          T4.THING_NM3,
          T4.SERIAL_NO3,
          T4.THING_TC4,
          T4.THING_NM4,
          T4.SERIAL_NO4,
          T4.THING_TC5,
          T4.THING_NM5,
          T4.SERIAL_NO5,
          T4.THING_TC6,
          T4.THING_NM6,
          T4.SERIAL_NO6,
          T4.THING_TC7,
          T4.THING_NM7,
          T4.SERIAL_NO7,
          T4.THING_TC8,
          T4.THING_NM8,
          T4.SERIAL_NO8,
          T4.THING_TC9,
          T4.THING_NM9,
          T4.SERIAL_NO9,
          T4.THING_TC10,
          T4.THING_NM10,
          T4.SERIAL_NO10,
          CASE
             WHEN (SELECT COUNT (*)
                     FROM GAIS.VI1070
                    WHERE     GROUP_VISIT_ID = T1.GROUP_VISIT_ID
                          AND VISIT_ID = T1.VISIT_ID
                          AND VIST_YMD = T1.VIST_YMD) > 0
             THEN
                'Y'
             ELSE
                'N'
          END
             AS USE_PORT                                            -- 포트 사용유무
                        ,
          CASE
             WHEN (SELECT COUNT (*)
                     FROM GAIS.VI1080
                    WHERE     GROUP_VISIT_ID = T1.GROUP_VISIT_ID
                          AND VISIT_ID = T1.VISIT_ID
                          AND VIST_YMD = T1.VIST_YMD) > 0
             THEN
                'Y'
             ELSE
                'N'
          END
             AS USE_Internet                                       -- 인터넷 사용우무
     FROM GAIS.VI1050 T1,
          GAIS.VI1010 T2,
          GAIS.VI1020 T3,
          (  SELECT C_CD,
                    GROUP_VISIT_ID,
                    VISIT_ID,
                    VIST_YMD,
                    MAX (
                       CASE SEQ_NO
                          WHEN 1
                          THEN
                             (SELECT GAIS.F_GET_CODENM (C_CD,
                                                        'VI050',
                                                        EQUIP_NM)
                                FROM DUAL)
                       END)
                       AS THING_TC1,
                    MAX (CASE SEQ_NO WHEN 1 THEN MODEL_NM END) AS THING_NM1,
                    MAX (CASE SEQ_NO WHEN 1 THEN SERIAL_NO END) AS SERIAL_NO1,
                    MAX (
                       CASE SEQ_NO
                          WHEN 2
                          THEN
                             (SELECT GAIS.F_GET_CODENM (C_CD,
                                                        'VI050',
                                                        EQUIP_NM)
                                FROM DUAL)
                       END)
                       AS THING_TC2,
                    MAX (CASE SEQ_NO WHEN 2 THEN MODEL_NM END) AS THING_NM2,
                    MAX (CASE SEQ_NO WHEN 2 THEN SERIAL_NO END) AS SERIAL_NO2,
                    MAX (
                       CASE SEQ_NO
                          WHEN 3
                          THEN
                             (SELECT GAIS.F_GET_CODENM (C_CD,
                                                        'VI050',
                                                        EQUIP_NM)
                                FROM DUAL)
                       END)
                       AS THING_TC3,
                    MAX (CASE SEQ_NO WHEN 3 THEN MODEL_NM END) AS THING_NM3,
                    MAX (CASE SEQ_NO WHEN 3 THEN SERIAL_NO END) AS SERIAL_NO3,
                    MAX (
                       CASE SEQ_NO
                          WHEN 4
                          THEN
                             (SELECT GAIS.F_GET_CODENM (C_CD,
                                                        'VI050',
                                                        EQUIP_NM)
                                FROM DUAL)
                       END)
                       AS THING_TC4,
                    MAX (CASE SEQ_NO WHEN 4 THEN MODEL_NM END) AS THING_NM4,
                    MAX (CASE SEQ_NO WHEN 4 THEN SERIAL_NO END) AS SERIAL_NO4,
                    MAX (
                       CASE SEQ_NO
                          WHEN 5
                          THEN
                             (SELECT GAIS.F_GET_CODENM (C_CD,
                                                        'VI050',
                                                        EQUIP_NM)
                                FROM DUAL)
                       END)
                       AS THING_TC5,
                    MAX (CASE SEQ_NO WHEN 5 THEN MODEL_NM END) AS THING_NM5,
                    MAX (CASE SEQ_NO WHEN 5 THEN SERIAL_NO END) AS SERIAL_NO5,
                    MAX (
                       CASE SEQ_NO
                          WHEN 6
                          THEN
                             (SELECT GAIS.F_GET_CODENM (C_CD,
                                                        'VI050',
                                                        EQUIP_NM)
                                FROM DUAL)
                       END)
                       AS THING_TC6,
                    MAX (CASE SEQ_NO WHEN 6 THEN MODEL_NM END) AS THING_NM6,
                    MAX (CASE SEQ_NO WHEN 6 THEN SERIAL_NO END) AS SERIAL_NO6,
                    MAX (
                       CASE SEQ_NO
                          WHEN 7
                          THEN
                             (SELECT GAIS.F_GET_CODENM (C_CD,
                                                        'VI050',
                                                        EQUIP_NM)
                                FROM DUAL)
                       END)
                       AS THING_TC7,
                    MAX (CASE SEQ_NO WHEN 7 THEN MODEL_NM END) AS THING_NM7,
                    MAX (CASE SEQ_NO WHEN 7 THEN SERIAL_NO END) AS SERIAL_NO7,
                    MAX (
                       CASE SEQ_NO
                          WHEN 8
                          THEN
                             (SELECT GAIS.F_GET_CODENM (C_CD,
                                                        'VI050',
                                                        EQUIP_NM)
                                FROM DUAL)
                       END)
                       AS THING_TC8,
                    MAX (CASE SEQ_NO WHEN 8 THEN MODEL_NM END) AS THING_NM8,
                    MAX (CASE SEQ_NO WHEN 8 THEN SERIAL_NO END) AS SERIAL_NO8,
                    MAX (
                       CASE SEQ_NO
                          WHEN 9
                          THEN
                             (SELECT GAIS.F_GET_CODENM (C_CD,
                                                        'VI050',
                                                        EQUIP_NM)
                                FROM DUAL)
                       END)
                       AS THING_TC9,
                    MAX (CASE SEQ_NO WHEN 9 THEN MODEL_NM END) AS THING_NM9,
                    MAX (CASE SEQ_NO WHEN 9 THEN SERIAL_NO END) AS SERIAL_NO9,
                    MAX (
                       CASE SEQ_NO
                          WHEN 10
                          THEN
                             (SELECT GAIS.F_GET_CODENM (C_CD,
                                                        'VI050',
                                                        EQUIP_NM)
                                FROM DUAL)
                       END)
                       AS THING_TC10,
                    MAX (CASE SEQ_NO WHEN 10 THEN MODEL_NM END) AS THING_NM10,
                    MAX (CASE SEQ_NO WHEN 10 THEN SERIAL_NO END) AS SERIAL_NO10
               FROM GAIS.VI1060
           GROUP BY C_CD,
                    GROUP_VISIT_ID,
                    VISIT_ID,
                    VIST_YMD) T4
    WHERE     T1.C_CD = 'HEC'
          AND T1.STR_TIME IS NOT NULL
          AND T2.C_CD = T1.C_CD
          AND T2.GROUP_VISIT_ID = T1.GROUP_VISIT_ID
          AND T3.C_CD = T1.C_CD
          AND T3.GROUP_VISIT_ID = T1.GROUP_VISIT_ID
          AND T3.VISIT_ID = T1.VISIT_ID
          AND T4.C_CD(+) = T1.C_CD
          AND T4.GROUP_VISIT_ID(+) = T1.GROUP_VISIT_ID
          AND T4.VISIT_ID(+) = T1.VISIT_ID
          AND T4.VIST_YMD(+) = T1.VIST_YMD
/
COMMENT ON VIEW VI1050_V_HMGWARN IS '방문자관리-조기경보시스템 연동'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.LOG_SEQ IS '일련번호'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.COMPANY_CD IS '회사'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.DATE_VISIT IS '방문예약일자'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.EMP_ID IS '접견인원 정보'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.GRADE_NAME IS '직급'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.V_AREA IS '방문지역'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.V_ENTERDATE IS '입문일시'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.V_LEAVEDATE IS '출문일시'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.V_COMPANY_NAME IS '방문업체'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.V_EMP_NAME IS '방문자 이름'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.V_SSN IS '방문자 생년월일'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.V_TELNO IS '방문자 연락처'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.V_PURPOSE IS '방문목적'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.CAR_NM IS '방문차량 모델'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.CAR_NO IS '방문차량 번호'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_TC1 IS '반입물품명1'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_NM1 IS '반입물품 모델명1'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.SERIAL_NO1 IS '반입물품 시리얼 번호1'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_TC2 IS '반입물품명2'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_NM2 IS '반입물품 모델명2'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.SERIAL_NO2 IS '반입물품 시리얼 번호2'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_TC3 IS '반입물품명3'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_NM3 IS '반입물품 모델명3'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.SERIAL_NO3 IS '반입물품 시리얼 번호3'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_TC4 IS '반입물품명4'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_NM4 IS '반입물품 모델명4'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.SERIAL_NO4 IS '반입물품 시리얼 번호4'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_TC5 IS '반입물품명5'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_NM5 IS '반입물품 모델명5'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.SERIAL_NO5 IS '반입물품 시리얼 번호5'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_TC6 IS '반입물품명6'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_NM6 IS '반입물품 모델명6'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.SERIAL_NO6 IS '반입물품 시리얼 번호6'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_TC7 IS '반입물품명7'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_NM7 IS '반입물품 모델명7'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.SERIAL_NO7 IS '반입물품 시리얼 번호7'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_TC8 IS '반입물품명8'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_NM8 IS '반입물품 모델명8'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.SERIAL_NO8 IS '반입물품 시리얼 번호8'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_TC9 IS '반입물품명9'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_NM9 IS '반입물품 모델명9'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.SERIAL_NO9 IS '반입물품 시리얼 번호9'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_TC10 IS '반입물품명10'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.THING_NM10 IS '반입물품 모델명10'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.SERIAL_NO10 IS '반입물품 시리얼 번호10'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.USE_PORT IS '포트 사용유무'
/
COMMENT ON COLUMN VI1050_V_HMGWARN.USE_INTERNET IS '인터넷 사용우무'
/
