CREATE VIEW EMP_V_ECAMPUS AS SELECT TO_CHAR (SYSDATE, 'YYYYMMDDHH24MISS') AS PROC_DATE,
          '1' AS PROC_PART,
          'A' AS PROC_TYPE,
          'H139' AS COMPANY_CODE,
          SUBSTR (T1.EMP_ID, 3, 7) AS EMP_NO,
          NULL AS JUMIN,
          T1.EMP_NM AS EMP_NAME,
          T1.ENG_EMP_NM AS EMP_ENG_NAME,
          NULL AS FIRST_NAME,
          NULL AS LAST_NAME -- 본부장 직책의 경우 근무지ID 앞에 X를 기표하여 본부장 근무지 아래에 dummy로 추가된 조직에 매핑되도록 처리한다.
                           ,
             CASE
                WHEN T2.DUTY_CD IN ('AE', 'AK') AND T3.ORG_CLASS = '002'
                THEN
                   'X'
             END
          || T2.WORK_LOC_ID
             AS ORG_CODE,
          T7.ORG_NAME AS ORG_NAME,
          T7.ORG_ENG_NAME AS ORG_ENG_NAME,
          '본사' AS WP_NAME,
          CASE
             WHEN T2.DUTY_CD IS NULL OR T2.DUTY_CD = 'ZZ' THEN ' '
             ELSE '*'
          END
             AS ASGN_FLAG,
          CASE WHEN T2.DUTY_CD = 'ZZ' THEN NULL ELSE T2.DUTY_CD END
             AS ASGN_CODE,
          F_GET_CODENM (T2.C_CD, '/SY05', T2.DUTY_CD) AS ASGN_NAME,
          T2.JOB_ID AS JOB_CODE,
          F_GET_OBJNM (T2.C_CD,
                       'J',
                       T2.JOB_ID,
                       TO_CHAR (SYSDATE, 'YYYYMMDD'))
             AS JOB_NAME,
          T2.POST_CD AS POS_CODE,
          F_GET_CODENM (T2.C_CD, '/SY04', T2.POST_CD) AS POS_NAME,
          TRIM (
             TO_CHAR (
                DECODE (T2.POST_CD2,
                        '00', 0,
                        '01', 1,
                        '02', 2,
                        '03', 3,
                        '04', 4,
                        '05', 5,
                        '06', 6,
                        '26', 7,
                        '0A', 8,
                        '0B', 9,
                        '2A', 10,
                        '2B', 11,
                        '82', 12,
                        T6.NEW_ORDER),
                '00'))
             AS POS_LEVEL,
          T2.POST_CD2 AS GRADE_CODE,
          F_GET_CODENM (T2.C_CD, '00100', T2.POST_CD2) AS GRADE_NAME,
          '1' AS OCC_GRP_CODE,
          '일반직' AS OCC_GRP_NAME,
          T2.DUTY_CD AS JOB_TITLE_CODE,
          F_GET_CODENM (T2.C_CD, '/SY05', T2.DUTY_CD) AS JOB_TITLE_NAME,
          T1.DUTY_APP_YMD AS JOB_DT,
          T1.ENTER_YMD AS HIREDATE,
          NVL (T1.RETIRE_YN, 'N') AS RET_FLAG,
          T1.RETIRE_YMD AS RET_DATE,
          T1.LAST_MOVE_YMD AS APPO_DATE,
          T1.WORK_LOC_TEL_NO AS CORP_TEL_NO,
          T1.MOBILE_NO AS MOBILE,
          T1.MAIL_ADDR AS EMAIL,
          F_GET_BIRTHYMD ('1', T1.PER_NO, 0) ASBIRTH_DAY,
          DECODE (T1.GENDER_TYPE, 'M', '1', '2') AS SEX_FLAG,
          TRIM ('M' || SUBSTR (T1.EMP_ID, 3, 7)) AS MESNG_ID,
          DECODE (T2.EMP_TYPE, 'A', '1', '2') AS CONTRACT_CD,
          T8.ZIP_NO AS ZIPCD,
          '2' AS ADDR_GUBUN,
          T8.ADDR AS ADDR,
          T8.DTL_ADDR AS ADDR_DTL,
--             F_GET_CODENM (T2.C_CD, '/SY04', T2.POST_CD)
--          || ' '
--          || F_GET_CODENM (T2.C_CD, 'SY020', T2.SAL_STEP_CD)
--             PRMTN_ADO,
          TO_NUMBER(SUBSTR(T2.SAL_STEP_CD,LENGTH(T2.SAL_STEP_CD)-1, 2)) AS PRMTN_ADO,
          T1.DUTY_APP_YMD AS ASGN_DT,
          T1.LAST_PROM_YMD AS PRMTN_DT,
          T11.CD_NM AS EDUBCKGRD_HIST,
          F_ORG_NM (T2.C_CD,
                    TO_CHAR (SYSDATE, 'YYYYMMDD'),
                    T2.ORG_ID,
                    '3D')
             AS TERMINUS_DEPT_NM,
          F_ORG_NM (T2.C_CD,
                    TO_CHAR (SYSDATE, 'YYYYMMDD'),
                    T2.ORG_ID,
                    '1D')
             AS DVSN_NM,
          F_GET_CODENM (T9.C_CD, 'OM020', T9.WORK_LOC_CLASS_CD)
             AS WP_GUBUN_CD,
          'U' AS WORK_TYPE                                   -- HEC는 무조건 U로 기표
     FROM PA1010# T1,
          PA1020 T2,
          OM0010 T3,
          SY5020 T4,
          SY3010 T5,
          (SELECT C_CD,
                  CD,
                  20 + ROW_NUMBER () OVER (ORDER BY DP_ORDER) AS NEW_ORDER
             FROM SY5020
            WHERE     IDX_CD = '00100'
                  AND CD IN (SELECT POST_CD2
                               FROM PA1020
                              WHERE     TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN STA_YMD
                                                                          AND END_YMD
                                    AND LAST_YN = 'Y'
                                    AND STAT_CD LIKE '1%')) T6,
          ORG_V_ECAMPUS T7,
          (SELECT *
             FROM PA2010
            WHERE ADDR_CD = '003') T8,
          OM3010 T9,
          (SELECT *
             FROM PA2020
            WHERE     (C_CD, EMP_ID, END_YMD) IN (  SELECT C_CD,
                                                           EMP_ID,
                                                           MAX (END_YMD)
                                                      FROM PA2020
                                                  GROUP BY C_CD, EMP_ID)
                  AND ROWNUM = 1) T10,
          SY5020 T11
    WHERE     T1.C_CD = T2.C_CD(+)
          AND T1.EMP_ID = T2.EMP_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD(+)
                                                AND T2.END_YMD(+)
          --
          AND T2.C_CD = T3.C_CD(+)
          AND T2.ORG_ID = T3.ORG_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T3.STA_YMD(+)
                                                AND T3.END_YMD(+)
          --
          AND T2.C_CD = T4.C_CD(+)
          AND T4.IDX_CD(+) = '/SY04'
          AND T2.POST_CD = T4.CD(+)
          --
          AND T2.C_CD = T5.C_CD(+)
          AND T2.ORG_ID = T5.OBJ_ID(+)
          AND T5.OBJ_TYPE NOT IN ('OE')
          --
          AND T2.C_CD = T6.C_CD(+)
          AND T2.POST_CD2 = T6.CD(+)
          --
          AND    CASE
                    WHEN T2.DUTY_CD IN ('AE', 'AK') AND T3.ORG_CLASS = '002'
                    THEN
                       'X'
                 END
              || T2.WORK_LOC_ID = T7.ORG_CODE
          --
          AND T1.C_CD = T8.C_CD(+)
          AND T1.EMP_ID = T8.EMP_ID(+)
          --
          AND T2.C_CD = T9.C_CD(+)
          AND T2.WORK_LOC_ID = T9.WORK_LOC_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T9.STA_YMD(+)
                                                AND T9.END_YMD(+)
          --
          AND T1.C_CD = T10.C_CD(+)
          AND T1.EMP_ID = T10.EMP_ID(+)
          --
          -- 최종학력 학력구분, 졸업구분으로 그룹사 I/F용 최종학력 코드를 생성한다.
          AND T11.C_CD(+) = T10.C_CD
          AND T11.IDX_CD(+) = 'TE600'
          AND T11.COND_CD1(+) = T10.SCHO_CD
          AND T11.COND_CD2(+) = T10.GRADU_CD
          --
          AND T2.LAST_YN = 'Y'
          AND (   T2.STAT_CD LIKE '1%'
               OR (    T2.STAT_CD = '30'
                   AND T1.RETIRE_YMD >= TO_CHAR (SYSDATE - 7, 'YYYYMMDD'))) -- 재직자 또는 1주일내 퇴사한 인원 포함
          AND T2.POST_CD2 NOT IN ('82', 'A0', '81')               -- 자문, 고문 제외
          AND CASE
                 WHEN T2.EMP_TYPE IN ('A',
                                      'B',
                                      'C',
                                      'D',
                                      'G',
                                      'I',
                                      'J',
                                      'K',
                                      'N',
                                      'M',
                                      'R',
                                      'S')               -- 시설직원 추가 2015.02.09
                 THEN
                    '1'
              END = '1'
          AND T1.EMP_ID NOT IN ('201504684' -- 임유역 사원(1504684) 예외처리. 최정환 차장 요청(15.01.30)
                                           )
/
