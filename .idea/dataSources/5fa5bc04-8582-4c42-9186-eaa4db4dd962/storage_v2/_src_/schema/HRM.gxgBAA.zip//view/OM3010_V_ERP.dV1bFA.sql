CREATE VIEW OM3010_V_ERP AS SELECT   T1.OBJ_ID AS CODEXCD, T1.OBJ_NM AS CODEXNM
     FROM   SY3010 T1, OM3010 T2
    WHERE   T1.C_CD = 'HEC' AND T1.OBJ_TYPE = 'WA'
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                  AND  T1.END_YMD
            AND T2.C_CD(+) = T1.C_CD
            AND T2.WORK_LOC_ID(+) = T1.OBJ_ID
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD(+)
                                                  AND  T2.END_YMD(+)
/
