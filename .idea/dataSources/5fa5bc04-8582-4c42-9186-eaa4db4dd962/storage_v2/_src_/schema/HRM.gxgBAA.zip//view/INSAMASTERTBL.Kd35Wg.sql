CREATE VIEW INSAMASTERTBL AS SELECT 'HE' AS COMPANYCD,
          'ko' AS LANGCD,
          NVL (B.SABUN, A.EMP_ID),
          NVL (B.USERID, SUBSTR (A.EMP_ID, 3, 7)),
          NVL (B.KNAME, A.EMP_NM),
          NVL (B.ENAME, A.ENG_EMP_NM),
          B.SNAME,
          NVL (B.JIKWICD, A.POST_CD2),                      -- hecos 직위 / 호칭직위
          NVL (B.BUSOCD, A.WORK_LOC_ID), -- 본부레벨의 본부장,실장,사업부장 직책의 경우 근무지ID 앞에 X를 기표하여 본부장 근무지 아래에 dummy로 추가된 조직에 매핑되도록 처리한다.
          B.TEAMCD,
          NVL (B.JUMINNO, SUBSTR (A.EMP_ID, 3, 7) || 'hec*'),
          NVL (B.TELOFFICE, A.OFFICE_TEL_NO),
          NVL (B.TELHOME, A.MOBILE_NO),
          B.FAX,
          NVL (B.EMAILID,
               NVL (A.MAIL_ADDR, SUBSTR (A.EMP_ID, 3, 7) || '@hec.co.kr')),
          B.VOIP_TEL,
          NVL (B.ISGROUPWARE, '0'),
          NVL (B.ISEMAIL, DECODE (A.MAIL_ADDR, NULL, '0', '1')),
          B.ISEIS,
          NVL (B.CREATEDATE, SYSDATE),
          NVL (B.CHANGEDATE, SYSDATE),
          B.BUSINESS,
          B.ORGSAUP,
          NVL (B.SITEPOS,
               DECODE (A.DUTY_CD,  'ZZ', '',  'GF', '',  A.DUTY_CD)),
          NVL (
             B.SITEPOS_NM,
             DECODE (A.DUTY_NM,
                     '직책없음', '',
                     '파트장(팀장)', '',
                     A.DUTY_NM)),
          NVL (B.ORGDEPT,
               F_ORG_ID (A.C_CD,
                         A.STA_YMD,
                         A.ORG_ID,
                         '1')),
          NVL (B.MAILID,
               SUBSTR (A.MAIL_ADDR, 1, INSTR (A.MAIL_ADDR, '@') - 1)),
          NVL (B.MAILDOMAIN,
               SUBSTR (A.MAIL_ADDR, INSTR (A.MAIL_ADDR, '@') + 1)),
          B.MODIFYINFODATE,
          NVL (B.CHILDCOMPANYCD, '2'),
          NVL (
             B.EXTENSIONNUMBER,
             CASE
                WHEN    SUBSTR (A.OFFICE_TEL_NO, 1, 4) = '2166'
                     OR SUBSTR (A.OFFICE_TEL_NO, 1, 7) = '02-2166'
                THEN
                   '2166'
                WHEN    SUBSTR (A.OFFICE_TEL_NO, 1, 4) = '2136'
                     OR SUBSTR (A.OFFICE_TEL_NO, 1, 7) = '02-2136'
                THEN
                   '2166'
                WHEN    SUBSTR (A.OFFICE_TEL_NO, 1, 9) = '82-2-2166'
                     OR SUBSTR (A.OFFICE_TEL_NO, 1, 10) = '82-02-2166'
                THEN
                   '2166'
                WHEN    SUBSTR (A.OFFICE_TEL_NO, 1, 4) = '2134'
                     OR SUBSTR (A.OFFICE_TEL_NO, 1, 7) = '02-2134'
                     OR SUBSTR (A.OFFICE_TEL_NO, 1, 6) = '022134'
                --THEN '2134'
                THEN
                   '8833'                 -- 계동사옥 전체 이전전까지 임시변경. 현대CnI 박재형 과장.
                WHEN    SUBSTR (A.OFFICE_TEL_NO, 1, 9) = '82-2-2134'
                     OR SUBSTR (A.OFFICE_TEL_NO, 1, 10) = '82-02-2134'
                --THEN '2134'
                THEN
                   '8833'                 -- 계동사옥 전체 이전전까지 임시변경. 현대CnI 박재형 과장.
             END),
          CASE WHEN B.SABUN IS NULL THEN 'N' ELSE B.DISPLAYYN END DISPLAY_YN
     FROM PA1020_V_1 A, INSAMASTERTBL_UC B
    WHERE     A.EMP_ID = B.SABUN(+)
          AND A.STAT_CD LIKE '1%'
          AND A.EMP_ID NOT LIKE '19E'
/
COMMENT ON VIEW INSAMASTERTBL IS '[건설IM_IF용] (INSAMASTERTBL)인사마스터'
/
