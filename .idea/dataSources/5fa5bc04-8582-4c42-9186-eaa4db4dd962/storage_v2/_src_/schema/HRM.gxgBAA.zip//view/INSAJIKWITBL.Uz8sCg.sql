CREATE VIEW INSAJIKWITBL AS SELECT 'HE' AS CompanyCD,
            'ko' AS LangCD,
            T1.CD AS JikwiCD,           --(직위코드)HECOS직위 코드
            T2.CD_NM AS JikiwNM,        --(직위명)호칭직위명
            T1.ENG_NM AS EJikwiNM,      --(영문직위명)HECOS직위 영문명
            NULL AS SJikwiNM,
            T1.DP_ORDER AS SortOrder
       FROM SY5020 T1, SY5020 T2
      WHERE     T1.IDX_CD = '00100'     --//(T1) HECOS직위(00100)
            AND T2.C_CD = T1.C_CD
            AND T2.IDX_CD = '00101'     --//(T2) 호칭직위(00101)
            AND T2.CD = T1.COND_CD1
   ORDER BY T1.DP_ORDER
/
COMMENT ON VIEW INSAJIKWITBL IS '[IM_IF용] (INSAJIKWITBL)직위_코드테이블'
/
