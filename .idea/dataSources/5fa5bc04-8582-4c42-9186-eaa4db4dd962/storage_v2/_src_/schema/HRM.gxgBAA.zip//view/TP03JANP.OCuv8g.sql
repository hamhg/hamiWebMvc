CREATE VIEW TP03JANP AS SELECT   T1.EMP_ID AS SABUNCD,
            T1.WORK_YMD AS NALJADT,
            T1.OT_APPL_TYPE AS JANUPGB,
            T1.STA_WORK_HM AS SIJAKTM,
            T1.END_WORK_HM AS JONGRTM,
            T1.OT_TRAN_MON AS SUDNGAT,
            T1.WORK_RSN_TXT AS UPMOOMY,
            T1.APPL_STAT_CD AS SIGNSTS,
            T1.PRJ_CD AS PRJ_CD,
            T1.ORG_ID AS ORG_ID, -- 특근입력시점의 소속으로 변경. 2011.04.02 김성관
            T1.DIVISION_CD AS ORG_CD, -- 입력시 저장된 본부코드로 변경. 2011.05.03 김성관
            T1.INOUT_CD AS INOUT_CD,
            T1.INS_USER_ID,
            T1.INS_YMDHMS,
            T1.MOD_USER_ID,
            T1.MOD_YMDHMS
     FROM   TM1030 T1, TM1035 T2
    WHERE       T1.C_CD = T2.C_CD
            AND T1.EMP_ID = T2.EMP_ID
            AND T1.WORK_YMD BETWEEN T2.STA_YMD AND T2.END_YMD
            AND T1.APPL_STAT_CD IN ('A', 'D')
            AND T2.CLOSE_YN = 'Y'
            AND T2.PAYROLL_TYPE = '01'
/
