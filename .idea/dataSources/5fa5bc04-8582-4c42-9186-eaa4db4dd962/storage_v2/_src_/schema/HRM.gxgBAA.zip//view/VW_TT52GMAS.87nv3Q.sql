CREATE VIEW VW_TT52GMAS AS SELECT T0.EMP_ID
            ,T2.ORGN_YM            -- 지급월
            ,T2.PAYROLL_TYPE       -- 급여유형 '01' 급여  11 상여  ,20 성과 ,21 격려
            ,T3.PAYITEM_TYPE       -- 1 지급 , 2 공제
            ,T1.PAYITEM            -- 급여형목
            ,SUBSTR(T1.ORGN_PAYROLL_NO,1,6) ORGN_PAYROLL_YM   -- 적용월
            ,(SELECT PAYROLL_TYPE FROM PY0300 WHERE C_CD=T1.C_CD AND PAYROLL_NO =T1.ORGN_PAYROLL_NO) ORGN_PAYROLL_TYPE --적용 유형
            ,T5.WORK_LOC_ID         -- 근무지
            ,T1.SEQ_NO              -- 순번
            ,T0.D_CNT               -- 근무일
            ,T1.LAST_MON            -- 기준금액
            ,'' FLAGXCD
        FROM PY1020 T0,
             PY2360 T1,
             PY0300 T2,
             PY0100 T3,
             PA1020 T5
       WHERE T0.C_CD  = 'HEC'
         AND T1.C_CD = T0.C_CD
         AND T1.EMP_ID = T0.EMP_ID
         AND T1.PAYROLL_NO = T0.PAYROLL_NO
         AND T1.PAYITEM = T1.PAYITEM
         AND T2.C_CD = T1.C_CD
         AND T2.PAYROLL_NO = T1.ORGN_PAYROLL_NO
         AND T3.C_CD = T1.C_CD
         AND T3.PAYITEM = T1.PAYITEM
         AND T0.C_CD = T5.C_CD
         AND T0.EMP_ID = T5.EMP_ID
         AND T2.PAYROLL_YMD BETWEEN T5.STA_YMD AND T5.END_YMD
         AND T5.LAST_YN ='Y'
/
