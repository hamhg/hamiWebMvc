CREATE VIEW TX_YA1010 AS SELECT T1.C_CD C_CD,
       T1.EMP_ID EMP_ID,
       SUBSTR(T1.ADJ_YMD, 1, 6) TAX_ORGN_YM,
       T5.ORG_ID ORG_ID,
       T1.BIZPL_CD BIZPL_CD,
       T1.TAX_LOC_CD LOC_CD,
       T1.ADJ_YY ADJ_YY,
       T1.ADJ_CD ADJ_CD,
       NVL(T3.TOT_PAY_MON, 0) TOT_PAY_MON,
       NVL(T4.NTAX_MON, 0) NTAX_MON,
       NVL(T2.BLN_INCM_TAX_MON, 0) INCM_TAX_MON,
       NVL(T2.BLN_RESI_TAX_MON, 0) RESI_TAX_MON,
       NVL(T2.BLN_FAM_TAX_MON, 0) FAM_TAX_MON
  FROM YA1010 T1,
       YA2110 T2,
       (
       SELECT T1.C_CD,
              T1.ADJ_YY,
              T1.EMP_ID,
              NVL(SUM(T1.TOT_PAY_MON), 0) TOT_PAY_MON
         FROM (
               SELECT T1.C_CD,
                      T1.ADJ_YY,
                      T1.EMP_ID,
                      (T1.TOT_PAY_MON + T1.TOT_BONUS_MON + T1.RCG_BONUS_MON + T1.STOCK_MON + T1.ASSO_WDRW_MON) TOT_PAY_MON
                 FROM YA2040 T1
                WHERE 1=1
               UNION ALL
               SELECT T1.C_CD,
                      T1.ADJ_YY,
                      T1.EMP_ID,
                      (T1.TOT_PAY_MON + T1.TOT_BONUS_MON + T1.RCG_BONUS_MON + T1.STOCK_MON + T1.ASSO_WDRW_MON) TOT_PAY_MON
                 FROM YA2090 T1
                WHERE 1=1
              ) T1
        WHERE 1=1
        GROUP BY
              T1.C_CD,
              T1.ADJ_YY,
              T1.EMP_ID
       ) T3,
       (
       SELECT T1.C_CD,
              T1.ADJ_YY,
              T1.EMP_ID,
              NVL(SUM(T1.MON), 0) NTAX_MON
         FROM (
               SELECT T1.C_CD,
                      T1.ADJ_YY,
                      T1.EMP_ID,
                      T1.MON
                 FROM YA2045 T1
                WHERE 1=1
               UNION ALL
               SELECT T1.C_CD,
                      T1.ADJ_YY,
                      T1.EMP_ID,
                      T1.MON
                 FROM YA2095 T1
                WHERE 1=1
              ) T1
        WHERE 1=1
        GROUP BY
              T1.C_CD,
              T1.ADJ_YY,
              T1.EMP_ID
       ) T4,
       PA1020 T5
 WHERE 1=1
   AND T2.C_CD = T1.C_CD
   AND T2.ADJ_YY = T1.ADJ_YY
   AND T2.EMP_ID = T1.EMP_ID
   AND T3.C_CD(+) = T2.C_CD
   AND T3.ADJ_YY(+) = T2.ADJ_YY
   AND T3.EMP_ID(+) = T2.EMP_ID
   AND T4.C_CD(+) = T2.C_CD
   AND T4.ADJ_YY(+) = T2.ADJ_YY
   AND T4.EMP_ID(+) = T2.EMP_ID
   AND T5.C_CD = T1.C_CD
   AND T5.EMP_ID = T1.EMP_ID
   AND T1.ADJ_YMD BETWEEN T5.STA_YMD AND T5.END_YMD
   AND T5.LAST_YN = 'Y'
/
