CREATE PROCEDURE     P_BE024_BATCH01_KYK(
  I_C_CD        IN VARCHAR2,
  I_PAYROLL_NO  IN VARCHAR2,
  I_SINS_TYPE   IN VARCHAR2,  --사회보험구분
  I_EMP_ID      IN VARCHAR2,  --사번 NULL 이면 전사원
  I_MOD_USER_ID IN VARCHAR2
 
)
IS
/***********************************************************************
 Program Name   : P_BE024_BATCH01
 Description    : 사회보험 급여반영 생성 배치
 Author         :
 History        :
***********************************************************************/
  V_BE_CLOSE_YN VARCHAR2(1);   --급여마감여부
  V_PAYROLL_YMD VARCHAR2(8);
  V_PAYROLL_TYPE VARCHAR2(20);
  V_STA_YMD VARCHAR2(8);
  V_END_YMD VARCHAR2(8);
  V_PAY_UNIT VARCHAR2(5);
  V_PAY_RULE VARCHAR2(5);
   O_ERRORCODE    VARCHAR2(8); --결과코드
  O_ERRORMESG    VARCHAR2(8);  --결과메시지
  R1 BE2010%ROWTYPE;
  V_NPEN_PAYITEM VARCHAR2(20) := F_GET_SYS_VAL(I_C_CD, 'NPEN_PAYITEM');   -- 국민연금
  V_HINS_PAYITEM VARCHAR2(20) := F_GET_SYS_VAL(I_C_CD, 'HINS_PAYITEM');   -- 건강보험
BEGIN
    /*
    - 급여계산번호에 해당하는 급여마감여부가 Y 가 아니면 실행
    - 대상 : BE1010(사회보험기본)에서 급여월 현재 가입중인 직원을 대상으로 등급에 맞는 금액 생성하여
               BE2010(사회보험공제)에 자료 생성

    BE2010
    사번
    급여계산번호
    업무구분
    귀속일 : 급여계산번호의 급여일
    등급 : BE1010 의 보수월액에 해당하는 등급
    납부상태코드 : BE1010 의 납부상태코드
    공제액_본인 : 등급표의 개인부담금
    공제액_회사 : 등급표의 회사부담금
    나머지 필드는 급여에서 넣어줌



  DECLARE
      o_Cnt        VARCHAR2(500);
      o_Errorcode        VARCHAR2(500);
      o_Errormesg        VARCHAR2(500);
      A              DATE;
      B              DATE;
  BEGIN
       SELECT SYSDATE INTO A FROM DUAL;
      P_BE024_BATCH01
      (
      '30'
      , '20070402'
      , '2'
      , '206033'
      , 'SUPER', o_Cnt, o_Errorcode, o_Errormesg);
      SELECT SYSDATE INTO B FROM DUAL;
      DBMS_OUTPUT.put_line(TO_CHAR(A,'HH:MI:SS')||' = '||TO_CHAR(B,'HH:MI:SS')||' = '||O_Errorcode);
  END;




    */
  SELECT BE_CLOSE_YN,
         PAYROLL_YMD,
         PAYROLL_TYPE,
         STA_YMD,
         END_YMD
    INTO V_BE_CLOSE_YN,
         V_PAYROLL_YMD,
         V_PAYROLL_TYPE,
         V_STA_YMD,
         V_END_YMD
    FROM PY0300
   WHERE C_CD = I_C_CD
     AND PAYROLL_NO = I_PAYROLL_NO;

  IF V_BE_CLOSE_YN = 'Y' THEN
    RAISE_APPLICATION_ERROR(-20000, '급여가 마감되어 처리할 수 없습니다.');
  END IF;


  DELETE FROM BE2010
        WHERE C_CD = I_C_CD
          AND EMP_ID LIKE I_EMP_ID || '%'   --  2007.05.22 사번추가
          AND PAYROLL_NO = I_PAYROLL_NO
          AND SINS_TYPE = I_SINS_TYPE;

  IF I_SINS_TYPE = '1'  THEN
    /* 금액에 대해 급여항목멸 가감내역을 적용한다. */
    SELECT ROUND_UNIT_CD,
           ROUND_TYPE
      INTO V_PAY_UNIT,
           V_PAY_RULE
      FROM PY0100
     WHERE C_CD = I_C_CD
       AND PAYITEM = V_NPEN_PAYITEM;

    /* 수정 : 국민연금코드를 시스템환경변수에서 가져온다. 최영우 20071128
    AND PAYITEM = 'G0012';
    */
    DBMS_OUTPUT.PUT_LINE(V_STA_YMD || ' = ' || V_END_YMD || ' = ' || V_PAYROLL_TYPE);

    INSERT INTO BE2010
                (C_CD,
                 EMP_ID,
                 PAYROLL_NO,
                 SINS_TYPE,
                 ORGN_YMD,
                 GRD_CD,
                 DDCT_STAT_CD,
                 PSN_MON,
                 COM_MON,
                 MOD_USER_ID,
                 MOD_YMDHMS,
INS_USER_ID,
INS_YMDHMS
                )
      SELECT I_C_CD,
             A.EMP_ID,
             I_PAYROLL_NO,
             '1',
             V_PAYROLL_YMD,
             0,
             A.DDCT_STAT_CD,
             CASE A.DDCT_STAT_CD
               WHEN '00'
                 THEN F_CALC_MON(B.MON, V_PAY_UNIT, V_PAY_RULE)
               WHEN '12'
                 THEN F_CALC_MON(B.MON / 2, V_PAY_UNIT, V_PAY_RULE)
               ELSE 0
             END,
             CASE A.DDCT_STAT_CD
               WHEN '00'
                 THEN F_CALC_MON(B.MON, V_PAY_UNIT, V_PAY_RULE)
               WHEN '12'
                 THEN F_CALC_MON(B.MON / 2, V_PAY_UNIT, V_PAY_RULE)
               ELSE 0
             END,
             I_MOD_USER_ID,
             SYSDATE,
             I_MOD_USER_ID,
             SYSDATE
        FROM BE1010 A,
             PY2010 B,
             PA1020_V_B D   -- 2007.05.31 배치대상자 찾기를 PA1010 에서 PA1020으로 수정
       WHERE A.C_CD = I_C_CD
         AND A.C_CD = B.C_CD
         AND A.C_CD = D.C_CD
         AND A.SINS_TYPE = '1'
         AND A.EMP_ID LIKE I_EMP_ID || '%'   --  2007.05.22 사번추가
         AND A.EMP_ID = B.EMP_ID
         AND A.EMP_ID = D.EMP_ID
         AND B.PAYITEM = V_NPEN_PAYITEM
         /* 수정 : 건강보험코드를 시스템환경변수에서 가져온다. 최영우 20071128
         AND B.PAYITEM = 'G0011'
         */
         AND A.STA_YMD <= V_END_YMD
         AND NVL(A.END_YMD, '99991231') >= V_STA_YMD
         AND B.STA_YMD <= V_END_YMD
         AND B.END_YMD >= V_STA_YMD
         AND V_END_YMD BETWEEN D.STA_YMD AND D.END_YMD   -- 2007.05.31 배치대상자 찾기를 PA1010 에서 PA1020으로 수정
         AND 1 =
               CASE
                 WHEN V_PAYROLL_TYPE = '100'
                 AND D.STAT_CD = '30'
                 AND D.STA_YMD < V_END_YMD
                   THEN 1   -- 2007.06.14 말일퇴직자는 퇴직급여가 아닌 월급여로 지급
/* [CHECK] 수정 : 퇴직자도 포함한다. 최영우, 20080108
                                         WHEN v_Payroll_type <> '100' AND D.STAT_CD IN ('10','13') THEN 1
*/
               WHEN V_PAYROLL_TYPE <> '100'
               AND D.STAT_CD IN('10', '13', '30')
                   THEN 1
                 WHEN V_PAYROLL_TYPE <> '100'
                 AND D.STAT_CD = '30'
                 AND D.STA_YMD = V_END_YMD
                   THEN 1
               END
         AND 1 = CASE
                  WHEN D.GRP_YMD BETWEEN V_STA_YMD AND V_END_YMD
                  AND A.ENTER_MM_DDCT_YN = 'N'
                    THEN 0   --  2007.05.22 입사월공제여부 적용
                  ELSE 1
                END;

DBMS_OUTPUT.PUT_LINE('222222222222222');
  ELSIF I_SINS_TYPE = '2'  THEN
    /* 금액에 대해 급여항목멸 가감내역을 적용한다. */
    SELECT ROUND_UNIT_CD,
           ROUND_TYPE
      INTO V_PAY_UNIT,
           V_PAY_RULE
      FROM PY0100
     WHERE C_CD = I_C_CD
       AND PAYITEM = V_HINS_PAYITEM;

    /* 수정 : 건강보험코드를 시스템환경변수에서 가져온다. 최영우 20071128
    AND PAYITEM = 'G0011';
    */
    INSERT INTO BE2010
                (C_CD,
                 EMP_ID,
                 PAYROLL_NO,
                 SINS_TYPE,
                 ORGN_YMD,
                 GRD_CD,
                 DDCT_STAT_CD,
                 PSN_MON,
                 COM_MON,
                 MOD_USER_ID,
                 MOD_YMDHMS,
INS_USER_ID,
INS_YMDHMS
                )
      SELECT I_C_CD,
             A.EMP_ID,
             I_PAYROLL_NO,
             '2',
             V_PAYROLL_YMD,
             0,
             A.DDCT_STAT_CD,
             CASE A.DDCT_STAT_CD
               WHEN '00'
                 THEN F_CALC_MON(B.MON, V_PAY_UNIT, V_PAY_RULE)
               WHEN '12'
                 THEN F_CALC_MON(B.MON / 2, V_PAY_UNIT, V_PAY_RULE)
               ELSE 0
             END,
             CASE A.DDCT_STAT_CD
               WHEN '00'
                 THEN F_CALC_MON(B.MON, V_PAY_UNIT, V_PAY_RULE)
               WHEN '12'
                 THEN F_CALC_MON(B.MON / 2, V_PAY_UNIT, V_PAY_RULE)
               ELSE 0
             END,
             I_MOD_USER_ID,
             SYSDATE,
             I_MOD_USER_ID,
             SYSDATE
        FROM BE1010 A,
             PY2010 B,
             PA1020_V_B D   -- 2007.05.31 배치대상자 찾기를 PA1010 에서 PA1020으로 수정
       WHERE A.C_CD = I_C_CD
         AND A.C_CD = B.C_CD
         AND A.C_CD = D.C_CD
         AND A.SINS_TYPE = '2'
         AND A.EMP_ID LIKE I_EMP_ID || '%'   --  2007.05.22 사번추가
         AND A.EMP_ID = B.EMP_ID
         AND A.EMP_ID = D.EMP_ID
         AND B.PAYITEM = V_HINS_PAYITEM
         /* 수정 : 건강보험코드를 시스템환경변수에서 가져온다. 최영우 20071128
         AND B.PAYITEM = 'G0011'
         */
         AND A.STA_YMD <= V_END_YMD
         AND NVL(A.END_YMD, '99991231') >= V_STA_YMD
         AND B.STA_YMD <= V_END_YMD
         AND B.END_YMD >= V_STA_YMD
         AND V_END_YMD BETWEEN D.STA_YMD AND D.END_YMD   -- 2007.05.31 배치대상자 찾기를 PA1010 에서 PA1020으로 수정
         AND 1 =
               CASE
                 WHEN V_PAYROLL_TYPE = '100'
                 AND D.STAT_CD = '30'
                 AND D.STA_YMD < V_END_YMD
                   THEN 1   -- 2007.06.14 말일퇴직자는 퇴직급여가 아닌 월급여로 지급
/* [CHECK] 수정 : 퇴직자도 포함한다. 최영우, 20080108
                                         WHEN v_Payroll_type <> '100' AND D.STAT_CD IN ('10','13') THEN 1
*/
               WHEN V_PAYROLL_TYPE <> '100'
               AND D.STAT_CD IN('10', '13', '30')
                   THEN 1
                 WHEN V_PAYROLL_TYPE <> '100'
                 AND D.STAT_CD = '30'
                 AND D.STA_YMD = V_END_YMD
                   THEN 1
               END
         AND 1 = CASE
                  WHEN D.GRP_YMD BETWEEN V_STA_YMD AND V_END_YMD
                  AND A.ENTER_MM_DDCT_YN = 'N'
                    THEN 0   --  2007.05.22 입사월공제여부 적용
                  ELSE 1
                END;

/*

              AND D.STAT_CD IN ((CASE  WHEN v_Payroll_type = '100' AND A.END_YMD > D.STA_YMD THEN '30'
                                          WHEN v_Payroll_type <> '100' AND D.STAT_CD = '30' AND v_End_ymd = D.STA_YMD THEN 'C'    -- 2007.06.07 말일퇴직자는 퇴직급여가 아닌 월급여로 지급
                                       ELSE 'A' END)
                                           ,(CASE v_Payroll_type WHEN '01' THEN 'B' END))
                                           
*/
DBMS_OUTPUT.PUT_LINE('333333333333333');
  END IF;

  O_ERRORCODE := '';
  O_ERRORMESG := '';
EXCEPTION
  WHEN OTHERS
  THEN
    O_ERRORCODE := SQLCODE;
    O_ERRORMESG := SQLERRM;
END;
/
