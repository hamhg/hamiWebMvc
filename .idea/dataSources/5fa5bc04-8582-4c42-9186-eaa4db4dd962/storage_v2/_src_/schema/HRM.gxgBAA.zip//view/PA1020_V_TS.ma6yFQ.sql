CREATE VIEW PA1020_V_TS AS SELECT T1.EMP_ID AS SABUNCD,
          CASE
             WHEN T3.WORK_LOC_CLASS_CD IS NULL AND T1.RETIRE_YMD IS NOT NULL
             THEN
                '1' -- 현장구분이 없고 퇴사일이 있는경우 1;본사로 넘긴다. 퇴사처리 발령시작일에 조직이 닫힌경우가 있으므로
             ELSE
                T3.WORK_LOC_CLASS_CD
          END
             AS HYUNJGB,
          T1.ENTER_YMD AS IPSA1DT,
          T1.RETIRE_YMD AS TOISADT,
          T2.JOB_ID
     FROM PA1010# T1, PA1020 T2, OM3010 T3
    WHERE     T1.C_CD = T2.C_CD
          AND T1.EMP_ID = T2.EMP_ID
          AND T2.C_CD = T3.C_CD(+)
          AND T2.WORK_LOC_ID = T3.WORK_LOC_ID(+)
          AND T2.STA_YMD BETWEEN T3.STA_YMD(+) AND T3.END_YMD(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD AND T2.END_YMD
          AND T2.LAST_YN = 'Y'
          AND T2.EMP_TYPE IN ('A',
                              'B',
                              'C',
                              'D',
                              'G',
                              'I',
                              'K',
                              'J',
                              'M',
                              'N',
                              'E',
                              'R',
                              'S')
/
