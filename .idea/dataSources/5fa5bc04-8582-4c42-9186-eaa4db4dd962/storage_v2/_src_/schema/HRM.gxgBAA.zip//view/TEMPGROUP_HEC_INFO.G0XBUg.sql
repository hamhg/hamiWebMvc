CREATE VIEW TEMPGROUP_HEC_INFO AS SELECT "SEQ_NO"
       ,"GROUP_ID"
       ,"GROUP_NAME"
       ,"PARENTGROUP_ID"
       ,"COMPANY_ID"
       ,"COMPANY_TYPE"
       ,"COMAPNY_NAME"
  FROM (SELECT T1.SEQ        SEQ_NO
              ,T2.OBJ_ID     GROUP_ID
              ,T2.OBJ_NM     GROUP_NAME
              ,T1.PAR_OBJ_ID PARENTGROUP_ID
              ,NULL          COMPANY_ID
              ,NULL          COMPANY_TYPE
              ,NULL          COMAPNY_NAME
          FROM (SELECT LEVEL           TLEVEL
                      ,T1.OBJ_TYPE
                      ,T1.OBJ_ID
                      ,T1.PAR_OBJ_TYPE
                      ,T1.PAR_OBJ_ID
                      ,T1.STA_YMD
                      ,T1.END_YMD
                      ,ROWNUM          SEQ
                  FROM (SELECT T1.*
                          FROM SY3020 T1
                         WHERE T1.C_CD = 'HEC'
                           AND T1.OBJ_TYPE IN
                               (SELECT A.OBJ_TYPE
                                  FROM SY3080 A
                                 WHERE A.C_CD = 'HEC'
                                   AND A.OBJ_TREE_TYPE = 'WATREE')
                           AND TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD AND
                               T1.END_YMD) T1
                 START WITH (T1.C_CD, T1.OBJ_TYPE, T1.OBJ_ID) IN
                            (SELECT C_CD
                                   ,ROOT_OBJ_TYPE
                                   ,ROOT_OBJ_ID
                               FROM SY3070
                              WHERE C_CD = 'HEC'
                                AND OBJ_TREE_TYPE = 'WATREE'
                                AND TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN
                                    STA_YMD AND END_YMD)
                        AND TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD AND
                            T1.END_YMD
                CONNECT BY PRIOR T1.C_CD = T1.C_CD
                       AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
                       AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
                 ORDER SIBLINGS BY T1.SEQ_NO) T1
              ,SY3010 T2
         WHERE T2.C_CD = 'HEC'
           AND T2.OBJ_TYPE = T1.OBJ_TYPE
           AND T2.OBJ_ID = T1.OBJ_ID
           AND TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD AND
               T2.END_YMD
           AND T2.OBJ_ID NOT IN ('RT00000020')

        --AND T2.OBJ_ID NOT IN ('O000000001', 'O000000420') --//[2013.04.17] 사장실 OBJ_ID 변경('O000000420'에서 'O000001010')
        /*
        --// [2013.04.17] 사장실의 조직도 변경에 따라 주석처리('O000001010')
         UNION ALL
         SELECT 1 SEQ_NO,
                OBJ_ID GROUP_ID,
                OBJ_NM GROUP_NAME,
                'O000000001' PARENTGROUP_ID,
                NULL COMPANY_ID,
                NULL COMPANY_TYPE,
                NULL COMAPNY_NAME
           FROM SY3010
          WHERE     C_CD = 'HEC'
                AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN STA_YMD
                                                      AND END_YMD
                AND OBJ_ID IN ('O000000420', 'O000001010') --//[2013.04.17] 사장실 OBJ_ID 변경('O000000420'에서 'O000001010')
        */
        )
 ORDER BY SEQ_NO
/
COMMENT ON VIEW TEMPGROUP_HEC_INFO IS '[DRM_IF용] (TEMPGROUP_HEC_INFO)'
/
