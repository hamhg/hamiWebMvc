CREATE PROCEDURE P_BE_BEH211_MIGRATION(
                            I_EXEC         IN  VARCHAR2,
                            O_ERRORCODE    OUT VARCHAR2,
                            O_ERRORMESG    OUT VARCHAR2,
                            O_BILL_SEQ_NO  OUT VARCHAR2
                            
)
IS
/***********************************************************************
 Program Name   : P_BE_BEH211_MIGRATION
 Description    : 복리후생 일잔검진결과 마이그레이션 작업 
 Author         : 윤병근 
 History        : 2010-11-02
***********************************************************************/
  CUR_EMPNO      VARCHAR2(10);
  CUR_YYYYMMDD   VARCHAR2(08);
  CUR_RESULT     VARCHAR2(1);
  CUR_REPORT1    VARCHAR2(50);
  CUR_REPORTA    VARCHAR2(50);  
  CUR_REPORTB    VARCHAR2(50);  
  CUR_REPORTC    VARCHAR2(50);  
  CUR_OPINION    VARCHAR2(200); 
  CUR_CNT        NUMBER; 
  V_REPORT       VARCHAR2(50);    
  

  CURSOR CUR1 IS SELECT W1.EMPNO,
                        W1.YYYYMMDD,
                        W1.RESULT,
                        W1.OPINION, 
                        NVL(W1.CNT,0) AS CNT,
                        W1.REPORT1,
                        SUBSTR(REPORT,1,2) AS REPORTA,
                        SUBSTR(REPORT,3,2) AS REPORTB,
                        SUBSTR(REPORT,5,2) AS REPORTC
                   FROM (
                           SELECT T1.EMPNO,
                                  T1.YYYYMMDD,
                                  T1.RESULT,
                                  T1.OPINION, 
                                  REPLACE(T1.REPORT1,'^','') AS REPORT1,
                                  CASE WHEN LENGTHB(REPLACE(T1.REPORT2,'^','')) = 6 THEN 3
                                       WHEN LENGTHB(REPLACE(T1.REPORT2,'^','')) = 4 THEN 2
                                       WHEN LENGTHB(REPLACE(T1.REPORT2,'^','')) = 2 THEN 1
                                  END CNT,
                                  REPLACE(T1.REPORT2,'^','') AS REPORT     
                             FROM HECLEG.MEDICAL_CHECKUP T1
                        ) W1;                   
              
                 

BEGIN
  
       OPEN CUR1;                      
            LOOP FETCH CUR1            
                  INTO CUR_EMPNO,
                       CUR_YYYYMMDD,
                       CUR_RESULT,
                       CUR_OPINION,
                       CUR_CNT,
                       CUR_REPORT1,
                       CUR_REPORTA,
                       CUR_REPORTB,
                       CUR_REPORTC;
                 IF CUR1%NOTFOUND THEN 
                    GOTO END_RTN;      
                 END IF;
  
  
                 FOR CUR_CNT IN 1..3 LOOP
                 
                     IF CUR_CNT = 1 AND NVL(CUR_REPORTA,' ') > ' ' THEN 
                        V_REPORT := CUR_REPORTA;
                     ELSIF CUR_CNT = 2 AND NVL(CUR_REPORTB,' ') > ' ' THEN   
                        V_REPORT := CUR_REPORTB;
                     ELSIF CUR_CNT = 3 AND NVL(CUR_REPORTC,' ') > ' ' THEN      
                        V_REPORT := CUR_REPORTC;  
                     END IF;
  
                 --==============================
                 --==  일반건강검진 결과등록   ==
                 --==============================
                 IF NVL(CUR_REPORT1,' ') > ' 'THEN 
                     UPDATE BEH211
                        SET NOTE = NULL
                      WHERE C_CD          = 'HEC'
                        AND YY            = SUBSTR(CUR_YYYYMMDD,1,4)
                        AND EMP_ID        = CUR_EMPNO
                        AND DECS_MGR_CD   = CUR_REPORT1
                        AND DECS_DOUBT_CD = V_REPORT;
                 ELSE
                     UPDATE BEH211
                        SET NOTE = NULL
                      WHERE C_CD          = 'HEC'
                        AND YY            = SUBSTR(CUR_YYYYMMDD,1,4)
                        AND EMP_ID        = CUR_EMPNO
                        AND DECS_DOUBT_CD = V_REPORT;                 
                 END IF;       
                        
                 
                 IF SQL%NOTFOUND THEN

                     INSERT INTO  BEH211(C_CD,         
                                         YY,           
                                         EMP_ID,       
                                         SEQ_NO,       
                                         CHK_RSLT,     
                                         CHK_YMD,      
                                         DECS_MGR_CD,  
                                         DECS_DOUBT_CD,
                                         DOCT_COMNT,   
                                         NOTE,         
                                         INS_USER_ID,  
                                         INS_YMDHMS,   
                                         MOD_USER_ID,  
                                         MOD_YMDHMS
                                         )
                                  VALUES('HEC',  
                                         SUBSTR(CUR_YYYYMMDD,1,4),      
                                         CUR_EMPNO,
                                         ( SELECT NVL(MAX(SEQ_NO), 0) + 1 FROM BEH211 WHERE C_CD = 'HEC'),
                                         CUR_RESULT,
                                         CUR_YYYYMMDD,
                                         CUR_REPORT1,
                                         V_REPORT,
                                         CUR_OPINION,
                                         NULL,
                                         'SUPER',
                                         SYSDATE,
                                         'SUPER',
                                         SYSDATE 
                                         );
                  END IF;
                                     
                  END LOOP;              
  
       END LOOP;    
  
       << END_RTN >>     
       CLOSE  CUR1;  
  
EXCEPTION
  WHEN OTHERS THEN
    O_ERRORCODE := SQLCODE;
    O_ERRORMESG := SQLERRM;  
END P_BE_BEH211_MIGRATION;
/
