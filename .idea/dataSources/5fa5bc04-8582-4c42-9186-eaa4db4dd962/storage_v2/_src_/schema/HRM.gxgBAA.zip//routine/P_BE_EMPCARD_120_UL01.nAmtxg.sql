CREATE PROCEDURE     P_BE_EMPCARD_120_UL01
(
    I_C_CD        IN VARCHAR2, --회사코드 
    I_ISSUE_YMD   IN VARCHAR2, --발급일자  
    I_MOD_USER_ID IN VARCHAR2,
    O_ERRORCODE   OUT VARCHAR2,
    O_ERRORMESG   OUT VARCHAR2
) IS
    /***********************************************************************
     Program Name   : P_BE_EMPCARD_120_UL01
     Description    : 신규입사자  사원증 일괄 발급 대상자 생성 작업 
     Author         : 윤병근 
     History        : 2010-08-09 신규개발
                      2011.05.24 정명주 수정, 인사기본에 사번있는데 사원증발급관리에 사번 없고 재직이면 
                                              찾아서 생성
    ***********************************************************************/
    --V_BE_CLOSE_YN VARCHAR2(1);
BEGIN

    /**
      SELECT F_MAKE_NEW_TABLE_ID(I_C_CD, 'BEE210', 'DATA_ID', '4') NEW_TABLE_ID
        INTO V_DATA_ID 
        FROM DUAL;
        
      DELETE FROM BEE210
            WHERE C_CD        = I_C_CD
              AND ISSUE_YMD   = I_ISSUE_YMD
              AND ISSUE_CLASS = '10'  --> 발급구분이 자동신청 일 경우만 
              AND PAY_IFE_YN  = 'N'
              AND NVL(BILL_NO,' ') = ' ';
    
      INSERT INTO BEE210
                  ( 
                    C_CD,        
                    DATA_ID,     
                    EMP_ID,      
                    ISSUE_YN,    
                    ISSUE_YMD,   
                    ISSUE_CLASS, 
                    DDCT_MON,    
                    PAY_DDCT_MM, 
                    PAYROLL_NO,  
                    PAY_IFE_YN,  
                    BILL_NO,     
                    APPL_ID,     
                    APPL_YMD,    
                    NOTE,        
                    INS_USER_ID, 
                    INS_YMDHMS,  
                    MOD_USER_ID, 
                    MOD_YMDHMS  
                  )
                  SELECT NVL(T1.C_CD,' ')    C_CD,
                         V_DATA_ID,
                         NVL(T1.EMP_ID,' ')  EMP_ID, 
                         'N',           
                         I_ISSUE_YMD,
                         '10',
                         8000,
                         NULL,
                         NULL,
                         'N',
                         NULL,
                         NULL,
                         I_ISSUE_YMD,
                         NULL,
                         I_MOD_USER_ID,
                         SYSDATE,
                         I_MOD_USER_ID,
                         SYSDATE
                    FROM 
                         ( 
                          SELECT DISTINCT S1.* 
                            FROM PA9010 S1,
                                 PA1010 S2
                           WHERE S1.C_CD      = I_C_CD
                             AND I_ISSUE_YMD <= S1.STA_YMD 
                             AND S1.APPNT_CD  = '02'
                             AND S1.C_CD    = S2.C_CD 
                             AND S1.EMP_ID != S2.EMP_ID  
                         ) T1     
                   WHERE T1.C_CD = I_C_CD;
    */

    /**
    수정일 : 2011-01-03 
    수정자 : 진용인
    수정내용 : 대상자 생성시 2011년 01월 03일 이후의 입사자들만 조회한다.
    주석처리 : 2011.05.24 정명주
    INSERT INTO BEE210
        (C_CD, DATA_ID, EMP_ID, ISSUE_YN, ISSUE_YMD, ISSUE_CLASS, DDCT_MON, PAY_DDCT_MM, PAYROLL_NO, PAY_IFE_YN, BILL_NO, APPL_ID, APPL_YMD, NOTE, INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS)
        SELECT T3.C_CD
              ,(SELECT MAX(DATA_ID) + T3.NUM FROM BEE210)
              ,T3.EMP_ID
              ,'N'
              ,I_ISSUE_YMD
              ,'10'
              ,0
              ,NULL
              ,NULL
              ,'N'
              ,NULL
              ,NULL
              ,I_ISSUE_YMD
              ,NULL
              ,I_MOD_USER_ID
              ,SYSDATE
              ,I_MOD_USER_ID
              ,SYSDATE
          FROM (SELECT T1.C_CD
                      ,T1.EMP_ID
                      ,ROWNUM AS NUM
                  FROM PA1020 T1
                      ,PA1010 T2
                 WHERE T1.C_CD = I_C_CD
                   AND I_ISSUE_YMD BETWEEN T1.STA_YMD AND T1.END_YMD
                   AND T1.STAT_CD LIKE '1%'
                   AND T1.APPNT_CD IN ('01', '02')
                   AND T1.LAST_YN = 'Y'
                   AND T1.EMP_TYPE NOT IN ('8', 'P', 'O')
                   AND T1.EMP_ID NOT IN (SELECT EMP_ID
                                           FROM BEE210
                                          WHERE C_CD = I_C_CD
                                            AND ISSUE_CLASS = '10'
                                            AND SUBSTR(ISSUE_YMD, 0, 4) = SUBSTR(I_ISSUE_YMD, 0, 4)
                                          GROUP BY EMP_ID)
                   AND T1.C_CD = T2.C_CD
                   AND T1.EMP_ID = T2.EMP_ID
                   AND T2.ENTER_YMD >= '20110103') T3;
    */

    /**
    정명주 추가
    인사기본에 사번있는데 사원증발급관리에 사번 없고 재직이면 찾아서 생성
    */
    INSERT INTO BEE210
        (C_CD, DATA_ID, EMP_ID, ISSUE_YN, ISSUE_YMD, ISSUE_CLASS, DDCT_MON, PAY_DDCT_MM, PAYROLL_NO, PAY_IFE_YN, BILL_NO, APPL_ID, APPL_YMD, NOTE, INS_USER_ID, INS_YMDHMS, MOD_USER_ID, MOD_YMDHMS)
        SELECT T3.C_CD
              ,(SELECT MAX(DATA_ID) + T3.NUM FROM BEE210)
              ,T3.EMP_ID
              ,'N'
              ,I_ISSUE_YMD
              ,'10'
              ,0
              ,NULL
              ,NULL
              ,'N'
              ,NULL
              ,NULL
              ,I_ISSUE_YMD
              ,NULL
              ,I_MOD_USER_ID
              ,SYSDATE
              ,I_MOD_USER_ID
              ,SYSDATE
          FROM (SELECT T1.C_CD
                      ,T1.EMP_ID
                      ,ROWNUM AS NUM
                  FROM PA1020_V_B T1
                 WHERE T1.C_CD = I_C_CD
                   AND I_ISSUE_YMD BETWEEN T1.STA_YMD AND T1.END_YMD
                   AND T1.STAT_CD LIKE '1%' -- 기준일 시점 재직이고
                   AND T1.ENTER_YMD >= '20110103' -- 2011.01.03 하드코딩, 진용인 수정
                   AND T1.ENTER_YMD <= I_ISSUE_YMD -- 기준일이전입사자
                   AND T1.EMP_TYPE NOT IN ('O', 'P', '8', '8H', '8P') -- 외주직, 일용직, 타사직원 제외 (11.07.25-외주직 코드 세분화)
                   AND T1.EMP_ID NOT IN (SELECT EMP_ID
                                           FROM BEE210
                                          WHERE C_CD = I_C_CD
                                            AND ISSUE_CLASS = '10'
                                            AND SUBSTR(ISSUE_YMD, 0, 4) = SUBSTR(I_ISSUE_YMD, 0, 4)) -- 사원증관리에 사번없고     
                ) T3 -- 사원증없는 사번
        ;

    O_ERRORCODE := '0';
    O_ERRORMESG := '성공';
EXCEPTION
    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE; -- -20000;
        O_ERRORMESG := SQLERRM; --'사원증신규 대상자 생성중 에러가 발생 하였습니다.';
END;
/
