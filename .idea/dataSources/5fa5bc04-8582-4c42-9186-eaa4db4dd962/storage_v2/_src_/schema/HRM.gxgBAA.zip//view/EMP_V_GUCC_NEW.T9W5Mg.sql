CREATE VIEW EMP_V_GUCC_NEW AS SELECT 'H139' AS COMPANY_CODE,
          SUBSTR (T1.EMP_ID, 3, 7) AS EMP_NO,
          T1.EMP_NM AS EMP_NAME,
          T1.ENG_EMP_NM AS EMP_ENG_NAME,
          NULL AS EMP_FIRST_NAME,
          NULL AS EMP_LAST_NAME,
             -- T2.ORG_ID AS ORG_CODE,
          T2.WORK_LOC_ID AS ORG_CODE,
          T7.ORG_NAME AS ORG_NAME,
          T7.ORG_ENG_NAME AS ORG_ENG_NAME,
          '1' AS WP_CODE,
          '본사' AS WP_NAME,
          NULL AS WP_ENG_NAME,
          F_GET_CODENM (T3.C_CD, 'OM010', T3.ORG_CLASS) AS ORG_GRD_NAME,
          NULL AS ASGN_GRD_CODE,
          NULL AS ASGN_FLAG,
          NULL AS ASGN_CODE,
          NULL AS ASGN_NAME,
          NULL AS ASGN_ENG_NAME,
          NULL AS JOB_CODE,
          NULL AS JOB_NAME,
          NULL AS JOB_ENG_NAME,
          --F_GET_CODE_ORDER (T2.C_CD, '00100', T2.POST_CD2) || T2.POST_CD2
          NVL (PKG_HEC_GUCC.F_GET_POST_CODE (T2.C_CD, T2.POST_CD2), '99')
             AS POS_CODE,
          --F_GET_CODENM (T2.C_CD, '00100', T2.POST_CD2) POS_NAME,
          NVL (PKG_HEC_GUCC.F_GET_POST_NAME (T2.C_CD, T2.POST_CD2), '사원')
             AS POS_NAME,
          NULL AS POS_ENG_NAME,
          TRIM (
             TO_CHAR (
                DECODE (T2.POST_CD2,
                        '00', 0,
                        '01', 1,
                        '02', 2,
                        '03', 3,
                        '04', 4,
                        '05', 5,
                        '06', 6,
                        '26', 7,
                        '0A', 8,
                        '0B', 9,
                        '2A', 10,
                        '2B', 11,
                        '82', 12,
                        T6.NEW_ORDER),
                '00'))
             AS POS_LEVEL,
          T2.POST_CD2 AS GRADE_CODE,
          F_GET_CODENM (T2.C_CD, '00100', T2.POST_CD2) AS GRADE_NAME,
          NULL AS GRADE_ENG_NAME,
          '1' AS OCC_GRP_CODE,
          '일반직' AS OCC_GRP_NAME,
          NULL AS OCC_GRP_ENG_NAME,
          NULL AS JOB_TITLE_CODE,
          NULL AS JOB_TITLE_NAME,
          NULL AS JOB_TITLE_ENG_NAME,
          NULL AS BIZ_ADD_FLAG,
          CASE
             WHEN T2.EMP_TYPE IN ('A',
                                  'B',
                                  'C',
                                  'D',
                                  'G',
                                  'I',
                                  'J',
                                  'K',
                                  'N',
                                  'M',
                                  'R',
                                  'S')                   -- 시설직원 추가 2015.02.09
             THEN
                '0'
             ELSE
                '8'
          END
             AS USER_COMP_TYPE,
          CASE
             WHEN T2.EMP_TYPE IN ('A',
                                  'B',
                                  'C',
                                  'D',
                                  'G',
                                  'I',
                                  'J',
                                  'K',
                                  'N',
                                  'M',
                                  'R',
                                  'S')                   -- 시설직원 추가 2015.02.09
             THEN
                'U01'
             ELSE
                'U07'
          END
             AS USER_TYPE,
          NULL AS RET_FLAG,
          NULL AS RET_DATE,
          NULL AS EXPIRE_DATE,
          NULL AS LOCK_DATE,
          NULL AS DELETE_DATE,
          NULL AS APPO_DATE,
          NULL AS HIRE_DATE,
          NULL AS TEL_NO,
          T1.WORK_LOC_TEL_NO AS CORP_TEL_NO,
          T1.MOBILE_NO AS MOBILE,
          T1.WORK_LOC_FAX AS FAX,
          T1.MAIL_ADDR AS EMAIL,
          NULL AS BIRTH_DAY,
          NULL AS SEX_FLAG,
          NULL AS TAKEOFF_FLAG,
          NULL AS CHARGE_JOB,
          NULL AS CHARGE_JOB_DTL,
          NULL AS COMM_ORG_CODE,
          CASE WHEN T1.MAIL_ADDR IS NOT NULL THEN 'Y' ELSE 'N' END
             AS MESNG_FLAG,
          T1.MAIL_ADDR AS MESNG_ID,
          NULL AS COMM_ACL,
          T1.EMP_ID AS PHOTO_LINK_URL,
          NULL AS HOT_LINE,
          NULL AS TEL_LINK_TYPE,
          NULL AS ORG_TEAM_CODE,
          NULL AS ORIGINAL_ORG_CODE,
          NULL AS CUSTOM_ATTR1,
          NULL AS CUSTOM_ATTR2,
          NULL AS CUSTOM_ATTR3,
          NULL AS CUSTOM_ATTR4,
          NULL AS CUSTOM_ATTR5,
          NULL AS CUSTOM_ATTR6,
          NULL AS CUSTOM_ATTR7,
          NULL AS CUSTOM_ATTR8,
          NULL AS CUSTOM_ATTR9,
          NULL AS WORK_TYPE,
          NULL AS WORK_DATE
     FROM PA1010# T1,
          PA1020 T2,
          OM0010 T3,
          SY5020 T4,
          SY3010 T5,
          (SELECT C_CD,
                  CD,
                  20 + ROW_NUMBER () OVER (ORDER BY DP_ORDER) AS NEW_ORDER
             FROM SY5020
            WHERE     IDX_CD = '00100'
                  AND CD IN (SELECT POST_CD2
                               FROM PA1020
                              WHERE     TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN STA_YMD
                                                                          AND END_YMD
                                    AND LAST_YN = 'Y'
                                    AND STAT_CD LIKE '1%')) T6,
          ORG_V_GUCC_NEW T7
    WHERE     T1.C_CD = T2.C_CD(+)
          AND T1.EMP_ID = T2.EMP_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD(+)
                                                AND T2.END_YMD(+)
          --
          AND T2.C_CD = T3.C_CD(+)
          AND T2.ORG_ID = T3.ORG_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T3.STA_YMD(+)
                                                AND T3.END_YMD(+)
          --
          AND T2.C_CD = T4.C_CD(+)
          AND T4.IDX_CD(+) = '/SY04'
          AND T2.POST_CD = T4.CD(+)
          --
          AND T2.C_CD = T5.C_CD(+)
          AND T2.ORG_ID = T5.OBJ_ID(+)
          AND T5.OBJ_TYPE NOT IN ('OE')
          --
          AND T2.C_CD = T6.C_CD(+)
          AND T2.POST_CD2 = T6.CD(+)
          --
          AND T2.WORK_LOC_ID = T7.ORG_CODE
          --
          AND T2.LAST_YN = 'Y'
          AND T2.STAT_CD = '10'
          AND T2.POST_CD2 NOT IN ('82', 'A0', '81')               -- 자문, 고문 제외
          AND CASE
                 WHEN T2.EMP_TYPE IN ('A',
                                      'B',
                                      'C',
                                      'D',
                                      'G',
                                      'I',
                                      'J',
                                      'K',
                                      'N',
                                      'M',
                                      'R',
                                      'S')               -- 시설직원 추가 2015.02.09
                 THEN
                    '1'
              END = '1'
          AND T1.EMP_ID NOT IN ('201504684' -- 임유역 사원(1504684) 예외처리. 최정환 차장 요청(15.01.30)
                                           )
UNION                                           
   SELECT 'H139' AS COMPANY_CODE,
          SUBSTR (T1.EMP_ID, 3, 7) AS EMP_NO,
          T1.EMP_NM AS EMP_NAME,
          T1.ENG_EMP_NM AS EMP_ENG_NAME,
          NULL AS EMP_FIRST_NAME,
          NULL AS EMP_LAST_NAME,
             -- T2.ORG_ID AS ORG_CODE,
             -- 본부장 직책의 경우 근무지ID 앞에 X를 기표하여 본부장 근무지 아래에 dummy로 추가된 조직에 매핑되도록 처리한다.
             CASE
                WHEN T2.DUTY_CD IN ('AE', 'AK') AND T3.ORG_CLASS = '002'
                THEN
                   'X'
             END
          || T2.WORK_LOC_ID
             AS ORG_CODE,
          T7.ORG_NAME AS ORG_NAME,
          T7.ORG_ENG_NAME AS ORG_ENG_NAME,
          '1' AS WP_CODE,
          '본사' AS WP_NAME,
          NULL AS WP_ENG_NAME,
          F_GET_CODENM (T3.C_CD, 'OM010', T3.ORG_CLASS) AS ORG_GRD_NAME,
          NULL AS ASGN_GRD_CODE,
          NULL AS ASGN_FLAG,
          NULL AS ASGN_CODE,
          NULL AS ASGN_NAME,
          NULL AS ASGN_ENG_NAME,
          NULL AS JOB_CODE,
          NULL AS JOB_NAME,
          NULL AS JOB_ENG_NAME,
          --F_GET_CODE_ORDER (T2.C_CD, '00100', T2.POST_CD2) || T2.POST_CD2
          NVL (PKG_HEC_GUCC.F_GET_POST_CODE (T2.C_CD, T2.POST_CD2), '99')
             AS POS_CODE,
          --F_GET_CODENM (T2.C_CD, '00100', T2.POST_CD2) POS_NAME,
          NVL (PKG_HEC_GUCC.F_GET_POST_NAME (T2.C_CD, T2.POST_CD2), '사원')
             AS POS_NAME,
          NULL AS POS_ENG_NAME,
          TRIM (
             TO_CHAR (
                DECODE (T2.POST_CD2,
                        '00', 0,
                        '01', 1,
                        '02', 2,
                        '03', 3,
                        '04', 4,
                        '05', 5,
                        '06', 6,
                        '26', 7,
                        '0A', 8,
                        '0B', 9,
                        '2A', 10,
                        '2B', 11,
                        '82', 12,
                        T6.NEW_ORDER),
                '00'))
             AS POS_LEVEL,
          T2.POST_CD2 AS GRADE_CODE,
          F_GET_CODENM (T2.C_CD, '00100', T2.POST_CD2) AS GRADE_NAME,
          NULL AS GRADE_ENG_NAME,
          '1' AS OCC_GRP_CODE,
          '일반직' AS OCC_GRP_NAME,
          NULL AS OCC_GRP_ENG_NAME,
          NULL AS JOB_TITLE_CODE,
          NULL AS JOB_TITLE_NAME,
          NULL AS JOB_TITLE_ENG_NAME,
          NULL AS BIZ_ADD_FLAG,
          CASE
             WHEN T2.EMP_TYPE IN ('A',
                                  'B',
                                  'C',
                                  'D',
                                  'G',
                                  'I',
                                  'J',
                                  'K',
                                  'N',
                                  'M',
                                  'R',
                                  'S')                   -- 시설직원 추가 2015.02.09
             THEN
                '0'
             ELSE
                '8'
          END
             AS USER_COMP_TYPE,
          CASE
             WHEN T2.EMP_TYPE IN ('A',
                                  'B',
                                  'C',
                                  'D',
                                  'G',
                                  'I',
                                  'J',
                                  'K',
                                  'N',
                                  'M',
                                  'R',
                                  'S')                   -- 시설직원 추가 2015.02.09
             THEN
                'U01'
             ELSE
                'U07'
          END
             AS USER_TYPE,
          NULL AS RET_FLAG,
          NULL AS RET_DATE,
          NULL AS EXPIRE_DATE,
          NULL AS LOCK_DATE,
          NULL AS DELETE_DATE,
          NULL AS APPO_DATE,
          NULL AS HIRE_DATE,
          NULL AS TEL_NO,
          T1.WORK_LOC_TEL_NO AS CORP_TEL_NO,
          T1.MOBILE_NO AS MOBILE,
          T1.WORK_LOC_FAX AS FAX,
          T1.MAIL_ADDR AS EMAIL,
          NULL AS BIRTH_DAY,
          NULL AS SEX_FLAG,
          NULL AS TAKEOFF_FLAG,
          NULL AS CHARGE_JOB,
          NULL AS CHARGE_JOB_DTL,
          NULL AS COMM_ORG_CODE,
          CASE WHEN T1.MAIL_ADDR IS NOT NULL THEN 'Y' ELSE 'N' END
             AS MESNG_FLAG,
          T1.MAIL_ADDR AS MESNG_ID,
          NULL AS COMM_ACL,
          T1.EMP_ID AS PHOTO_LINK_URL,
          NULL AS HOT_LINE,
          NULL AS TEL_LINK_TYPE,
          NULL AS ORG_TEAM_CODE,
          NULL AS ORIGINAL_ORG_CODE,
          NULL AS CUSTOM_ATTR1,
          NULL AS CUSTOM_ATTR2,
          NULL AS CUSTOM_ATTR3,
          NULL AS CUSTOM_ATTR4,
          NULL AS CUSTOM_ATTR5,
          NULL AS CUSTOM_ATTR6,
          NULL AS CUSTOM_ATTR7,
          NULL AS CUSTOM_ATTR8,
          NULL AS CUSTOM_ATTR9,
          NULL AS WORK_TYPE,
          NULL AS WORK_DATE
     FROM PA1010# T1,
          PA1020 T2,
          OM0010 T3,
          SY5020 T4,
          SY3010 T5,
          (SELECT C_CD,
                  CD,
                  20 + ROW_NUMBER () OVER (ORDER BY DP_ORDER) AS NEW_ORDER
             FROM SY5020
            WHERE     IDX_CD = '00100'
                  AND CD IN (SELECT POST_CD2
                               FROM PA1020
                              WHERE     TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN STA_YMD
                                                                          AND END_YMD
                                    AND LAST_YN = 'Y'
                                    AND STAT_CD LIKE '1%')) T6,
          ORG_V_GUCC_NEW T7
    WHERE     T1.C_CD = T2.C_CD(+)
          AND T1.EMP_ID = T2.EMP_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD(+)
                                                AND T2.END_YMD(+)
          --
          AND T2.C_CD = T3.C_CD(+)
          AND T2.ORG_ID = T3.ORG_ID(+)
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T3.STA_YMD(+)
                                                AND T3.END_YMD(+)
          --
          AND T2.C_CD = T4.C_CD(+)
          AND T4.IDX_CD(+) = '/SY04'
          AND T2.POST_CD = T4.CD(+)
          --
          AND T2.C_CD = T5.C_CD(+)
          AND T2.ORG_ID = T5.OBJ_ID(+)
          AND T5.OBJ_TYPE NOT IN ('OE')
          --
          AND T2.C_CD = T6.C_CD(+)
          AND T2.POST_CD2 = T6.CD(+)
          --
          AND    CASE
                    WHEN T2.DUTY_CD IN ('AE', 'AK') AND T3.ORG_CLASS = '002'
                    THEN
                       'X'
                 END
              || T2.WORK_LOC_ID = T7.ORG_CODE
          --
          AND T2.LAST_YN = 'Y'
          AND T2.STAT_CD = '10'
          AND T2.POST_CD2 NOT IN ('82', 'A0', '81')               -- 자문, 고문 제외
          AND CASE
                 WHEN T2.EMP_TYPE IN ('A',
                                      'B',
                                      'C',
                                      'D',
                                      'G',
                                      'I',
                                      'J',
                                      'K',
                                      'N',
                                      'M',
                                      'R',
                                      'S')               -- 시설직원 추가 2015.02.09
                 THEN
                    '1'
              END = '1'
          AND T1.EMP_ID NOT IN ('201504684' -- 임유역 사원(1504684) 예외처리. 최정환 차장 요청(15.01.30)
                                           )
/
