CREATE VIEW VW_PY2361 AS SELECT T2.C_CD,
          T2.ORGN_YM,
          T2.PAYROLL_TYPE,
          T2.PAYROLL_NO,
          T1.EMP_ID,
          T1.PAYITEM,
          T3.CD_NM PAYITEM_NM,
          T1.SEQ_NO,
          T1.LAST_MON
     FROM PY2360 T1, PY0300 T2, SY5020 T3
    WHERE T2.C_CD = T1.C_CD
          AND T2.PAYROLL_NO = T1.PAYROLL_NO
        --AND T1.PAYITEM IN ('D105', 'D110') -- 고객사별 연말정산 환급,추징과 관련된 모든 급여항목을 넣습니다. ( 차감소득세,차감주민세,차감농특세 등 )
          AND T1.PAYITEM IN ('D3800')  --//(HEC) [D3800]연말정산세액 단일항목으로 처리
          AND T3.C_CD = T1.C_CD
          AND T3.IDX_CD = '/PY02'
          AND T3.CD = T1.PAYITEM
/
COMMENT ON VIEW VW_PY2361 IS '(VW_PY2361)연말정산_세액분할납부(급여정보 참조)'
/
