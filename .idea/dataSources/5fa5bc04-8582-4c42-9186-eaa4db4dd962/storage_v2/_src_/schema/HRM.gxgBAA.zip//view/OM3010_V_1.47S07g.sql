CREATE VIEW OM3010_V_1 AS SELECT T1."C_CD",T1."OBJ_TYPE",T1."OBJ_ID",T1."PAR_OBJ_TYPE",T1."PAR_OBJ_ID",T1."STA_YMD",T1."END_YMD",T1."SEQ_NO",T1."ORDER_NO",T1."ETC_PPT_1",T1."ETC_PPT_2",T1."ETC_PPT_3",T1."ETC_PPT_4",T1."ETC_PPT_5",T1."POS_LV_CD",T1."REORG_CLASS",T1."REORG_RSN_TXT",T1."LEVEL_OF_ASPIRATION",T1."REQUIRE_CD",T1."INS_USER_ID",T1."INS_YMDHMS",T1."MOD_USER_ID",T1."MOD_YMDHMS", LEVEL TLEVEL, ROWNUM DP_ORDER
FROM     (SELECT  T1.*
               FROM     SY3020 T1
               WHERE (T1.C_CD, T1.OBJ_TYPE) IN
                                                                   (SELECT A.C_CD, A.OBJ_TYPE
                                                                    FROM SY3080 A
                                                                    WHERE A.OBJ_TREE_TYPE = 'WATREE'
                                                                    AND    ROWNUM >0)
               AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD AND T1.END_YMD) T1
              START WITH 1 = 1
              AND (T1.C_CD, T1.OBJ_TYPE, T1.OBJ_ID) IN
                                                                            (SELECT A.C_CD, A.ROOT_OBJ_TYPE, A.ROOT_OBJ_ID
                                                                             FROM SY3070 A
                                                                             WHERE 1 = 1 AND A.OBJ_TREE_TYPE = 'WATREE'
                                                                             AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN A.STA_YMD  AND A.END_YMD
                                                                             AND ROWNUM >0)
              AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD AND T1.END_YMD
              AND (T1.C_CD, T1.PAR_OBJ_TYPE) IN
                                                                    (SELECT A.C_CD, A.OBJ_TYPE
                                                                     FROM SY3080 A
                                                                    WHERE A.OBJ_TREE_TYPE = 'WATREE'
                                                                    AND ROWNUM >0)
              CONNECT BY     1 = 1
             AND PRIOR T1.C_CD = T1.C_CD
             AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
             AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
             AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD   AND T1.END_YMD
           ORDER SIBLINGS BY T1.C_CD, T1.SEQ_NO
/
COMMENT ON VIEW OM3010_V_1 IS '(OM3010_V_1)'
/
