CREATE PROCEDURE     P_BE_COPY_BEB210_HRM
(
    I_C_CD         IN VARCHAR2,
    I_APPL_YY      IN VARCHAR2, --신청년도                
    I_SRC_QT_CD    IN VARCHAR2, -- 복사원본분기
    I_TRG_QT_CD    IN VARCHAR2, --분기코드
    I_SRC_SCHO_QT_CD   IN VARCHAR2, --복사원본학사분기                                                
    I_TRG_SCHO_QT_CD   IN VARCHAR2, --학사분기     
    I_PAY_YM       IN VARCHAR2, --지급년월
    I_MOD_USER_ID  IN VARCHAR2,
    O_ERRORCODE    OUT VARCHAR2,
    O_ERRORMESG    OUT VARCHAR2
) IS
    /***********************************************************************
     Program Name   : P_BE_COPY_BEB210
     Description    : 학자금신청 데이터 복사
     Author         : 정명주
     History        : 2011.06.07 신규생성
    ***********************************************************************/

    V_I NUMBER := 1;
    V_APPL_ID VARCHAR2(20);
    V_BEB220_PAY_MON NUMBER;  -- 학자금관리의 지급금액
    V_DUP_CNT NUMBER := 0;

BEGIN
    FOR C IN (SELECT T1.*
                    ,T2.APPL_EMP_ID
                    ,T2.TRG_EMP_ID
                FROM GAIS.BEB210# T1
                    ,SY7010 T2
                    ,PA1020_V_1 T3
               WHERE T1.C_CD = I_C_CD
                 AND T1.APPL_YY = I_APPL_YY   -- 년도
                 AND T1.QT_CD = I_SRC_QT_CD -- n분기를 다른분기로..
                 AND T1.SCHO_QT_CD = I_SRC_SCHO_QT_CD -- 학자금 지급대상분기 선택
                 AND T1.SCHEXP_CLASS = '20' -- 고등학교
                 AND T2.C_CD = T1.C_CD
                 AND T2.APPL_ID = T1.APPL_ID
                 AND T2.APPL_TYPE = '003'  -- 학자금
                 AND T3.C_CD = T2.C_CD
                 AND T3.EMP_ID = T2.TRG_EMP_ID
                 AND TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN T3.STA_YMD AND T3.END_YMD -- 생성일 기준
                 AND T3.STAT_CD LIKE '1%' -- 재직이고
              )
    LOOP
    
        -- 원본에서 2개학기 이상 신청한 경우 에러 발생시킨다. 중복으로 복제되므로. 2014.01.21 김성관
        SELECT COUNT(*)
          INTO V_DUP_CNT
          FROM GAIS.BEB210#
         WHERE C_CD = I_C_CD
           AND APPL_YY = I_APPL_YY
           AND QT_CD = I_SRC_QT_CD
           AND SCHO_QT_CD = I_SRC_SCHO_QT_CD
           AND SCHEXP_CLASS = '20'
           AND TRG_PER_NO = C.TRG_PER_NO;
           
        IF V_DUP_CNT > 1 THEN
            RAISE_APPLICATION_ERROR(-20000, '원본 학기에 중복신청된 건이 존재하여 복사를 중지합니다. 사번 : '||C.TRG_EMP_ID||', 자녀 성명 : '||C.TRG_NM||'. 자녀 주민번호 : '||C.TRG_PER_NO);
        END IF;
    
        -- 신청서ID 조회
        SELECT LPAD(SEQ_APPL_ID.NEXTVAL, 20, '0') INTO V_APPL_ID FROM DUAL;
    
        INSERT INTO SY7010
            ( C_CD
            , APPL_ID
            , APPL_TYPE
            , APPL_EMP_ID
            , TRG_EMP_ID
            , TRG_EMP_NM
            , ADM_EMP_ID
            , APPL_YMD
            , APPL_STAT_CD
            , APPR_YMD
            , ADM_YN
            , NOTE
            , MOD_USER_ID
            , MOD_YMDHMS
            , INS_USER_ID
            , INS_YMDHMS)
        VALUES
            (I_C_CD,
             V_APPL_ID,
             '003',
             C.TRG_EMP_ID,
             C.TRG_EMP_ID,
             C.TRG_NM,
             '',
             TO_CHAR(SYSDATE, 'YYYYMMDD'),
             '500', -- 최종완료상태
             '',
             'N',
             '',
             I_MOD_USER_ID,
             SYSDATE,
             I_MOD_USER_ID,
             SYSDATE);
    
        -- 학자금관리의 지급금액을 신청금액으로 넣기 위해 관리의 지급금액을 조회
        BEGIN
          SELECT NVL(PAY_MON, 0)
            INTO V_BEB220_PAY_MON
            FROM GAIS.BEB220#  -- 학자금 관리
           WHERE C_CD = I_C_CD
             AND APPL_ID = C.APPL_ID  -- 학자금 신청(SHEET형) 으로 변경 후 자녀한명 당 APPL_ID 한건임..
             ;
        EXCEPTION 
          WHEN NO_DATA_FOUND THEN
            V_BEB220_PAY_MON := 0;
        END;
    
        -- 학자금 관리에서 수정시, 학자금 신청 데이터의 지금금액을 UPDATE 한다.
        INSERT INTO GAIS.BEB210#
            (SCHO_QT_CD, --학사분기
             C_CD, --회사코드
             APPL_ID, --신청서ID
             SEQ_NO, --일련번호
             APPL_YY, --신청년도
             QT_CD, --분기코드
             TRG_NM, --대상성명
             TRG_PER_NO, --대상주민번호
             FAM_CD, --가족관계코드
             SCHEXP_CLASS, --학자금구분
             SCHL_NM, --학교명
             SCHL_YY_CD, --학년코드
             CNT, --횟수
             APPL_MON, --신청금액
             PAY_MON, --지급금액
             PAY_YM, --지급년월
             NOTE, --비고
             INS_USER_ID, --입력자ID
             INS_YMDHMS, --입력일시
             MOD_USER_ID, --작업자ID
             MOD_YMDHMS --수정일시
             )
        VALUES
            (I_TRG_SCHO_QT_CD, --학사분기
             I_C_CD, --회사코드
             V_APPL_ID, -- APPL_ID, 신청서ID
             1, --일련번호
             I_APPL_YY, --신청년도
             I_TRG_QT_CD, --분기코드
             C.TRG_NM, --대상성명
             C.TRG_PER_NO, --대상주민번호
             C.FAM_CD, --가족관계코드
             '20', --학자금구분
             C.SCHL_NM, --학교명
             C.SCHL_YY_CD, --학년코드
             NVL(C.CNT, 0) + 1, --횟수
             V_BEB220_PAY_MON, --신청금액, 전분기 신청금액이 아닌, 관리에 있는 금액을 조회하여 INSERT, 없다면 0 으로... 
             V_BEB220_PAY_MON, --지급금액, 관리에 있는 금액을 조회하여 INSERT, 없다면 0 으로...
             I_PAY_YM, --지급년월
             '자동신청', --비고
             'SUPER', --입력자ID
             SYSDATE, --입력일시
             'SUPER', --작업자ID
             SYSDATE --수정일시
             );
       
      DBMS_OUTPUT.PUT_LINE(V_I || ', ' || C.TRG_EMP_ID || ', ' || V_APPL_ID || ', ' || C.TRG_PER_NO); 
      V_I := V_I + 1;
    
    END LOOP;

    O_ERRORCODE := '0';
    O_ERRORMESG := '성공';
EXCEPTION
    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE;
        O_ERRORMESG := SQLERRM;
END;
/
