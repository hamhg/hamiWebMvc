CREATE VIEW VW_ADJ_LATEST_CHANGE_TARGET AS SELECT TB1.C_CD
       , TB1.ADJ_YY 
       , TB1.EMP_ID
       , MAX(TB1.MOD_USER_ID) AS MOD_USER_ID
       , TO_CHAR(MAX(TB1.MOD_YMDHMS), 'YYYY-MM-DD HH24:MI:SS') AS MOD_YMDHMS
  FROM (
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(T1.MOD_USER_ID) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2105 T1  --#(HEC주석)VW_YA2105 --// 카드 추가공제
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2150# T1  --#(HEC주석)VW_YA2150--// 월세액 거주자간 임차차입금 원리금 상환액
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================          
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2210 T1  --#(HEC주석)VW_YA2210--// 주택 설문
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2140# T1  --#(HEC주석)VW_YA2140--// 주택팝업
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2045 T1  --#(HEC주석)VW_YA2045--// 전근무지비과세
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2040 T1  --#(HEC주석)VW_YA2040--// 전근무지소득
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2095 T1  --#(HEC주석)VW_YA2095--// 현근무지비과세
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2090 T1  --#(HEC주석)VW_YA2090--// 현근무지소득
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2020 T1  --#(HEC주석)VW_YA2020--// 정산항목신청
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            ----=========================================================
            -- UNION
            ----=========================================================
            --SELECT *
            --  FROM YA2120 T1  --#(HEC주석)VW_YA2120--// 정산항목결과
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2130# T1  --#(HEC주석)VW_YA2130--// 교육비
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID  
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2100# T1  --#(HEC주석)VW_YA2100--// 카드비
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2060# T1  --#(HEC주석)VW_YA2060--// 기부금
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2050# T1  --#(HEC주석)VW_YA2050--// 의료비
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2070# T1  --#(HEC주석)VW_YA2070--// 보험료
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2080# T1  --#(HEC주석)VW_YA2080--// 연금저축
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA2030# T1  --#(HEC주석)VW_YA2030--// 정산가족
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            ----=========================================================
            -- UNION
            ----=========================================================
            --SELECT *
            --  FROM YA2110 T1  --#(HEC주석)VW_YA2110--//정산결과
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA5030# T1  --#(HEC주석)VW_YA5030--//정산결과상세데이터
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA5020# T1  --#(HEC주석)VW_YA5020--//전자문서주요데이터
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA5010 T1  --#(HEC주석)VW_YA5010--//전자문서업로드
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
            ----=========================================================
            -- UNION
            ----=========================================================
            --SELECT *
            --  FROM YA4020 T1  --#(HEC주석)VW_YA4020--//표준세액공제대상자
            --=========================================================
             UNION
            --=========================================================
            SELECT T1.C_CD
                   , T1.ADJ_YY
                   , T1.EMP_ID
                   , NVL(MAX(NVL(T1.MOD_USER_ID, T1.INS_USER_ID)) KEEP (DENSE_RANK FIRST ORDER BY NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS) DESC), 0) AS MOD_USER_ID
                   , MAX(NVL(T1.MOD_YMDHMS, T1.INS_YMDHMS)) AS MOD_YMDHMS
              FROM YA1010 T1  --#(HEC주석)VW_YA1010--//정산대상자
             GROUP BY T1.C_CD
                      , T1.ADJ_YY
                      , T1.EMP_ID
       ) TB1
 GROUP BY TB1.C_CD
          , TB1.ADJ_YY
          , TB1.EMP_ID
/
