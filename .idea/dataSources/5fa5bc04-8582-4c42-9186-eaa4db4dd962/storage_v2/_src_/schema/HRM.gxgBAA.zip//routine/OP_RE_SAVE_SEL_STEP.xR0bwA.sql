CREATE PROCEDURE OP_RE_SAVE_SEL_STEP (
   I_IUD           IN     VARCHAR2,
   I_C_CD          IN     RE3050.C_CD%TYPE,                            -- 회사코드
   I_RE_NO         IN     RE3050.RE_NO%TYPE,                         -- 채용일련번호
   I_SEL_STEP      IN     RE3050.SEL_STEP%TYPE,
   I_ORDER_NO      IN     RE3050.DP_ORDER%TYPE,
   I_CLOSE_YN      IN     RE3050.CLOSE_YN%TYPE,
   I_EXPT_YMD      IN     RE3050.EXPT_YMD%TYPE,                     -- 전형예정일
   I_MOD_USER_ID   IN     RE3050.MOD_USER_ID%TYPE,                    -- 작업자ID
   O_ERRORCODE        OUT VARCHAR2,                                   -- 에러 코드
   O_ERRORMSG         OUT VARCHAR2                                   -- 에러 메세지
                                  )
IS
   R_RE3050_OLD   RE3050%ROWTYPE;

   V_STAT_CD      VARCHAR2 (10);                          -- 현 전형단계에 해당하는 채용상태
   V_RE_TITLE     VARCHAR2 (500);

   V_ERRORCODE    VARCHAR2 (10);
   V_ERRORMSG     VARCHAR2 (1000);
/***********************************************************************
 Program Name   : OP_RE_FIX01
 Description    : 전형단계별 확정 처리
 Author         : 한은총
 History        : 2008-02-25 신규개발
***********************************************************************/

BEGIN
   IF I_IUD = 'I'
   THEN
      -- 채용제목조회
      BEGIN
          SELECT RE_TITLE
            INTO V_RE_TITLE
            FROM RE3010 T1
           WHERE C_CD = I_C_CD
             AND RE_NO = I_RE_NO;
      EXCEPTION WHEN OTHERS THEN
        V_RE_TITLE := '';
      END;
         
      -- 채용 전형항목기준
      -- 채용 전형항목기준
      DELETE FROM RE3050
            WHERE C_CD = I_C_CD AND RE_NO = I_RE_NO AND SEL_STEP = I_SEL_STEP;


      DELETE FROM RE3090
            WHERE C_CD = I_C_CD AND RE_NO = I_RE_NO AND SEL_STEP = I_SEL_STEP;


      INSERT INTO RE3050 (C_CD,
                          RE_NO,
                          SEL_STEP,
                          DP_ORDER,
                          CLOSE_YN,
                          EXPT_YMD,
                          MOD_USER_ID,
                          MOD_YMDHMS)
          VALUES (I_C_CD,
                  I_RE_NO,
                  I_SEL_STEP,
                  I_ORDER_NO,
                  I_CLOSE_YN,
                  I_EXPT_YMD,
                  I_MOD_USER_ID,
                  SYSDATE);

      INSERT INTO RE3090 (C_CD,
                          RE_NO,
                          SEL_STEP,
                          PASS_TYPE,
                          MAIL_TXT,
                          SMS_TXT,
                          NOTE,
                          SEND_MOBILE_NO,
                          MAIL_TITLE,
                          MOD_USER_ID,
                          MOD_YMDHMS)
          VALUES (I_C_CD,
                  I_RE_NO,
                  I_SEL_STEP,
                  'N',
                  --'현대엔지니어링에 대한 깊은 관심과 애정에 감사 드립니다.<br><br>금번 전형 결과 귀하께서 불합격하셨음을 알려드리게 되어 안타깝게 생각합니다.<br><br>다음에 더 좋은 인연으로 현대엔지니어링과 함께 할 수 있길 기원합니다.<br><br>감사합니다.',
                   '안녕하십니까 현대엔지니어링 인사실입니다.<br><br>'
                || '금번 현대엔지니어링에서 실시한 &quot;' || V_RE_TITLE || '&quot;에<br><br>'
                || '지원해 주셔서 진심으로 감사 드립니다.<br><br><br>'
                || '귀하를 포함한 대부분의 지원자가 자질과 능력이 매우 우수하여 당사는<br><br>'
                || '여러 번의 검토과정을 거쳐 엄정하고 객관적인 심사를 하였습니다.<br><br><br>'
                || '그 결과 제한된 채용인원으로 인하여 귀하의 재능과 능력을 당사에서<br><br>'
                || '마음껏 발휘할 수 있는 기회를 제공하지 못함을 안타깝게 생각합니다.<br><br>'
                || '다시 한번 당사에 지원해 주신 정성에 감사드리며,<br><br>'
                || '다음 기회에 좋은 인연으로 만나 뵐 수 있기를 기원합니다.<br><br><br>'
                || '<b>-   현대엔지니어링 인사실   -</b>',
                  '',
                  '',
                  '02-2134-1114',
                  --'[현대엔지니어링'||F_GET_CODENM(I_C_CD, '03050', I_SEL_STEP) ||']'||V_RE_TITLE,
                  '현대엔지니어링 채용전형 결과 안내',
                  I_MOD_USER_ID,
                  SYSDATE);

      INSERT INTO RE3090 (C_CD,
                          RE_NO,
                          SEL_STEP,
                          PASS_TYPE,
                          MAIL_TXT,
                          SMS_TXT,
                          NOTE,
                          SEND_MOBILE_NO,
                          MAIL_TITLE,
                          MOD_USER_ID,
                          MOD_YMDHMS)
          VALUES (I_C_CD,
                  I_RE_NO,
                  I_SEL_STEP,
                  'Y',
                  '안녕하십니까 현대엔지니어링 입니다.<br><br>귀하께서는 아래와 같이 합격자로 확정되셨습니다.<br><br>이에 일정을 안내해 드리오니 <br><br>아래에 안내 드리는 시간에 맞춰 참석해주시기 바랍니다.',
                  '',
                  '',
                  '02-2134-1114',
                  --'[현대엔지니어링'||F_GET_CODENM(I_C_CD, '03050', I_SEL_STEP) ||']'||V_RE_TITLE,
                  '현대엔지니어링 채용전형 결과 안내',
                  I_MOD_USER_ID,
                  SYSDATE);
   ELSIF I_IUD = 'U'
   THEN
      -- 채용 전형항목기준


      UPDATE RE3050
         SET SEL_STEP = I_SEL_STEP,
             DP_ORDER = I_ORDER_NO,
             CLOSE_YN = I_CLOSE_YN,
             EXPT_YMD = I_EXPT_YMD,
             MOD_USER_ID = I_MOD_USER_ID,
             MOD_YMDHMS = SYSDATE
       WHERE C_CD = I_C_CD AND RE_NO = I_RE_NO AND SEL_STEP = I_SEL_STEP;
   ELSIF I_IUD = 'D'
   THEN
      -- 채용 전형항목기준
      DELETE FROM RE3050
            WHERE C_CD = I_C_CD AND RE_NO = I_RE_NO AND SEL_STEP = I_SEL_STEP;


      DELETE FROM RE3090
            WHERE C_CD = I_C_CD AND RE_NO = I_RE_NO AND SEL_STEP = I_SEL_STEP;
   END IF;

   O_ERRORCODE := '0';
   O_ERRORMSG := '';
EXCEPTION
   WHEN OTHERS
   THEN
      O_ERRORCODE := SQLCODE;
      O_ERRORMSG := SQLERRM;
END;
/
