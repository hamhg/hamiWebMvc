CREATE PROCEDURE     P_BE_BILL_TARGET01(
                            I_C_CD         IN  VARCHAR2, --회사코드 
                            I_SEQ_NO       IN  NUMBER,   --순번  
                            I_EMP_ID       IN  VARCHAR2, --사번                            
                            I_FAM_CD       IN  VARCHAR2, --가족관계코드 
                            I_FAM_PER_NO   IN  VARCHAR2, --부모님주민번호
                            I_HOSPITAL_CD  IN  VARCHAR2, --병원코드 
                            I_COM_MON      IN  NUMBER,   --회사부담금     
                            I_CHK_YMD      IN  VARCHAR2, --검진일자 
                            I_BILL_YMD     IN  VARCHAR2, --증빙일 
                            I_MOD_USER_ID  IN  VARCHAR2, --로그인유저 아이디 
                            O_ERRORCODE    OUT VARCHAR2,
                            O_ERRORMESG    OUT VARCHAR2,
                            O_SEQ_NO       OUT VARCHAR2
)
IS
/***********************************************************************
 Program Name   : P_BE_BILL_TARGET01
 Description    : 복리후생 전표대상 프로시져 
 Author         : 윤병근 
 History        : 2010-10-27
***********************************************************************/

  R1 BEHBILL_TEMP#%ROWTYPE;
BEGIN

  --=================================  
  --== 저장 변수 셋팅              ==
  --=================================              
  
  R1.C_CD         := I_C_CD;
  R1.SEQ_NO       := I_SEQ_NO;
  R1.EMP_ID       := I_EMP_ID; 
  R1.FAM_CD       := I_FAM_CD;
  R1.FAM_PER_NO   := F_HEC_ENC_PER(I_FAM_PER_NO);
  R1.HOSPITAL_CD  := I_HOSPITAL_CD;
  R1.COM_MON      := I_COM_MON;
  R1.CHK_YMD      := I_CHK_YMD;
  R1.BILL_YMD     := I_BILL_YMD;
  R1.INS_USER_ID  := I_MOD_USER_ID;
  R1.INS_YMDHMS   := SYSDATE;
  R1.MOD_USER_ID  := I_MOD_USER_ID;
  R1.MOD_YMDHMS   := SYSDATE;
  
  --===================================================
  --== BEHBILL_TEMP#  ( 전표대상 테이블 구성 작업     ==
  --=================================================== 
  
  BEGIN
     
      INSERT INTO BEHBILL_TEMP#
                (
                   C_CD,            SEQ_NO,          EMP_ID,           FAM_CD,      
                   FAM_PER_NO,      HOSPITAL_CD,     COM_MON,          CHK_YMD,    
                   BILL_YMD,        INS_USER_ID,      INS_YMDHMS,  
                   MOD_USER_ID,     MOD_YMDHMS  
                )
          VALUES
               (
                   R1.C_CD,         R1.SEQ_NO,       R1.EMP_ID,        R1.FAM_CD,  
                   R1.FAM_PER_NO,   R1.HOSPITAL_CD,  R1.COM_MON,       R1.CHK_YMD,
                   R1.BILL_YMD,     R1.INS_USER_ID,   R1.INS_YMDHMS,    
                   R1.MOD_USER_ID,  R1.MOD_YMDHMS   
               );
   EXCEPTION
      WHEN OTHERS THEN         
           RAISE_APPLICATION_ERROR( -20000, 'BEHBILL_TEMP# 저장 ERROR');
           RETURN;                         
   END;        
      
  O_ERRORCODE := '0';
  
  O_SEQ_NO := I_SEQ_NO;
   

COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    O_ERRORCODE := SQLCODE;
    O_ERRORMESG := SQLERRM;
END;
/
