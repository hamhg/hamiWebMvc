CREATE VIEW SY3020_V_I AS SELECT T1.TLEVEL,
            T1.SEQ_NO,
            T1.OBJ_TYPE,
            T1.OBJ_ID,
            T2.OBJ_NM,
            O1.ORG_CLASS,
            T1.PAR_OBJ_ID,
            T2.STA_YMD,
            T2.END_YMD,
            T2.SMR_OBJ_NM,
            T2.CHA_OBJ_NM,
            T2.ENG_OBJ_NM,
            T2.CHG_RSN_TXT,
            T2.TABLE_NM,
            decode(T2.WK_SITE,'1100','11','2100','21','3100','31','4200','42','7200','72','7100','71','6100','61','9100','91',T2.WK_SITE) WK_SITE,
            T2.ORG_FULL_NM,
            F_ORG_ID ('HEC',
                      TO_CHAR (SYSDATE, 'YYYYMMDD'),
                      T1.OBJ_ID,
                      '1')
               AS G_ID,
            F_ORG_NM ('HEC',
                      TO_CHAR (SYSDATE, 'YYYYMMDD'),
                      T1.OBJ_ID,
                      '1')
               AS G_NM,
            F_ORG_ID ('HEC',
                      TO_CHAR (SYSDATE, 'YYYYMMDD'),
                      T1.OBJ_ID,
                      '2')
               AS B_ID,
            F_ORG_NM ('HEC',
                      TO_CHAR (SYSDATE, 'YYYYMMDD'),
                      T1.OBJ_ID,
                      '2')
               AS B_NM
       FROM (           SELECT LEVEL TLEVEL,
                               T1.OBJ_TYPE,
                               T1.OBJ_ID,
                               T1.PAR_OBJ_ID,
                               T1.SEQ_NO,
                               ROWNUM SEQ
                          FROM (SELECT T1.*
                                  FROM SY3020 T1
                                 WHERE T1.C_CD = 'HEC' AND T1.OBJ_TYPE LIKE 'O%') T1
                    START WITH     T1.C_CD = 'HEC'
                               AND T1.OBJ_TYPE = 'O'
                               AND T1.OBJ_ID = 'O000000001'
                               AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                     AND T1.END_YMD
                    CONNECT BY     PRIOR T1.C_CD = T1.C_CD
                               AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
                               AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
             ORDER SIBLINGS BY T1.SEQ_NO) T1,
            SY3010 T2,
            OM0010 O1
      WHERE     T2.C_CD = 'HEC'
            AND T2.OBJ_TYPE = T1.OBJ_TYPE
            AND T2.OBJ_ID = T1.OBJ_ID
            AND O1.ORG_ID = T1.OBJ_ID
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD AND T2.END_YMD
   ORDER BY T1.SEQ
/
