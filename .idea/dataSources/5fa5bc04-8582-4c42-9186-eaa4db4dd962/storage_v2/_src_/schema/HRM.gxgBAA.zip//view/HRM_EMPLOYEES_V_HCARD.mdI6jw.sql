CREATE VIEW HRM_EMPLOYEES_V_HCARD AS SELECT SUBSTR (B.EMP_ID, 3) EMP_ID7,
            B.EMP_ID,
            A.EMP_NM,
            A.ENG_EMP_NM,
            B.POST_CD2 AS POST_CD,
            F_GET_CODENM (B.C_CD, '00100', B.POST_CD2) POST_NM,
            B.ORG_ID,
            B.ORG_NM,
            C.WORK_LOC_CLASS_CD,
            F_GET_CODENM (C.C_CD, 'OM020', C.WORK_LOC_CLASS_CD)
               WORK_LOC_CLASS_NM,
            A.ENTER_YMD,
            SUBSTR (F_HEC_DEC_PER (A.PER_NO), 1, 6) BIRTH_YMD
       FROM HRM.PA1010# A, HRM.PA1020 B, HRM.OM3010 C
      WHERE     A.C_CD = B.C_CD
            AND A.EMP_ID = B.EMP_ID
            AND B.C_CD = C.C_CD(+)
            AND B.WORK_LOC_ID = C.WORK_LOC_ID(+)
            AND B.STA_YMD BETWEEN C.STA_YMD(+) AND C.END_YMD(+)
            AND A.C_CD = 'HEC'
            AND B.LAST_YN = 'Y'
            -- 신용학 상무님 예외처리 2014.11.28
            /*
            AND CASE
                   WHEN A.EMP_ID = '201447141'
                   THEN
                      TO_CHAR (SYSDATE + 3, 'YYYYMMDD')
                   ELSE
                      TO_CHAR (SYSDATE + 3, 'YYYYMMDD')
                END BETWEEN B.STA_YMD
                        AND B.END_YMD
            */
            -- 김영태 전무(201502480), 강순문 상무(201502491) 예외처리 2014.12.31
            --AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN B.STA_YMD AND B.END_YMD
            AND CASE
                   WHEN A.EMP_ID IN ('201502480', '201502491')
                   THEN
                      TO_CHAR (SYSDATE + 1, 'YYYYMMDD')
                   ELSE
                      TO_CHAR (SYSDATE, 'YYYYMMDD')
                END BETWEEN B.STA_YMD
                        AND B.END_YMD
            AND B.STAT_CD LIKE '1%'
            AND B.EMP_TYPE IN ('A',
                               'B',
                               'C',
                               'D',
                               'G',
                               'I',
                               'J',
                               'N',
                               'M',
                               'K',
                               '8P',
                               'E',                       -- 별정직 추가 2014.08.08
                               'R',                      -- 전문위원 추가 2014.08.27
                               'S')                      -- 시설직원 추가 2015.02.09
            AND NVL (A.PAY_CALC_EXEC_YN, 'N') = 'N'
   ORDER BY B.POST_CD, EMP_NM
/
COMMENT ON VIEW HRM_EMPLOYEES_V_HCARD IS '[HCARD_IF용] (HRM_EMPLOYEES_V_HCARD)인사정보'
/
