CREATE PROCEDURE     MIG_RET_OFR_ADD_RATE
(
    I_EMP_ID    IN VARCHAR2, -- 사번
    O_ERRORCODE OUT VARCHAR2,
    O_ERRORMESG OUT VARCHAR2
) IS
    V_ERRORCODE VARCHAR2(1000);
    V_ERRORMESG VARCHAR2(1000);

    I_C_CD       VARCHAR2(20) := 'HEC';
    I_PAYROLL_NO VARCHAR2(20);
    V_OFR_ADD_RATE            NUMBER := 0;   
    V_RET_MON    NUMBER := 0;
BEGIN

    -- 임원 퇴직금 대상자
    FOR R_RT1010 IN (SELECT T1.*
                           ,T2.PAYROLL_TYPE
                       FROM RT1010# T1
                           ,PY0300 T2
                      WHERE T1.C_CD = I_C_CD
                        AND (I_EMP_ID IS NULL OR T1.EMP_ID = I_EMP_ID) -- 사번조건있는 경우..
                        AND NVL(T1.CONTI_Y_CNT7, 0) + NVL(T1.CONTI_Y_CNT1, 0) + NVL(T1.CONTI_Y_CNT2, 0) + NVL(T1.CONTI_Y_CNT3, 0) + NVL(T1.CONTI_Y_CNT4, 0) + NVL(T1.CONTI_Y_CNT5, 0) +
                            NVL(T1.CONTI_Y_CNT6, 0) > 0
                        AND ADJ_TYPE = '1'
                        AND T2.C_CD = T1.C_CD
                        AND T2.PAYROLL_NO = T1.PAYROLL_NO)
    LOOP
    
        I_PAYROLL_NO := R_RT1010.PAYROLL_NO;
    
    
        -- 임원 가산률 합 ( 총 가산률 )
        SELECT ROUND(SUM(OFR_ADD_RATE), 4)
          INTO V_OFR_ADD_RATE
          FROM (SELECT T1.POST_CD
                      ,ROUND(SUM(MONTHS_BETWEEN(TO_DATE(LEAST(T1.END_YMD, R_RT1010.END_YMD), 'YYYYMMDD') + 1, TO_DATE(GREATEST(T1.STA_YMD, R_RT1010.STA_YMD), 'YYYYMMDD')))) *
                       NVL(MAX(T2.OFR_ADD_RATE), 0) / 12 AS OFR_ADD_RATE
                  FROM PA1020 T1
                      ,RT0030 T2
                 WHERE T1.C_CD = I_C_CD
                   AND T1.EMP_ID = R_RT1010.EMP_ID
                   AND T1.LAST_YN = 'Y'
                   AND T1.STA_YMD <= R_RT1010.END_YMD
                   AND T1.END_YMD >= R_RT1010.STA_YMD
                   AND T2.C_CD(+) = T1.C_CD
                   AND T2.POST_CD(+) = T1.POST_CD
                   AND R_RT1010.ADJ_YMD BETWEEN T2.STA_YMD(+) AND T2.END_YMD(+)
                 GROUP BY T1.POST_CD);
                 
        IF NVL(V_OFR_ADD_RATE, 0) > 0 THEN DBMS_OUTPUT.PUT_LINE(F_GET_EMPNM(I_C_CD, R_RT1010.EMP_ID) || '('|| R_RT1010.EMP_ID || '),' || R_RT1010.PAYROLL_NO || ' ------------------------------');  END IF;
                                                 
        IF NVL(R_RT1010.CONTI_Y_CNT7, 0) > 0 THEN DBMS_OUTPUT.PUT_LINE('원래 : 상무보대우, ' || R_RT1010.PROM_YMD7 || ', ' || R_RT1010.CONTI_Y_CNT7 || '년'); END IF;
        IF NVL(R_RT1010.CONTI_Y_CNT1, 0) > 0 THEN DBMS_OUTPUT.PUT_LINE('원래 : 상무보, '     || R_RT1010.PROM_YMD1 || ', ' || R_RT1010.CONTI_Y_CNT1 || '년'); END IF;
        IF NVL(R_RT1010.CONTI_Y_CNT2, 0) > 0 THEN DBMS_OUTPUT.PUT_LINE('원래 : 상무, '       || R_RT1010.PROM_YMD2 || ', ' || R_RT1010.CONTI_Y_CNT2 || '년'); END IF;
        IF NVL(R_RT1010.CONTI_Y_CNT3, 0) > 0 THEN DBMS_OUTPUT.PUT_LINE('원래 : 전무, '       || R_RT1010.PROM_YMD3 || ', ' || R_RT1010.CONTI_Y_CNT3 || '년'); END IF;
        IF NVL(R_RT1010.CONTI_Y_CNT4, 0) > 0 THEN DBMS_OUTPUT.PUT_LINE('원래 : 부사장, '     || R_RT1010.PROM_YMD4 || ', ' || R_RT1010.CONTI_Y_CNT4 || '년'); END IF;
        IF NVL(R_RT1010.CONTI_Y_CNT5, 0) > 0 THEN DBMS_OUTPUT.PUT_LINE('원래 : 사장, '       || R_RT1010.PROM_YMD5 || ', ' || R_RT1010.CONTI_Y_CNT5 || '년'); END IF;
        IF NVL(R_RT1010.CONTI_Y_CNT6, 0) > 0 THEN DBMS_OUTPUT.PUT_LINE('원래 : 회장, '       || R_RT1010.PROM_YMD6 || ', ' || R_RT1010.CONTI_Y_CNT6 || '년'); END IF;

   
        -- 직위별 승진일, 비율을 저장..
        FOR CUR1 IN (SELECT T1.POST_CD
                           ,MIN(T1.STA_YMD) AS STA_YMD
                           ,ROUND(ROUND(SUM(MONTHS_BETWEEN(TO_DATE(LEAST(T1.END_YMD, R_RT1010.END_YMD), 'YYYYMMDD') + 1, TO_DATE(GREATEST(T1.STA_YMD, R_RT1010.STA_YMD), 'YYYYMMDD')))) / 12, 4) AS CONTI_Y_CNT   -- 직위년수 ex)2.5년
                           ,ROUND(SUM(MONTHS_BETWEEN(TO_DATE(LEAST(T1.END_YMD, R_RT1010.END_YMD), 'YYYYMMDD') + 1, TO_DATE(GREATEST(T1.STA_YMD, R_RT1010.STA_YMD), 'YYYYMMDD')))) AS CONTI_M_CNT   -- 직위월수 ex)30개월
                           ,ROUND(SUM(MONTHS_BETWEEN(TO_DATE(LEAST(T1.END_YMD, R_RT1010.END_YMD), 'YYYYMMDD') + 1, TO_DATE(GREATEST(T1.STA_YMD, R_RT1010.STA_YMD), 'YYYYMMDD')))) *
                            NVL(MAX(T2.OFR_ADD_RATE), 0) AS OF_ADD_M_CNT
                       FROM PA1020 T1
                           ,RT0030 T2
                      WHERE T1.C_CD = I_C_CD
                        AND T1.EMP_ID = R_RT1010.EMP_ID
                        AND T1.LAST_YN = 'Y'
                        AND T1.STA_YMD <= R_RT1010.END_YMD
                        AND T1.END_YMD >= R_RT1010.STA_YMD
                        AND T2.C_CD(+) = T1.C_CD
                        AND T2.POST_CD(+) = T1.POST_CD
                        AND R_RT1010.ADJ_YMD BETWEEN T2.STA_YMD(+) AND T2.END_YMD(+)
                      GROUP BY T1.POST_CD
                      ORDER BY T1.POST_CD DESC)
        LOOP
            IF CUR1.POST_CD IN ('09', '07') THEN
                --상무보, 이사
                UPDATE RT1010#
                   SET PROM_YMD1    = LEAST(NVL(PROM_YMD1, '99991231'), CUR1.STA_YMD)   --시작일은 먼저 시작한 일자
                      ,CONTI_Y_CNT1 = CUR1.CONTI_Y_CNT
                      ,CONTI_M_CNT1 = CUR1.CONTI_M_CNT
                 WHERE C_CD = I_C_CD
                   AND PAYROLL_NO = I_PAYROLL_NO
                   AND EMP_ID = R_RT1010.EMP_ID;
                   
                DBMS_OUTPUT.PUT_LINE('UPDATE : ' || F_GET_CODENM(I_C_CD, '/SY04', CUR1.POST_CD) || ', ' || SQL%ROWCOUNT || '건');
            ELSIF CUR1.POST_CD = '06' THEN
                --상무
                UPDATE RT1010#
                   SET PROM_YMD2    = CUR1.STA_YMD
                      ,CONTI_Y_CNT2 = CUR1.CONTI_Y_CNT
                      ,CONTI_M_CNT2 = CUR1.CONTI_M_CNT
                 WHERE C_CD = I_C_CD
                   AND PAYROLL_NO = I_PAYROLL_NO
                   AND EMP_ID = R_RT1010.EMP_ID;
                DBMS_OUTPUT.PUT_LINE('UPDATE : ' || F_GET_CODENM(I_C_CD, '/SY04', CUR1.POST_CD) || ', ' || SQL%ROWCOUNT || '건');
            ELSIF CUR1.POST_CD = '05' THEN
                --전무
                UPDATE RT1010#
                   SET PROM_YMD3    = CUR1.STA_YMD
                      ,CONTI_Y_CNT3 = CUR1.CONTI_Y_CNT
                      ,CONTI_M_CNT3 = CUR1.CONTI_M_CNT
                 WHERE C_CD = I_C_CD
                   AND PAYROLL_NO = I_PAYROLL_NO
                   AND EMP_ID = R_RT1010.EMP_ID;
                DBMS_OUTPUT.PUT_LINE('UPDATE : ' || F_GET_CODENM(I_C_CD, '/SY04', CUR1.POST_CD) || ', ' || SQL%ROWCOUNT || '건');
            ELSIF CUR1.POST_CD = '04' THEN
                --부사장
                UPDATE RT1010#
                   SET PROM_YMD4    = CUR1.STA_YMD
                      ,CONTI_Y_CNT4 = CUR1.CONTI_Y_CNT
                      ,CONTI_M_CNT4 = CUR1.CONTI_M_CNT
                 WHERE C_CD = I_C_CD
                   AND PAYROLL_NO = I_PAYROLL_NO
                   AND EMP_ID = R_RT1010.EMP_ID;
                DBMS_OUTPUT.PUT_LINE('UPDATE : ' || F_GET_CODENM(I_C_CD, '/SY04', CUR1.POST_CD) || ', ' || SQL%ROWCOUNT || '건');
            ELSIF CUR1.POST_CD = '03' THEN
                --사장
                UPDATE RT1010#
                   SET PROM_YMD5    = CUR1.STA_YMD
                      ,CONTI_Y_CNT5 = CUR1.CONTI_Y_CNT
                      ,CONTI_M_CNT5 = CUR1.CONTI_M_CNT
                 WHERE C_CD = I_C_CD
                   AND PAYROLL_NO = I_PAYROLL_NO
                   AND EMP_ID = R_RT1010.EMP_ID;
                DBMS_OUTPUT.PUT_LINE('UPDATE : ' || F_GET_CODENM(I_C_CD, '/SY04', CUR1.POST_CD) || ', ' || SQL%ROWCOUNT || '건');
            ELSIF CUR1.POST_CD = '10' THEN
                --상무보대우
                UPDATE RT1010#
                   SET PROM_YMD7    = CUR1.STA_YMD
                      ,CONTI_Y_CNT7 = CUR1.CONTI_Y_CNT
                      ,CONTI_M_CNT7 = CUR1.CONTI_M_CNT
                 WHERE C_CD = I_C_CD
                   AND PAYROLL_NO = I_PAYROLL_NO
                   AND EMP_ID = R_RT1010.EMP_ID;
                DBMS_OUTPUT.PUT_LINE('UPDATE : ' || F_GET_CODENM(I_C_CD, '/SY04', CUR1.POST_CD) || ', ' || SQL%ROWCOUNT || '건');
            END IF;
          
            DBMS_OUTPUT.PUT_LINE('신규 : ' || 
                                 F_GET_CODENM(I_C_CD, '/SY04', CUR1.POST_CD) || ', ' || 
                                 CUR1.STA_YMD || ', ' || 
                                 CUR1.CONTI_Y_CNT || '년, ' || 
                                 CUR1.CONTI_M_CNT || '개월 ') ;
        END LOOP;
        
        /*      
        -- 원래 산출값과 비교용으로 구해 봄
        R_RT1010.OFR_ADD_RATE := NVL(V_OFR_ADD_RATE, 0);
        */
        -- 퇴충금은 퇴직금 반올림, 퇴직금은 버림.
        IF R_RT1010.PAYROLL_TYPE = '92' THEN
          V_RET_MON := ROUND(R_RT1010.AVG_MON * (R_RT1010.PAY_RATE + R_RT1010.PROG_ADD_RATE + R_RT1010.OFR_ADD_RATE)) ;-- 퇴직금 = 평균임금 * (지급율 + 누진가산율 + 임원가산율)
        ELSE
          V_RET_MON := TRUNC(R_RT1010.AVG_MON * (R_RT1010.PAY_RATE + R_RT1010.PROG_ADD_RATE + R_RT1010.OFR_ADD_RATE)) ;-- 퇴직금 = 평균임금 * (지급율 + 누진가산율 + 임원가산율)
        END IF;
        
        
        DBMS_OUTPUT.PUT_LINE('원 가산률 : ' || R_RT1010.OFR_ADD_RATE || ', 신규 가산률 : ' || NVL(V_OFR_ADD_RATE, 0));
        DBMS_OUTPUT.PUT_LINE('원 퇴직금 : ' || R_RT1010.RET_MON || ', 신규 퇴직금 : ' || V_RET_MON);        
    
    END LOOP;

    O_ERRORCODE := '0';
EXCEPTION
    WHEN OTHERS THEN
        O_ERRORCODE := SQLCODE;
        O_ERRORMESG := SQLERRM;
END;
/
