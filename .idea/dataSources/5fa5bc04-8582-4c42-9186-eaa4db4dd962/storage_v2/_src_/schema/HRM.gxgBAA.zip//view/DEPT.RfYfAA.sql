CREATE VIEW DEPT AS SELECT T1.D_NO        , --         부서코드
T1.D_NAME_KO          , --       부서명
T1.D_NAME_KO_SHORT    , --             부서명약자
T1.D_NAME_EN          , --       부서명영문
T1.D_SORT             , --    부서순서
T1.D_USE              , --   부서사용여부
T1.T_NO               , --  팀코드
T1.T_NAME_KO          , --       팀명
T1.T_NAME_KO_SHORT    , --             팀명약자
T1.T_NAME_EN          , --       팀명영문
T1.T_SORT             , --    팀순서
T1.T_USE              , --   팀사용여부
T1.C_USE_DATE         , --        생성일
T1.C_USE_CURRENT      , --           현재사용여부
T1.C_PRODUCE_SUPPORT  , --             사업부/지원부서 구분
T1.WK_SITE            , --     근무지코드
T1.B_NO               , --  부문코드
T1.B_NAME_KO          , --       부문명
T1.B_NAME_KO_SHORT    , --             부문명약자
T1.B_NAME_EN          , --       부문명영문
T1.B_SORT             , --    부문순서
T1.B_USE              , --   부문사용여부
T1.G_NO               , --  본부코드
T1.G_NAME_KO          , --       본부명
T1.G_NAME_KO_SHORT    , --             본부명약자
T1.G_NAME_EN          , --       본부명영문
T1.G_SORT             , --    본부순서
T1.G_USE               --   본부사용여부
FROM OM0010_IF_VW T1
/
