CREATE VIEW PY1020_V_OVERSEA AS SELECT S1."C_CD",
          S1."EMP_ID",
          S1."STA_YMD",
          S1."SEQ_NO",
          S1."END_YMD",
          S1."DOC_NO",
          S1."APPNT_CD",
          S1."APPNT_NM",
          S1."APPNT_RSN_CD",
          S1."APPNT_RSN_NM",
          S1."STAT_CD",
          S1."BIZPL_CD",
          S1."ORG_ID",
          S1."ORG_NM",
          S1."ORG_ID2",
          S1."ORG_NM2",
          S1."EMP_TYPE",
          S1."EMP_TYPE_NM",
          S1."EMP_GRADE_CD",
          S1."EMP_GRADE_NM",
          S1."SAL_STEP_CD",
          S1."SAL_STEP_NM",
          S1."DUTY_CD",
          S1."DUTY_NM",
          S1."JOB_ID",
          S1."POST_CD",
          S1."EMP_TITLE_CD",
          S1."POSITION_ID",
          S1."DUP_ORG_ID",
          S1."DUP_ORG_NM",
          S1."DUP_ORG_ID2",
          S1."DUP_ORG_NM2",
          S1."DUP_DUTY_CD",
          S1."DUP_DUTY_NM",
          S1."DUP_JOB_ID",
          S1."DUP_POSITION_ID",
          S1."DISP_ORG_ID",
          S1."DISP_DUTY_CD",
          S1."DISP_JOB_ID",
          S1."DISP_POSITION_ID",
          S1."OUT_DISP_ASSO_CD",
          S1."OUT_ORG_NM",
          S1."EXPT_PROB_END_YMD",
          S1."EXPT_END_YMD",
          S1."DUTY_APP_YMD",
          S1."APP_GRADE",
          S1."LAST_YN",
          S1."POST_NM",
          S1."EMP_TITLE_NM",
          S1."SAL_TYPE",
          S1."DUP_END_ORG_ID",
          S1."APPLY_YMD",
          S1."PAY_AREA_CD",
          S1."ATTEND_AREA_CD",
          S1."WORK_LOC_CD",
          S1."NOTE",
          S1."INS_USER_ID",
          S1."INS_YMDHMS",
          S1."MOD_USER_ID",
          S1."MOD_YMDHMS",
          S1."WORK_LOC_ID",
          S1."SCH_END_YMD",
          S1."STAT_CLASS",
          S1."WORK_LOC_NM",
          S1."TMP_REST_RSN_CD",
          S1."BTRIP_CLASS",
          S1."NTNL_CD",
          S1."ROT_WORK_YN",
          S1."DUP_WORK_LOC_ID",
          S1."DUP_WORK_LOC_NM",
          S1."WORK_LOC_ID_LEG",
          S1."ORG_ID_LEG",
          S1."POST_CD2",
          S1."HD_COM_CD",
          S1."DUP_END_WORK_LOC_ID",
          S1."DUP_WORK_DUTY_CD",
          S1."APP_EXEC_YN",
          S1."APP_EXEC_UPDATE_YN",
          S1."APP_EXEC_MAIL_YN",
          S1."SEL_STEP_CD",
          S1."OLD_JOB_ID",
          S1."PROB_END_YMD",
          S1."REMARK",
          NVL (S1.ASSIGN_STA_YMD, S1.STA_YMD) AS ASSIGN_STA_YMD,
          (SELECT NVL (
                     MIN (
                        CASE
                           WHEN S2.APPNT_CD = '23'
                           THEN
                              STA_YMD
                           ELSE
                              TO_CHAR (TO_DATE (STA_YMD, 'YYYYMMDD') - 1,
                                       'YYYYMMDD')
                        END),
                     '99991231')
             FROM PA1020 S2
            WHERE     S2.C_CD = S1.C_CD
                  AND S2.EMP_ID = S1.EMP_ID
                  AND S2.APPNT_CD IN ('22',
                                      '23',
                                      '03',
                                      '04',
                                      '20',
                                      '21',
                                      '69')      -- 해외현장복귀, 퇴사, 국내현장부임 ,국내현장전임
                  AND S2.STA_YMD > S1.STA_YMD
                  AND S2.ROWID <> S1.ROWID)
             AS SCH_END_YMD2
     FROM PA1020 S1
    WHERE     (   S1.APPNT_CD IN ('20', '21')
               OR (    S1.APPNT_CD = '69'
                   AND F_WORK_LOC_CD_NM (S1.C_CD,
                                         S1.WORK_LOC_ID,
                                         S1.STA_YMD,
                                         '1') IN ('3', '4', '6'))) -- 근무지별 구간을 구하기 위해서
          -- 같은날 중복발령이 난 경우를 피하기 위해서
          AND S1.SEQ_NO =
                 (SELECT MAX (S2.SEQ_NO)
                    FROM PA1020 S2
                   WHERE     S2.C_CD = S1.C_CD
                         AND S2.EMP_ID = S1.EMP_ID
                         AND S2.STA_YMD = S1.STA_YMD
                         AND (   S2.APPNT_CD IN ('20', '21')
                              OR (    S2.APPNT_CD = '69'
                                  AND F_WORK_LOC_CD_NM (S2.C_CD,
                                                        S2.WORK_LOC_ID,
                                                        S2.STA_YMD,
                                                        '1') IN ('3',
                                                                 '4',
                                                                 '6'))))
/
