CREATE VIEW EMP_ITSM AS SELECT   T1.EMP_ID,                                           -- 사번 9자리
            SUBSTR (T1.EMP_ID, 3, 7) EMP_ID7,                     --사번 7자리
            --      T1.C_CD,
            --      T2.STA_YMD,
            --      T2.APPNT_CD,
            T2.ORG_ID,                                               -- 조직ID
            T2.WORK_LOC_ID,                                        -- 근무지ID
            T1.EMP_NM,                                              --한글이름
            T1.ENG_EMP_NM,                                          --영문이름
            T1.CHA_EMP_NM,                                          --한자이름
            T2.POST_CD2 AS POST_CD,                                              --직위ID
            F_GET_CODENM (T2.C_CD, '00100', T2.POST_CD2) HECOS_POST_NM, --직위명(HECOS용)
            T2.DUTY_CD,                      --직책코드 ( 대표이사, 부문장 ..)
            T1.MAIL_ADDR,                                             --이메일
            T1.MOBILE_NO,                                           --휴대전화
            -- T1.LOC_CD WORK_LOCATION,                      --근무위치
            -- F_GET_CODENM (T1.C_CD, '00090', T1.LOC_CD) WORK_LOCATION_NM,   --근무위치
            T1.WORK_PLACE_NM WORK_LOCATION,
            F_GET_CODENM (T1.C_CD, '00090', t1.WORK_PLACE_NM)
               WORK_LOCATION_NM,
            T1.WORK_LOC_TEL_NO,                                   --사무실전화
            F_GET_OBJ_STA_YMD2 ('HEC',
                                T1.EMP_ID,
                                'O',
                                T2.ORG_ID,
                                TO_CHAR (SYSDATE, 'YYYYMMDD'))
               ORG_YMD,                                        -- 원소속발령일
            F_GET_OBJ_STA_YMD2 ('HEC',
                                T1.EMP_ID,
                                'WA',
                                T2.WORK_LOC_ID,
                                TO_CHAR (SYSDATE, 'YYYYMMDD'))
               WKSITE_YMD,                                     -- 근무지발령일
            CASE
               -- WHEN T2.EMP_TYPE IN ('A', 'B', 'C', 'D', 'G') THEN '직원'
               -- 2013.12.31 PJT가 제외되어 있어 추가함.
            WHEN T2.EMP_TYPE IN ('A', 'B', 'C', 'D', 'G', 'I') THEN '직원'
               ELSE '외주'
            END
               EMP_KIND                                            -- 직원종류
     FROM   PA1010# T1, PA1020 T2, PA2010 T3
    --            ,       PA2261 T4
    WHERE   T1.C_CD = 'HEC' AND T2.C_CD = T1.C_CD AND T2.EMP_ID = T1.EMP_ID
            --            AND T1.EMP_ID NOT IN ('201303628')
            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                  AND  T2.END_YMD
            AND T2.LAST_YN = 'Y'
            AND T2.STAT_CD LIKE '1%'
            AND T3.C_CD(+) = T1.C_CD
            AND T3.EMP_ID(+) = T1.EMP_ID
            AND T3.ADDR_CD(+) = '003'
--            AND T4.C_CD = T1.C_CD
--            AND T4.EMP_ID = T1.EMP_ID
--            AND T4.USE_SYS = '002'
--            AND 1 =
--                  (CASE
--                      WHEN T2.EMP_ID LIKE '%C'
--                      THEN
--                         1                                  -- 전자조달 사용자
--                      WHEN t2.EMP_ID IN ('201209028')
--                      THEN
--                         1
--                      -- 자버 사원(1209028) UC, HECOS, 이메일 사용 가능  서이준 사원 2012/08/22
--                      -- 이윤희 사원(1211448) HECOS 사용 가능. 서이준 사원 2012/10/11
--                   WHEN t2.EMP_ID IN
--                              ('200200098',
--                               '201115438',
--                               '199905739',
--                               '200905558',
--                               '200905568',
--                               '201210378', --인사팀 이승미 사원 요청으로  2013/01/09
--                               '201211448',
--                               '201304238',
--                               '201303628' -- 김찬미 인사팀 방진주 사원 요청 2013/01/28
--                                          )
--                      THEN
--                         1-- 정일룡, 조남규 수리실 김성일 과장 복사실, 김도형, 김변호 통신실  예외로 처리 (헤코스 O, 결재 O) 김장호 대리 2012/08/02
--                      WHEN t2.EMP_ID IN
--                                 ('201205698',
--                                  '201120998',
--                                  '201119968',
--                                  '201204098',
--                                  '201204078',
--                                  '201204068',
--                                  '201204938',
--                                  '201204058',
--                                  '201209918')
--                      THEN
--                         1
--                      -- 김민지, 서미애 드림투어 담당이라 예외로 처리 (헤코스 O, 결재 X) 김장호 대리 2012/08/02
--                      -- 추명희(201119968) 인프라 서비스라운지 담당자 예외로 처리 (헤코스 O, 결재 X) 김장호 대리 2012/08/06
--                      -- '201204098', '201204078', '201204068', '201204938', '201204058' '임시태', '박성군', '이성철', '나승욱', '유종익' 감사실직원 예외 처리 (헤코스 O, 메일 O, 결재 X) 김장호 대리 2012/08/08
--                      --  '201209918' 추가(헤코스 O, 결재 O) . 서이준 사원 2012.09.21
--                   WHEN T2.EMP_ID IN ('201212888', '201212878', '201212898')
--                      THEN
--                         1-- 전진홍(201212898), 최광윤(201212878), 이하영(201212888) 모의해킹용 관리자 및 사용자 계정추가. 허강녕 과장 2012/08/02
--                      WHEN T2.EMP_ID IN ('201302288', '201302298')
--                      THEN
--                         1 -- 황희수, 김종회 현대건설 전출자 HECOS 사용자 계정추가. 최정환 과장 2013/01/02
--                      WHEN T2.EMP_TYPE IN ('8', 'O', '8H')
--                           AND T2.POST_CD NOT LIKE '3%'
--                      THEN
--                         0
--                      ELSE
--                         1
--                   END)
--            AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T4.STA_YMD
--                                                  AND  T4.END_YMD;;;; 
/
COMMENT ON VIEW EMP_ITSM IS '[ITSM_IF용] (EMP_ITSM)인사정보'
/
