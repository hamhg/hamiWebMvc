CREATE PROCEDURE     P_BE_LOAN_APPLY_PAYROLL(
  I_C_CD IN VARCHAR2,
  I_PAYROLL_NO IN VARCHAR2,
  I_PAY_AREA_CD IN VARCHAR2,
  I_EMP_ID IN VARCHAR2,
  I_MOD_USER_ID IN VARCHAR2,
  O_EXEC_CNT OUT NUMBER,
  O_ERRORCODE OUT VARCHAR2,
  O_ERRORMESG OUT VARCHAR2
)
IS
/***********************************************************************
 Program Name   : P_BE_LOAN_APPLY_PAYROLL
 Description    : 대출상환금액 급여반영.
 Author         : 박영규
 History        : 2007-11-22
***********************************************************************/
R_PY0300 PY0300%ROWTYPE;
TO_YMD VARCHAR2(8) := TO_CHAR(SYSDATE, 'YYYYMMDD');
V_REFUND_MON NUMBER;
V_INTER_MON NUMBER;
BEGIN

  SELECT *
    INTO R_PY0300
    FROM PY0300
   WHERE C_CD = I_C_CD
     AND PAYROLL_NO = I_PAYROLL_NO;

  IF R_PY0300.CLOSE_YN = 'Y' THEN
    RAISE_APPLICATION_ERROR(-20000, '급여가 마감되어 처리할 수 없습니다.');
  END IF;
/*
  PY1010--개인급여기본
  SY7010--신청서마스터
  BEL220--대출
  BEL240--상환일정
  BEL010--대부기준
  PY2030--급여일회성예외
*/

  O_EXEC_CNT := 0;
  -- 대출상환일정에서 상환안한것중 급여일보다 작은걸 골라서 급여번호세팅
  FOR CUR1 IN (
    SELECT T3.EMP_ID,
           T3.DATA_ID,
           T4.REFUND_PAYITEM,
           T4.INTER_PAYITEM
      FROM GAIS.BEL220# T3,
           GAIS.BEL010 T4
     WHERE T3.C_CD = I_C_CD
       AND T3.EMP_ID LIKE NVL(I_EMP_ID, '%')
       AND T3.LOAN_END_YN = 'N'
       AND T4.C_CD = T3.C_CD
       AND T4.LOAN_CD = T3.LOAN_CD
       AND F_GET_PAY_AREA_CD(T3.C_CD, T3.EMP_ID, R_PY0300.PAYROLL_YMD) = R_PY0300.PAY_AREA_CD
  ) LOOP

    -- 급여번호세팅
    UPDATE GAIS.BEL240
       SET PAYROLL_NO = I_PAYROLL_NO,
           MOD_USER_ID = I_MOD_USER_ID,
           MOD_YMDHMS = SYSDATE
     WHERE C_CD = I_C_CD
       AND DATA_ID = CUR1.DATA_ID
       AND REFUND_YMD <= R_PY0300.PAYROLL_YMD
       AND REFUND_YN = 'N';

/*절대불가
    -- 급여예외사항 삭제(초기화)
    DELETE
      FROM PY2030
     WHERE C_CD = I_C_CD
       AND EMP_ID = CUR1.EMP_ID
       AND PAYROLL_NO = I_PAYROLL_NO
       AND PAYITEM IN (CUR1.REFUND_PAYITEM, CUR1.INTER_PAYITEM);
*/


    SELECT NVL(SUM(REFUND_MON), 0),
           NVL(SUM(INTER_MON), 0)
      INTO V_REFUND_MON,
           V_INTER_MON
      FROM GAIS.BEL240
     WHERE C_CD = I_C_CD
       AND DATA_ID = CUR1.DATA_ID
       AND PAYROLL_NO = I_PAYROLL_NO
       AND REFUND_YN = 'N';

    IF V_REFUND_MON > 0 THEN

      UPDATE PY2030
         SET MON = MON + V_REFUND_MON,
             MOD_USER_ID = I_MOD_USER_ID,
             MOD_YMDHMS = SYSDATE
       WHERE C_CD = I_C_CD
         AND EMP_ID = CUR1.EMP_ID
         AND PAYROLL_NO = I_PAYROLL_NO
         AND PAYITEM = CUR1.REFUND_PAYITEM;

      IF SQL%ROWCOUNT = 0 THEN

        INSERT INTO PY2030
        (
          C_CD,
          EMP_ID,
          PAYROLL_NO,
          PAYITEM,
          SEQ_NO,
          --RATE,
          MON,
          CURRENCY_CD,
          NOTE,
          MOD_USER_ID,
          MOD_YMDHMS,
INS_USER_ID,
INS_YMDHMS
        )
        VALUES
        (
          I_C_CD,
          CUR1.EMP_ID,
          I_PAYROLL_NO,
          CUR1.REFUND_PAYITEM,
          1,
          --0,
          V_REFUND_MON,
          NULL,
          NULL,
          I_MOD_USER_ID,
          SYSDATE,
          I_MOD_USER_ID,
          SYSDATE
        );
      END IF;

    END IF;

    IF V_INTER_MON > 0 THEN

      UPDATE PY2030
         SET MON = MON + V_INTER_MON,
             MOD_USER_ID = I_MOD_USER_ID,
             MOD_YMDHMS = SYSDATE
       WHERE C_CD = I_C_CD
         AND EMP_ID = CUR1.EMP_ID
         AND PAYROLL_NO = I_PAYROLL_NO
         AND PAYITEM = CUR1.INTER_PAYITEM;

      IF SQL%ROWCOUNT = 0 THEN

        INSERT INTO PY2030
        (
          C_CD,
          EMP_ID,
          PAYROLL_NO,
          PAYITEM,
          SEQ_NO,
          --RATE,
          MON,
          CURRENCY_CD,
          NOTE,
          MOD_USER_ID,
          MOD_YMDHMS,
INS_USER_ID,
INS_YMDHMS
        )
        VALUES
        (
          I_C_CD,
          CUR1.EMP_ID,
          I_PAYROLL_NO,
          CUR1.INTER_PAYITEM,
          1,
          --0,
          V_INTER_MON,
          NULL,
          NULL,
          I_MOD_USER_ID,
          SYSDATE,
          I_MOD_USER_ID,
          SYSDATE
        );
      END IF;

    END IF;

    -- 상환여부 Y 업데이트
    UPDATE GAIS.BEL240
       SET REFUND_YN = 'Y',
           REFUND_TYPE = '100',-- 급여상환
           MOD_USER_ID = I_MOD_USER_ID,
           MOD_YMDHMS = SYSDATE
     WHERE C_CD = I_C_CD
       AND DATA_ID = CUR1.DATA_ID
       AND PAYROLL_NO = I_PAYROLL_NO
       AND REFUND_YN = 'N';

    GAIS.P_BE_LOAN_UPDATE_MASTER(I_C_CD, CUR1.DATA_ID, I_MOD_USER_ID, O_ERRORCODE, O_ERRORMESG);
    IF O_ERRORCODE <> '0' THEN
      O_ERRORCODE := -20000;
      O_ERRORMESG := '대출마스터 업데이트 오류: '||O_ERRORMESG;
      RETURN;
    END IF;

    O_EXEC_CNT := O_EXEC_CNT + 1;

  END LOOP;

  O_ERRORCODE := 0;
  O_ERRORMESG := '';
EXCEPTION
  WHEN OTHERS
  THEN
    O_ERRORCODE := SQLCODE;
    O_ERRORMESG := SQLERRM;
END;
/
