CREATE VIEW EMP_HECOS_ADDITIONAL_POS AS SELECT   A.EMP_ID,
            A.EMP_ID7,
            A.ORG_ID1,
            A.ORG_ID2,
            A.ORG_ID3,
            A.ORG_NM1,
            A.ORG_NM2,
            A.ORG_NM3,
            B.SMR_OBJ_NM SMR_ORG_NM1,
            C.SMR_OBJ_NM SMR_ORG_NM2,
            D.SMR_OBJ_NM SMR_ORG_NM3,
            A.EMP_NM,
            A.ENG_EMP_NM,
            A.CHA_EMP_NM,
            A.POST_CD,
            A.POST_NM,
            A.HECOS_POST_NM,
            CAST (A.HECOS_POST_NO AS INT),
            A.ENG_POST_NM,
            A.DUTY_CD,
            A.DUTY_NM,
            A.MAIL_ADDR,
            A.PER_NO,
            A.EMP_TYPE,
            A.EMP_TYPE_NM,
            A.ENTER_YMD,
            A.ZIP_NO,
            A.ADDR,
            A.TEL_NO,
            A.MOBILE_NO,
            A.WORK_LOCATION,
            A.WORK_LOCATION_NM,
            A.WORK_LOC_TEL_NO,
            A.WORK_LOC_FAX,
            A.PHOTO_PATH,
            F_GET_JOB_DESC (A.C_CD, A.EMP_ID, TO_CHAR (SYSDATE, 'YYYYMMDD'))
               JOB_NM,
            F.ALTERNATE_KEY                                      --대체KEY추가
     FROM   (SELECT   T1.EMP_ID,                                 -- 사번 9자리
                      T1.C_CD,
                      T2.STA_YMD,
                      T2.APPNT_CD,
                      t2.org_id,
                      SUBSTR (T1.EMP_ID, 3, 7) EMP_ID7,           --사번 7자리
                      F_ORG_NM (
                         T2.C_CD,
                         DECODE (T2.APPNT_CD,
                                 '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                                 T2.STA_YMD)                      --,T2.ORG_ID
                                            ,
                         T2.DUP_ORG_ID,
                         '6'
                      )
                         ORG_ID1,                                    --본부 ID
                      F_ORG_NM (
                         T2.C_CD,
                         DECODE (T2.APPNT_CD,
                                 '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                                 T2.STA_YMD)                      --,T2.ORG_ID
                                            ,
                         T2.DUP_ORG_ID,
                         '7'
                      )
                         ORG_ID2,                                    --부문 ID
                      CASE
                         WHEN SUBSTR (                             --T2.ORG_ID
                                      T2.DUP_ORG_ID, 1, 2) = 'OE'
                         THEN
                            T2.DUP_ORG_ID                          --T2.ORG_ID
                         ELSE
                            F_ORG_NM (
                               T2.C_CD,
                               DECODE (T2.APPNT_CD,
                                       '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                                       T2.STA_YMD)                --,T2.ORG_ID
                                                  ,
                               T2.DUP_ORG_ID,
                               '8'
                            )
                      END
                         ORG_ID3                                     --부서 ID
                                ,
                      F_ORG_NM (
                         T2.C_CD,
                         DECODE (T2.APPNT_CD,
                                 '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                                 T2.STA_YMD)                      --,T2.ORG_ID
                                            ,
                         T2.DUP_ORG_ID,
                         '1'
                      )
                         ORG_NM1                                      --본부명
                                ,
                      F_ORG_NM (
                         T2.C_CD,
                         DECODE (T2.APPNT_CD,
                                 '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                                 T2.STA_YMD)                      --,T2.ORG_ID
                                            ,
                         T2.DUP_ORG_ID,
                         '2'
                      )
                         ORG_NM2                                      --부문명
                                ,
                      CASE
                         WHEN SUBSTR (                            -- T2.ORG_ID
                                      T2.DUP_ORG_ID, 1, 2) = 'OE'
                         THEN
                            F_GET_OBJNM (
                               T2.C_CD,
                               'OE',
                               --T2.ORG_ID,
                               T2.DUP_ORG_ID,
                               DECODE (T2.APPNT_CD,
                                       '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                                       T2.STA_YMD)
                            )
                         ELSE
                            F_ORG_NM (
                               T2.C_CD,
                               DECODE (T2.APPNT_CD,
                                       '60', F_ADD_YMD (T2.STA_YMD, 'D', -1),
                                       T2.STA_YMD),
                               --T2.ORG_ID,
                               T2.DUP_ORG_ID,
                               '3'
                            )
                      END
                         ORG_NM3,                                     --부서명
                      T1.EMP_NM,                                    --한글이름
                      T1.ENG_EMP_NM,                                --영문이름
                      T1.CHA_EMP_NM,                                --한자이름
                      T2.POST_CD,                                     --직위ID
                      F_GET_CODENM (T2.C_CD, '/SY04', T2.POST_CD) POST_NM, --직위명
                      (SELECT   ENG_NM
                         FROM   SY5020
                        WHERE       C_CD = T2.C_CD
                                AND IDX_CD = '/SY04'
                                AND CD = T2.POST_CD)
                         ENG_POST_NM,                           --직위명(영문)
                      F_GET_CODENM (T2.C_CD, '00100', T2.POST_CD2)
                         HECOS_POST_NM,                      --직위명(HECOS용)
                      (SELECT   DP_ORDER
                         FROM   SY5020
                        WHERE       C_CD = T2.C_CD
                                AND IDX_CD = '00100'
                                AND CD = T2.POST_CD2)
                         HECOS_POST_NO,
                      T2.DUP_DUTY_CD DUTY_CD, --직책코드 ( 대표이사, 부문장 ..)
                      F_GET_CODENM (T2.C_CD, '/SY05', T2.DUP_DUTY_CD) DUTY_NM, --직책명
                      T1.MAIL_ADDR,                                   --이메일
                      NULL AS PER_NO,--주민번호. 개인정보 연동 제거 목적으로 HECOS와 협의후 NULL로 리턴(추후 HECOS측 프로그램 수정후 컬럼 완전 제거 가능) 2013.12.26
                      T1.EMP_TYPE,                  --직원유형 (정직, 외주 등)
                      F_GET_CODENM (T2.C_CD, '/SY01', T2.EMP_TYPE)
                         EMP_TYPE_NM,                             --직원구분명
                      T1.ENTER_YMD,                                   --입사일
                      T3.ZIP_NO,                                    --우편번호
                      T3.ADDR || T3.DTL_ADDR ADDR,                    --집주소
                      T1.TEL_NO,                                      --집전화
                      T1.MOBILE_NO,                                 --휴대전화
                      -- T1.LOC_CD WORK_LOCATION,                      --근무위치
                      -- F_GET_CODENM (T1.C_CD, '00090', T1.LOC_CD) WORK_LOCATION_NM,   --근무위치
                      T1.WORK_PLACE_NM WORK_LOCATION,
                      F_GET_CODENM (T1.C_CD, '00090', t1.WORK_PLACE_NM)
                         WORK_LOCATION_NM,
                      T1.WORK_LOC_TEL_NO,                         --사무실전화
                      T1.WORK_LOC_FAX,                            --사무실 FAX
                      T1.PHOTO_PATH                              -- 사진 경로.
               --T1.WELFARE_CARD_YN --복지카드 발급유무
               FROM   PA1010# T1,
                      PA1020 T2,
                      PA2010 T3,
                      PA2261 T4
              WHERE       T1.C_CD = 'HEC'
                      AND T2.C_CD = T1.C_CD
                      AND T2.EMP_ID = T1.EMP_ID
                      AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD
                                                            AND  T2.END_YMD
                      --AND T2.LAST_YN = 'Y'
                      AND T2.STAT_CD LIKE '1%'
                      AND T3.C_CD(+) = T1.C_CD
                      AND T3.EMP_ID(+) = T1.EMP_ID
                      AND T3.ADDR_CD(+) = '003'
                      AND T4.C_CD = T1.C_CD
                      AND T4.EMP_ID = T1.EMP_ID
                      AND T4.USE_SYS = '002'
                      AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T4.STA_YMD
                                                            AND  T4.END_YMD
                      AND T2.APPNT_CD = '08'                           -- 겸직
                                            ) A,
            SY3010 B,
            SY3010 C,
            SY3010 D,
            -- 대체KEY추가
            (SELECT   *
               FROM   (SELECT   RANK ()
                                   OVER (
                                      PARTITION BY EMP_ID
                                      ORDER BY
                                         ins_ymdhms DESC,
                                         mod_ymdhms DESC,
                                         seq_no DESC
                                   )
                                   AS rk,
                                F.*
                         FROM   PA9080# F) FF
              WHERE   FF.RK = 1) F
    WHERE       B.C_CD(+) = A.C_CD
            -- 대체KEY 추가
            AND A.EMP_ID = F.EMP_ID(+)
            AND B.OBJ_TYPE(+) LIKE 'O%'
            AND B.OBJ_ID(+) = A.ORG_ID1
            AND DECODE (A.APPNT_CD,
                        '60', F_ADD_YMD (A.STA_YMD, 'D', -1),
                        A.STA_YMD) BETWEEN B.STA_YMD(+)
                                       AND  B.END_YMD(+)
            AND C.C_CD(+) = A.C_CD
            AND C.OBJ_TYPE(+) LIKE 'O%'
            AND C.OBJ_ID(+) = A.ORG_ID2
            AND DECODE (A.APPNT_CD,
                        '60', F_ADD_YMD (A.STA_YMD, 'D', -1),
                        A.STA_YMD) BETWEEN C.STA_YMD(+)
                                       AND  C.END_YMD(+)
            AND D.C_CD(+) = A.C_CD
            AND D.OBJ_TYPE(+) LIKE 'O%'
            AND D.OBJ_ID(+) = A.ORG_ID3
            AND DECODE (A.APPNT_CD,
                        '60', F_ADD_YMD (A.STA_YMD, 'D', -1),
                        A.STA_YMD) BETWEEN D.STA_YMD(+)
                                       AND  D.END_YMD(+)
/
COMMENT ON VIEW EMP_HECOS_ADDITIONAL_POS IS '[IM/HECOS/DRM_IF용] (EMP_HECOS_ADDITIONAL_POS)인사정보'
/
