CREATE VIEW INSAKYUMJIKTBL AS SELECT   'HE' CompanyCD,
            'ko' LangCD,
            a.emp_id Sabun,
            SUBSTR (a.emp_id, 3, 7) UserID,
            b.emp_nm KName,
            b.eng_emp_nm EName,
            c.post_cd JikwiCD,
            c.post_nm JikwiNM,
            d.eng_nm EJikwiNM,
            NULL SJikwiNM,
            a.org_id BusoCD,
            f_org_nm (a.c_cd,
                      a.sta_ymd,
                      a.org_id,
                      '4')
               BusoNM,
            f_org_eng_nm (c.c_cd,
                          c.sta_ymd,
                          c.org_id,
                          '4')
               EBusoNM,
            NULL SBusoNM,
            a.duty_cd SitePos,
            f_get_codenm (a.c_cd, '/SY05', a.duty_cd) SitePos_NM,
            NULL ESitePos_NM,
            NULL SSitePos_NM,
            NULL GUB,
            f_org_id (a.c_cd,
                      a.sta_ymd,
                      a.org_id,
                      '1')
               SA,
            f_org_nm (a.c_cd,
                      a.sta_ymd,
                      a.org_id,
                      '1')
               SA_NUM,
            NULL GYM,
            SYSDATE RegDate
     FROM   om0020 a,
            pa1010# b,
            pa1020 c,
            (SELECT   cd, cd_nm, eng_nm
               FROM   sy5020
              WHERE   idx_cd = '/SY04') d
    WHERE       a.mgr_class = '20'
            AND SYSDATE BETWEEN a.sta_ymd AND a.end_ymd
            AND a.emp_id = b.emp_id
            AND a.emp_id = c.emp_id
            AND SYSDATE BETWEEN c.sta_ymd AND c.end_ymd
            AND c.stat_cd LIKE '1%'
            AND c.last_yn = 'Y'
            AND c.post_cd = d.cd
/
COMMENT ON VIEW INSAKYUMJIKTBL IS '[IM_IF용] (INSAKYUMJIKTBL)겸직자정보'
/
