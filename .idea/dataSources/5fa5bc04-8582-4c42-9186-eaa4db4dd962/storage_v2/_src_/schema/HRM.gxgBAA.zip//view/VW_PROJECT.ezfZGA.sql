CREATE VIEW VW_PROJECT AS select ProjectCD, ProjectNM, ContractNM, BusinessCL, MainDivisionCD
    from erp.project    
    union all
    select ProjectCD, EducationNM, EducationNM, EducationCL, MainDivisionCD
    from erp.education
/
