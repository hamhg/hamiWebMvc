CREATE VIEW CHECK_OPTION AS select c_cd,
                     evu_std_id,
                     EMP_EVU_ID,
                     emp_id,
                     comp_last_score,
                     pm_last_score,
                     rank_no,
                     EVU_T_GRP_CD,
                     total_count,
                     round(rank_no/total_count,2)*100 bi_rate
            from  (
                        select c_cd,
                                 evu_std_id,
                                 EMP_EVU_ID,
                                 emp_id,
                                 comp_last_score,
                                 pm_last_score,
                                 EVU_T_GRP_CD,
                                 rank() over(order by pm_last_score) as rank_no,
                                 (select count(t2.C_CD) from pm2130 T2 where t2.C_CD = 'HEC' and t2.evu_std_id = '201006160001' and    t2.use_yn = 'Y') total_count
                        from  pm2130
                        where c_cd='HEC'
                        and    evu_std_id = '201006160001'
                        and    use_yn = 'Y'
                        and    rownum >0
                        ) 
          ORDER BY EMP_EVU_ID
/
