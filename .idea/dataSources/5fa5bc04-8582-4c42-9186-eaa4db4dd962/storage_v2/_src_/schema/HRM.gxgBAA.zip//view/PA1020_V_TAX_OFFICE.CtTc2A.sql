CREATE VIEW PA1020_V_TAX_OFFICE AS SELECT T1.C_CD,
          T1.EMP_ID,
          T1.ORG_ID,
          T1.ORG_NM,
          T1.STA_YMD,
          T1.END_YMD,
          T2.BIZPL_CD,
          T2.BIZPL_NM,
          T2.RST_EMP_ID,
          T2.MAIN_YN,
          T2.RST_NM,
          T2.BIZ_NO,
          T5.SINS_BIZPL_CD,
          T4.TEL_NO,
          T4.LOC_CD,
          T4.ZIP_NO,
          T4.ADDR,
          T4.DTL_ADDR,
          T4.ENG_ADDR,
          T3.TAX_OFFI_CD,
          T3.TAX_OFFI_NM,
          T3.LOC_CD,
          T3.ZIP_NO,
          T3.ADDR,
          T3.DTL_ADDR
     FROM PA1020 T1,
          SY5060 T2,
          SY5070# T3,
          SY5130 T4,
          SY5050 T5
    WHERE     T1.C_CD = T2.C_CD
          AND T1.C_CD = T3.C_CD
          AND T1.STAT_CD IN ('10', '20', '30')
          AND T1.LAST_YN = 'Y'
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD AND T1.END_YMD
          AND T1.BIZPL_CD = T2.BIZPL_CD
          AND T2.USE_YN = 'Y'
          AND T2.C_CD = T3.C_CD
          AND T2.TAX_OFFI_CD = T3.TAX_OFFI_CD
          AND T4.C_CD = T2.C_CD
          AND T4.LOC_CD = T2.LOC_CD
          AND T4.C_CD = T5.C_CD
          AND T4.LOC_CD = T5.LOC_CD
          AND T2.MAIN_YN = 'Y'
/
