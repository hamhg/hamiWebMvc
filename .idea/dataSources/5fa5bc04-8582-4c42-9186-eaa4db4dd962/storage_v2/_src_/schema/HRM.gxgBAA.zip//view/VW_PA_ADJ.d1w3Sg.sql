CREATE VIEW VW_PA_ADJ AS SELECT   T2.C_CD,
            T2.C_CD AS CP_CD,
            NULL AS ADJ_YY,
            T2.EMP_ID,
            T2.EMP_ID AS EMP_UID,
            T2.EMP_NM,
            NVL (T3.BIZPL_CD, T2.BIZPL_CD) AS BIZPL_CD,
            T2.BIRTH_YMD,
            T2.ENTER_YMD,
            T2.GRP_YMD,
            NVL(T2.RETIRE_YMD,(SELECT NVL(MAX(RETIRE_YMD),'') FROM PY8010 WHERE C_CD = T2.C_CD AND EMP_ID = T2.EMP_ID AND HOLD_TYPE IN ('09','05','02','03'))) AS RETIRE_YMD,
            T2.EXPT_PROB_END_YMD,
            T2.ATTEND_STA_YMD,
            NVL (T2.RET_STA_YMD, T2.GRP_YMD) AS RET_STA_YMD,
            T2.LAST_MOVE_YMD,
            T2.LAST_PROM_YMD,
            T2.SAL_STEP_YMD                            --,T2.NEXT_SAL_STEP_YMD
                           --,T2.OFR_STA_YMD
            ,
            T2.GENDER_TYPE,
            T2.MAIL_ADDR,
            T2.PER_NO,
            T2.OFFICE_TEL_NO,
            T2.TEL_NO,
            T2.MOBILE_NO,
            T3.ORG_ID AS OG_ORG_ID,
            NVL (T9.ORG_ID, T3.ORG_ID) AS ORG_ID,
            NVL (T7.OBJ_NM, T3.ORG_NM) AS ORG_NM                 --,T3.ORG_ID2
                                                ,
            T3.EMP_TYPE,
            T3.EMP_GRADE_CD,
            T6.CD_NM AS EMP_GRADE_NM,
            T3.SAL_TYPE,
            T3.SAL_STEP_CD,
            T3.DUTY_CD,
            T5.CD_NM AS DUTY_NM                                   --,T3.JOB_ID
                               ,
            T3.POST_CD,
            T4.CD_NM AS POST_NM,
            T3.EMP_TITLE_CD                                  --,T3.POSITION_ID
                           ,
            T3.DUP_ORG_ID,
            T3.DUP_DUTY_CD                                    --,T3.DUP_JOB_ID
                          --,T3.DUP_POSITION_ID
            ,
            T3.DISP_ORG_ID,
            T3.DISP_DUTY_CD                                  --,T3.DISP_JOB_ID
                           --,T3.DISP_POSITION_ID
                           --,T3.OUT_DISP_ASSO_CD
            ,
            T3.STAT_CD,
            T3.STA_YMD,
            T3.END_YMD                                      --,T3.APPNT_RSN_CD
                      ,
            T3.NOTE,
            T3.APPNT_CD,
            T3.ATTEND_AREA_CD,
            T3.PAY_AREA_CD,
            T3.WORK_LOC_CD,
            '' AS TAX_LOC_CD,
            T2.NTNL_CD,
            T2.MARRY_YN
     FROM   PA1010# T2,                               --#(HEC주석)VW_PA1010 T2
            PA1020 T3,                                --#(HEC주석)VW_PA1020 T3
            (SELECT   T1.C_CD,
                      T1.CD,
                      T1.CD_NM,
                      T1.DP_ORDER
               FROM   SY5020 T1                       --#(HEC주석)VW_SY5020 T1
              WHERE   T1.IDX_CD = '/SY04') T4,
            (SELECT   T1.C_CD,
                      T1.CD,
                      T1.CD_NM,
                      T1.DP_ORDER
               FROM   SY5020 T1                       --#(HEC주석)VW_SY5020 T1
              WHERE   T1.IDX_CD = '/SY05') T5,
            (SELECT   T1.C_CD,
                      T1.CD,
                      T1.CD_NM,
                      T1.DP_ORDER
               FROM   SY5020 T1                       --#(HEC주석)VW_SY5020 T1
              WHERE   T1.IDX_CD = '/SY03') T6,
            (SELECT   T1.C_CD,
                      T1.OBJ_ID,
                      T1.OBJ_NM,
                      T1.STA_YMD,
                      T1.END_YMD
               FROM   SY3010 T1                       --#(HEC주석)VW_SY3010 T1
              WHERE   T1.OBJ_TYPE = 'O') T7,
            YA3060 T9                                 --#(HEC주석)VW_YA3060 T9
    WHERE       T2.C_CD = 'HEC'
            AND T2.EMP_ID LIKE '%'
            AND T3.C_CD = T2.C_CD
            AND T3.EMP_ID = T2.EMP_ID
            AND T3.LAST_YN = 'Y'
            AND T4.C_CD(+) = T3.C_CD
            AND T4.CD(+) = T3.POST_CD
            AND T5.C_CD(+) = T3.C_CD
            AND T5.CD(+) = T3.DUTY_CD
            AND T6.C_CD(+) = T3.C_CD
            AND T6.CD(+) = T3.EMP_GRADE_CD
            AND T7.C_CD(+) = T3.C_CD
            AND T7.OBJ_ID(+) = T3.ORG_ID
            AND T3.STA_YMD BETWEEN T7.STA_YMD(+) AND T7.END_YMD(+)
            AND T9.C_CD(+) = T7.C_CD
            AND T9.TRG_ORG_ID(+) = T7.OBJ_ID
/
