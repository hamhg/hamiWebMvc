CREATE VIEW EMP_HMGWARN AS SELECT SUBSTR (T1.EMP_ID, 3, 7) EMPNO,
          T1.EMP_NM NAME_KO,

          T4.OBJ_NM DEPT_NM,

          F_GET_CODENM (T2.C_CD, '/SY04', T2.POST_CD) POSITION_NM,
          T1.ENTER_YMD,
          GREATEST(T1.RETIRE_YMD, TO_CHAR(T2.INS_YMDHMS,'YYYYMMDD')) RETIRE_YMD,     -- 2016.09.27 정보보안 W/G 요청으로 퇴직 발령이 늦게 난 경우 최종 퇴직발령 시점으로 수정      
          T4.OBJ_ID,
          T1.MAIL_ADDR                         -- 2012/11/12 정보보안W/G로 이메일 추가요청

     FROM PA1010# T1,
          PA1020 T2,
          PY8010 T3,
          SY3010 T4
    WHERE     T1.C_CD = 'HEC'
          AND T2.C_CD = T1.C_CD
          AND T2.EMP_ID = T1.EMP_ID
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD AND T2.END_YMD
          AND T2.LAST_YN = 'Y'
          AND T2.EMP_TYPE NOT IN ('8H')                     -- 외주협력 직원은 AD사용안됨
          AND T3.C_CD(+) = T1.C_CD
          AND T3.EMP_ID(+) = T1.EMP_ID
          AND TO_CHAR (SYSDATE, 'YYYYMM') BETWEEN T3.STA_YM(+)
                                              AND T3.END_YM(+)
          AND T2.C_CD = T4.C_CD(+)
          AND T2.WORK_LOC_ID = T4.OBJ_ID(+)
/
COMMENT ON VIEW EMP_HMGWARN IS '[SEP_IF용] (EMP_HMGWARN)인사정보'
/
