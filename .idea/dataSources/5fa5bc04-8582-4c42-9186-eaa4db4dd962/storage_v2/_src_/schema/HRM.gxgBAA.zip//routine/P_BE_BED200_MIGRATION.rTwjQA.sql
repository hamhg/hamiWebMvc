CREATE PROCEDURE     P_BE_BED200_MIGRATION(
                            I_EXEC         IN  VARCHAR2,
                            O_ERRORCODE    OUT VARCHAR2,
                            O_ERRORMESG    OUT VARCHAR2,
                            O_BILL_SEQ_NO  OUT VARCHAR2
                            
)
IS
/***********************************************************************
 Program Name   : P_BE_BED200_MIGRATION
 Description    : 복리후생 자녀캠프 마이그레이션 작업 
 Author         : 윤병근 
 History        : 2010-11-10
***********************************************************************/
  CUR_YYYY           VARCHAR2(04);
  CUR_ORDER_SEQ      VARCHAR2(02);
  CUR_SABUNCD        VARCHAR2(09);
  CUR_JUMINNO        VARCHAR2(13);
  CUR_GWANKCD        VARCHAR2(03);  
  CUR_FAMILY_NAME    VARCHAR2(20);  
  CUR_ZIP_CODE       VARCHAR2(30);  
  CUR_ADDRESS_BASIC  VARCHAR2(100); 
  CUR_ADDRESS_DETAIL VARCHAR2(100); 
  CUR_ETC            VARCHAR2(300);
  CUR_CREATION_DT    DATE;
  CUR_MODIFY_DT      DATE;
  V_EDU_CURRI_ID     VARCHAR2(20);
  I_EDU_CURRI_ID_1   VARCHAR2(20);
  I_EDU_CURRI_ID_2   VARCHAR2(20);  
  I_EDU_CURRI_ID_3   VARCHAR2(20);  
  I_EDU_CURRI_ID_4   VARCHAR2(20);          
  V_EDU_CURRI_ID2    VARCHAR2(20);

  CURSOR CUR1 IS SELECT T1.YYYY,
                        T1.ORDER_SEQ,
                        T1.SABUNCD,
                        T1.JUMINNO,
                        T1.GWANKCD,
                        T1.FAMILY_NAME,
                        REPLACE(T1.ZIP_CODE,'-',''),
                        T1.ADDRESS_BASIC,
                        T1.ADDRESS_DETAIL,
                        SUBSTR(T1.ETC,1,300),
                        T1.CREATION_DT,
                        T1.MODIFY_DT
                   FROM HECLEG.TP01_CHILDREN_CAMP T1
                  WHERE NVL(T1.ORDER_SEQ,' ') > ' '
                    AND NVL(T1.ORDER_SEQ,0) > 0;           
              
                 

BEGIN

                 --==============================
                 --== 자녀캠프 관리테이블 삭제  = 
                 --==============================

                 DELETE  FROM BED200#;
                 

                 --==============================
                 --== 자녀캠프 시행과정 삭제    = 
                 --==============================                 
                 
                 DELETE  FROM TE3020 WHERE C_CD = 'HEC'
                                        AND EDU_CURRI_NM IN ('[방학前]영어캠프1 ',
                                                             '[방학中]영어캠프2 ',
                                                             '[방학中]역사문화캠프',
                                                             '[방학中]영재캠프')
                                        AND EDU_GRP_ID = 'T000000040';
                                                             
                 
                 --============================
                 --== 자녀캠프 코드생성      == 
                 --============================


                 SELECT LPAD(SEQ_TE3020.NEXTVAL, 10, '0')
                   INTO I_EDU_CURRI_ID_1
                   FROM DUAL;

                  INSERT INTO TE3020
                    (
                     C_CD,                EDU_CURRI_ID,   EDU_CURRI_NM,   EDU_ORDER_NO,
                     EDU_GRP_ID,          EDU_GRP_NM,     PLAN_YY,        PLAN_P_CNT,
                     APPL_STA_YMD,        APPL_END_YMD,   ATTEND_IFE_YN,  RPT_YN,
                     PFM_IFE_YN,          GRP_YN,         COS_STAT_CD,    EINS_REFUND_YN,
                     GUIDE_FILE_PATH,     GUIDE_FILE_NM,  GUIDE_URL,      EDU_TRG_TXT,
                     EDU_TYPE,            EDU_MTH_CD,     STA_YMD,        END_YMD,
                     EDU_ASSO_CD,         EDU_ASSO_NM,    EDU_GOAL_TXT,   EDU_TXT,
                     EDU_EXPT_EFFECT_TXT, EDU_PLACE_CD,   EDU_PLACE_NM,   EDU_D_CNT,
                     EDU_H_CNT,           PER_COST_MON,   PER_DDCT_MON,   PASS_SCORE,
                     NOTE,                MOD_USER_ID,    MOD_YMDHMS,     MAJOR_CLASS_CD,
                     MINOR_CLASS_CD,      APPROVE_METHOD, ORDER_CTL_YN,   EXPENSE_YN,
                     EXPENSE_YYMM,        BILL_PROCESS,   EDU_PROJECT_CD, REG_EMP_ID,
                     APPL_REG_YN,         INS_USER_ID,    INS_YMDHMS
                     )
                  VALUES
                    ('HEC',               I_EDU_CURRI_ID_1, '[방학前]영어캠프1 ',       '1',
                     'T000000036',        '영어캠프',     '2010',                     '0',
                     '19000101',          '99991231',     '',                         'N',
                     '',                  '',             '0010',                     'N',
                     '',                  '',             '',                         '',
                     '0030',              '0040',         '19000101',                 '99991231',
                     '99',                '기타',         '',                         '',
                     '',                  '0007',         '부천 복사골',              '0',
                     '0',                 '0',            '0',                        '0',
                     '',                  'SUPER',        SYSDATE,                    '0060',
                     '0230',              '001',          'N',                        'N',
                     '',                  'N',            '',                         '200600781',
                     'Y',                 'SUPER',        SYSDATE
                     );
                     
                     
                 SELECT LPAD(SEQ_TE3020.NEXTVAL, 10, '0')
                   INTO I_EDU_CURRI_ID_2
                   FROM DUAL;

                  INSERT INTO TE3020
                    (
                     C_CD,                EDU_CURRI_ID,   EDU_CURRI_NM,   EDU_ORDER_NO,
                     EDU_GRP_ID,          EDU_GRP_NM,     PLAN_YY,        PLAN_P_CNT,
                     APPL_STA_YMD,        APPL_END_YMD,   ATTEND_IFE_YN,  RPT_YN,
                     PFM_IFE_YN,          GRP_YN,         COS_STAT_CD,    EINS_REFUND_YN,
                     GUIDE_FILE_PATH,     GUIDE_FILE_NM,  GUIDE_URL,      EDU_TRG_TXT,
                     EDU_TYPE,            EDU_MTH_CD,     STA_YMD,        END_YMD,
                     EDU_ASSO_CD,         EDU_ASSO_NM,    EDU_GOAL_TXT,   EDU_TXT,
                     EDU_EXPT_EFFECT_TXT, EDU_PLACE_CD,   EDU_PLACE_NM,   EDU_D_CNT,
                     EDU_H_CNT,           PER_COST_MON,   PER_DDCT_MON,   PASS_SCORE,
                     NOTE,                MOD_USER_ID,    MOD_YMDHMS,     MAJOR_CLASS_CD,
                     MINOR_CLASS_CD,      APPROVE_METHOD, ORDER_CTL_YN,   EXPENSE_YN,
                     EXPENSE_YYMM,        BILL_PROCESS,   EDU_PROJECT_CD, REG_EMP_ID,
                     APPL_REG_YN,         INS_USER_ID,    INS_YMDHMS
                     )
                  VALUES
                    ('HEC',               I_EDU_CURRI_ID_2, '[방학中]영어캠프2 ',       '1',
                     'T000000036',        '영어캠프',     '2010',                     '0',
                     '19000101',          '99991231',     '',                         'N',
                     '',                  '',             '0010',                     'N',
                     '',                  '',             '',                         '',
                     '0030',              '0040',         '19000101',                 '99991231',
                     '99',                '기타',         '',                         '',
                     '',                  '0007',         '부천 복사골',              '0',
                     '0',                 '0',            '0',                        '0',
                     '',                  'SUPER',        SYSDATE,                    '0060',
                     '0230',              '001',          'N',                        'N',
                     '',                  'N',            '',                         '200600781',
                     'Y',                 'SUPER',        SYSDATE
                     );                     

                 SELECT LPAD(SEQ_TE3020.NEXTVAL, 10, '0')
                   INTO I_EDU_CURRI_ID_3
                   FROM DUAL;

                  INSERT INTO TE3020
                    (
                     C_CD,                EDU_CURRI_ID,   EDU_CURRI_NM,   EDU_ORDER_NO,
                     EDU_GRP_ID,          EDU_GRP_NM,     PLAN_YY,        PLAN_P_CNT,
                     APPL_STA_YMD,        APPL_END_YMD,   ATTEND_IFE_YN,  RPT_YN,
                     PFM_IFE_YN,          GRP_YN,         COS_STAT_CD,    EINS_REFUND_YN,
                     GUIDE_FILE_PATH,     GUIDE_FILE_NM,  GUIDE_URL,      EDU_TRG_TXT,
                     EDU_TYPE,            EDU_MTH_CD,     STA_YMD,        END_YMD,
                     EDU_ASSO_CD,         EDU_ASSO_NM,    EDU_GOAL_TXT,   EDU_TXT,
                     EDU_EXPT_EFFECT_TXT, EDU_PLACE_CD,   EDU_PLACE_NM,   EDU_D_CNT,
                     EDU_H_CNT,           PER_COST_MON,   PER_DDCT_MON,   PASS_SCORE,
                     NOTE,                MOD_USER_ID,    MOD_YMDHMS,     MAJOR_CLASS_CD,
                     MINOR_CLASS_CD,      APPROVE_METHOD, ORDER_CTL_YN,   EXPENSE_YN,
                     EXPENSE_YYMM,        BILL_PROCESS,   EDU_PROJECT_CD, REG_EMP_ID,
                     APPL_REG_YN,         INS_USER_ID,    INS_YMDHMS
                     )
                  VALUES
                    ('HEC',               I_EDU_CURRI_ID_3, '[방학中]역사문화캠프',     '1',
                     'T000000036',        '영어캠프',     '2010',                     '0',
                     '19000101',          '99991231',     '',                         'N',
                     '',                  '',             '0010',                     'N',
                     '',                  '',             '',                         '',
                     '0030',              '0040',         '19000101',                 '99991231',
                     '99',                '기타',         '',                         '',
                     '',                  '0007',         '부천 복사골',              '0',
                     '0',                 '0',            '0',                        '0',
                     '',                  'SUPER',        SYSDATE,                    '0060',
                     '0230',              '001',          'N',                        'N',
                     '',                  'N',            '',                         '200600781',
                     'Y',                 'SUPER',        SYSDATE
                     );                     

                 SELECT LPAD(SEQ_TE3020.NEXTVAL, 10, '0')
                   INTO I_EDU_CURRI_ID_4
                   FROM DUAL;

                  INSERT INTO TE3020
                    (
                     C_CD,                EDU_CURRI_ID,   EDU_CURRI_NM,   EDU_ORDER_NO,
                     EDU_GRP_ID,          EDU_GRP_NM,     PLAN_YY,        PLAN_P_CNT,
                     APPL_STA_YMD,        APPL_END_YMD,   ATTEND_IFE_YN,  RPT_YN,
                     PFM_IFE_YN,          GRP_YN,         COS_STAT_CD,    EINS_REFUND_YN,
                     GUIDE_FILE_PATH,     GUIDE_FILE_NM,  GUIDE_URL,      EDU_TRG_TXT,
                     EDU_TYPE,            EDU_MTH_CD,     STA_YMD,        END_YMD,
                     EDU_ASSO_CD,         EDU_ASSO_NM,    EDU_GOAL_TXT,   EDU_TXT,
                     EDU_EXPT_EFFECT_TXT, EDU_PLACE_CD,   EDU_PLACE_NM,   EDU_D_CNT,
                     EDU_H_CNT,           PER_COST_MON,   PER_DDCT_MON,   PASS_SCORE,
                     NOTE,                MOD_USER_ID,    MOD_YMDHMS,     MAJOR_CLASS_CD,
                     MINOR_CLASS_CD,      APPROVE_METHOD, ORDER_CTL_YN,   EXPENSE_YN,
                     EXPENSE_YYMM,        BILL_PROCESS,   EDU_PROJECT_CD, REG_EMP_ID,
                     APPL_REG_YN,         INS_USER_ID,    INS_YMDHMS
                     )
                  VALUES
                    ('HEC',               I_EDU_CURRI_ID_4, '[방학中]영재캠프',         '1',
                     'T000000036',        '영어캠프',     '2010',                     '0',
                     '19000101',          '99991231',     '',                         'N',
                     '',                  '',             '0010',                     'N',
                     '',                  '',             '',                         '',
                     '0030',              '0040',         '19000101',                 '99991231',
                     '99',                '기타',         '',                         '',
                     '',                  '0007',         '부천 복사골',              '0',
                     '0',                 '0',            '0',                        '0',
                     '',                  'SUPER',        SYSDATE,                    '0060',
                     '0230',              '001',          'N',                        'N',
                     '',                  'N',            '',                         '200600781',
                     'Y',                 'SUPER',        SYSDATE
                     );                     


  
       OPEN CUR1;                      
            LOOP FETCH CUR1            
                  INTO CUR_YYYY,
                       CUR_ORDER_SEQ,
                       CUR_SABUNCD,
                       CUR_JUMINNO,
                       CUR_GWANKCD,
                       CUR_FAMILY_NAME,
                       CUR_ZIP_CODE,
                       CUR_ADDRESS_BASIC,
                       CUR_ADDRESS_DETAIL,
                       CUR_ETC,
                       CUR_CREATION_DT,
                       CUR_MODIFY_DT;
                 IF CUR1%NOTFOUND THEN 
                    GOTO END_RTN;      
                 END IF;
  

  
                 --==============================
                 --==  과정정보 가져오기       ==
                 --==============================  
                 --0000003291    [방학前]영어캠프1     I_EDU_CURRI_ID_1
                 --0000003292    [방학中]영어캠프2     I_EDU_CURRI_ID_2
                 --0000003293    [방학中]역사문화캠프  I_EDU_CURRI_ID_3
                 --0000003294    [방학中]영재캠프      I_EDU_CURRI_ID_4
                 
                 -- 교육코드관련 
                 --1 : [방학前]영어캠프1 
                 --2 : [방학中]영어캠프2 
                 --3 : [방학中]역사문화캠프 
                 --4 : [방학中]영재캠프 
                 --5 : [방학前]영어캠프1+[방학中]영어캠프2 
                 --6 : [방학前]영어캠프1+[방학中]역사문화캠프 
                 --7 : [방학前]영어캠프1+[방학中]영재캠프 
                 
                 IF CUR_ORDER_SEQ = '5' THEN 
                    V_EDU_CURRI_ID  := I_EDU_CURRI_ID_1;
                    V_EDU_CURRI_ID2 := I_EDU_CURRI_ID_2;
                 ELSIF CUR_ORDER_SEQ = '6' THEN     
                    V_EDU_CURRI_ID  := I_EDU_CURRI_ID_1;
                    V_EDU_CURRI_ID2 := I_EDU_CURRI_ID_3;                
                 ELSIF CUR_ORDER_SEQ = '7' THEN     
                    V_EDU_CURRI_ID  := I_EDU_CURRI_ID_1;
                    V_EDU_CURRI_ID2 := I_EDU_CURRI_ID_4;                                 
                 ELSIF CUR_ORDER_SEQ = '1' THEN   
                    V_EDU_CURRI_ID  := I_EDU_CURRI_ID_1;
                    V_EDU_CURRI_ID2 := NULL;
                 ELSIF CUR_ORDER_SEQ = '2' THEN   
                    V_EDU_CURRI_ID  := I_EDU_CURRI_ID_2;
                    V_EDU_CURRI_ID2 := NULL;
                 ELSIF CUR_ORDER_SEQ = '3' THEN   
                    V_EDU_CURRI_ID  := I_EDU_CURRI_ID_3;
                    V_EDU_CURRI_ID2 := NULL;                                        
                 ELSIF CUR_ORDER_SEQ = '4' THEN   
                    V_EDU_CURRI_ID  := I_EDU_CURRI_ID_4;
                    V_EDU_CURRI_ID2 := NULL;                                                            
                 END IF;
                 
  
                 --==============================
                 --==  자녀캠프 신청등록 1     ==
                 --==============================
                 
                 IF NVL(V_EDU_CURRI_ID,' ') > ' '  THEN

                     INSERT INTO  BED200#(C_CD,        
                                         YY,          
                                         EDU_CURRI_ID,
                                         EMP_ID,      
                                         FAM_PER_NO,  
                                         EDU_ORDER_NO,
                                         FAM_NM,      
                                         FAM_CD,      
                                         ZIP_NO,      
                                         ADDR,        
                                         DTL_ADDR,    
                                         TRG_YN,      
                                         ATTEND_YN,   
                                         BILL_NO,     
                                         NOTE,        
                                         MAIL_SUBM_YN,
                                         INS_USER_ID, 
                                         INS_YMDHMS,  
                                         MOD_USER_ID, 
                                         MOD_YMDHMS  
                                         )
                                  VALUES('HEC',  
                                         CUR_YYYY,      
                                         V_EDU_CURRI_ID,
                                         CUR_SABUNCD,
                                         F_HEC_ENC_PER(CUR_JUMINNO),
                                         '1',
                                         CUR_FAMILY_NAME,
                                         CUR_GWANKCD,
                                         CUR_ZIP_CODE,
                                         CUR_ADDRESS_BASIC,
                                         CUR_ADDRESS_DETAIL,
                                         'Y',
                                         'Y',
                                         0,
                                         CUR_ETC,
                                         'N',
                                         'MIGRATION',
                                         CUR_CREATION_DT,
                                         'MIGRATION',
                                         CUR_MODIFY_DT 
                                         );
                 END IF;
                  
                 --==============================
                 --==  자녀캠프 신청등록 2     ==
                 --==============================
                 
                 IF NVL(V_EDU_CURRI_ID2,' ') > ' '  THEN

                     INSERT INTO  BED200#(C_CD,        
                                         YY,          
                                         EDU_CURRI_ID,
                                         EMP_ID,      
                                         FAM_PER_NO,  
                                         EDU_ORDER_NO,
                                         FAM_NM,      
                                         FAM_CD,      
                                         ZIP_NO,      
                                         ADDR,        
                                         DTL_ADDR,    
                                         TRG_YN,      
                                         ATTEND_YN,   
                                         BILL_NO,     
                                         NOTE,        
                                         MAIL_SUBM_YN,
                                         INS_USER_ID, 
                                         INS_YMDHMS,  
                                         MOD_USER_ID, 
                                         MOD_YMDHMS  
                                         )
                                  VALUES('HEC',  
                                         CUR_YYYY,      
                                         V_EDU_CURRI_ID2,
                                         CUR_SABUNCD,
                                         F_HEC_ENC_PER(CUR_JUMINNO),
                                         '1',
                                         CUR_FAMILY_NAME,
                                         CUR_GWANKCD,
                                         CUR_ZIP_CODE,
                                         CUR_ADDRESS_BASIC,
                                         CUR_ADDRESS_DETAIL,
                                         'Y',
                                         'Y',
                                         0,
                                         CUR_ETC,
                                         'N',
                                         'MIGRATION',
                                         CUR_CREATION_DT,
                                         'MIGRATION',
                                         CUR_MODIFY_DT 
                                         );
                 END IF;
  
       END LOOP;    
  
       << END_RTN >>     
       CLOSE  CUR1;  
  
EXCEPTION
  WHEN OTHERS THEN
    O_ERRORCODE := SQLCODE;
    O_ERRORMESG := SQLERRM;  
END P_BE_BED200_MIGRATION;
/
