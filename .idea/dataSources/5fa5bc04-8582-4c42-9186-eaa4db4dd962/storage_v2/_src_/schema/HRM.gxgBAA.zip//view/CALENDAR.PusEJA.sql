CREATE VIEW CALENDAR AS SELECT T1.YMD CURDATE,                                                 --날짜
          TO_CHAR(TO_CHAR (
             TO_DATE (
                SUBSTR (YMD, 1, 6)
                || LPAD (TO_CHAR (SUBSTR (YMD, 7, 2)), 2, '0'),
                'YYYYMMDD'),
             'D')
          - 1) WEEK,                                                        --요일
          CASE
             WHEN F_GET_COND_CD1 (T1.C_CD, '/TM30', T1.WORK_TYPE) = 'Y'
             THEN
                '0'
             ELSE
                '1'
          END
             HOLDAY                                                       --휴일
     FROM TM0350 T1
/
