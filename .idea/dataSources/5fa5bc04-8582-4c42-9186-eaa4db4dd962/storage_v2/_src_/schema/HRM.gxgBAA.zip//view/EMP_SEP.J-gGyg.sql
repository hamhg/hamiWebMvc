CREATE VIEW EMP_SEP AS SELECT SUBSTR (T1.EMP_ID, 3, 7) EMPNO,
          T1.EMP_NM NAME_KO,
          --T2.ORG_ID ORG_ID,
          T4.OBJ_NM DEPT_NM,
          --T2.EMP_TYPE,

          --T2.POST_CD POSITION_CD,
          F_GET_CODENM (T2.C_CD, '/SY04', T2.POST_CD) POSITION_NM,
          T1.ENTER_YMD,
          T1.RETIRE_YMD,
          T4.OBJ_ID,
          T1.MAIL_ADDR                         -- 2012/11/12 정보보안W/G로 이메일 추가요청
     --NVL (F_GET_CODENM (T1.C_CD, '00090', T1.LOC_CD), '') OFFICD_NM,

     --T1.WORK_LOC_TEL_NO PHONE_OFFICE,

     --T1.MOBILE_NO PHONE_MOBILE,

     --T1.TEL_NO PHONE_HOME,

     --T1.WORK_LOC_FAX FAX_OFFICE,

     --            CASE

     --               WHEN T2.STAT_CD = '30' THEN '4'

     --               WHEN T2.STAT_CD = '13' THEN '2'

     --               WHEN T2.STAT_CD = '10' AND T3.EMP_ID IS NOT NULL THEN '5'

     --               WHEN T2.STAT_CD = '10' THEN '1'

     --               ELSE ''

     --            END

     --               EMP_STATUS,

     --            CASE

     --               WHEN T2.STAT_CD = '30' THEN '4'

     --               WHEN T2.STAT_CD LIKE '1%' AND T3.EMP_ID IS NOT NULL THEN '5'

     --               WHEN T2.STAT_CD LIKE '1%' THEN '1'

     --               ELSE ''

     --            END

     --               RETIRE_STATUS
     FROM PA1010# T1,
          PA1020 T2,
          PY8010 T3,
          SY3010 T4
    WHERE     T1.C_CD = 'HEC'
          AND T2.C_CD = T1.C_CD
          AND T2.EMP_ID = T1.EMP_ID
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD AND T2.END_YMD
          AND T2.LAST_YN = 'Y'
          AND T2.EMP_TYPE NOT IN ('8H')                     -- 외주협력 직원은 AD사용안됨
          AND T3.C_CD(+) = T1.C_CD
          AND T3.EMP_ID(+) = T1.EMP_ID
          AND TO_CHAR (SYSDATE, 'YYYYMM') BETWEEN T3.STA_YM(+)
                                              AND T3.END_YM(+)
          AND T2.C_CD = T4.C_CD(+)
          AND T2.WORK_LOC_ID = T4.OBJ_ID(+)
/
COMMENT ON VIEW EMP_SEP IS '[SEP_IF용] (EMP_SEP)인사정보'
/
