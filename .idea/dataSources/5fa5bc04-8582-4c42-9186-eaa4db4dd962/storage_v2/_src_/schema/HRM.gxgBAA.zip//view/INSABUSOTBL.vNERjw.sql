CREATE VIEW INSABUSOTBL AS SELECT 'HE' COMPANYCD,
          'ko' LANGCD,
          T1.OBJ_ID BUSOCD,
          --NVL (T4.OBJ_NM, T3.OBJ_NM) AS BUSONM,     -- 원소속명칭이 없는 경우 근무지 명칭 기표
          CASE
             WHEN T4.OBJ_NM IS NULL
             THEN
                T3.OBJ_NM
             WHEN TRIM (F_ORG_NM (T2.C_CD,
                                  TO_CHAR (SYSDATE, 'YYYYMMDD'),
                                  T2.ORG_ID,
                                  '4D')) <> TRIM (T3.OBJ_NM)
             THEN
                T3.OBJ_NM
             ELSE
                T4.OBJ_NM
          END
             AS BUSONM,
          NVL (NVL (T4.ENG_OBJ_NM, T3.ENG_OBJ_NM), T4.OBJ_NM) AS EBUSONM -- 원소속명칭이 없는 경우 근무지 명칭 기표
                                                                        ,
          NULL AS SBUSONM,
          '1' AS BUSOGB,
          '1' AS BONSAGB,
          T1.PAR_OBJ_ID AS ROOTCD,
          T1.STA_YMD AS CREATEDATE,
          T1.END_YMD AS DELETEDATE,
          'Y' AS DISPLAYYN,
          '대한민국' AS NATIONALNM,
          'KR' AS NATIONALCD,
          NULL AS AREA,
          T1.SEQ SORTORDER
     FROM (           SELECT LEVEL TLEVEL,
                             T1.OBJ_TYPE,
                             T1.OBJ_ID,
                             T1.PAR_OBJ_TYPE,
                             T1.PAR_OBJ_ID,
                             T1.STA_YMD,
                             T1.END_YMD,
                             ROWNUM SEQ
                        FROM (SELECT T1.*
                                FROM SY3020 T1
                               WHERE     T1.C_CD = 'HEC'
                                     AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN T1.STA_YMD
                                                                           AND T1.END_YMD)
                             T1
                  START WITH     (T1.C_CD, T1.OBJ_TYPE, T1.OBJ_ID) IN (SELECT C_CD,
                                                                              ROOT_OBJ_TYPE,
                                                                              ROOT_OBJ_ID
                                                                         FROM SY3070
                                                                        WHERE     C_CD =
                                                                                     'HEC'
                                                                              AND OBJ_TREE_TYPE =
                                                                                     'WATREE'
                                                                              AND TO_CHAR (
                                                                                     SYSDATE,
                                                                                     'YYYYMMDD') BETWEEN STA_YMD
                                                                                                     AND END_YMD)
                             AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                   AND T1.END_YMD
                  CONNECT BY     PRIOR T1.C_CD = T1.C_CD
                             AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
                             AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
           ORDER SIBLINGS BY T1.SEQ_NO) T1,
          OM3010 T2,
          SY3010 T3,
          SY3010 T4
    WHERE     T2.C_CD(+) = 'HEC'
          AND T2.WORK_LOC_ID(+) = T1.OBJ_ID
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD(+)
                                                AND T2.END_YMD(+)
          AND T3.C_CD(+) = 'HEC'
          AND T3.OBJ_ID(+) = T1.OBJ_ID
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T3.STA_YMD AND T3.END_YMD
          AND T4.OBJ_ID(+) = T2.ORG_ID
          AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T4.STA_YMD(+)
                                                AND T4.END_YMD(+)
          AND T1.OBJ_ID NOT IN ('WA00009583'        -- UC조직도상에서 발령대기 제외 요청 20160215
                               ,'WA00009237'        -- UC조직도상에서 인사대기 제외 요청 20160421
                               ) 
   -- UC조직도상 본부장은 본부아래 동일한 명칭의 조직을 기표하기 위해 추가. 2015.10.08
   UNION
   SELECT COMPANYCD,
          LANGCD,
          BUSOCD,
          BUSONM,
          EBUSONM,
          SBUSONM,
          BUSOGB,
          BONSAGB,
          ROOTCD,
          CREATEDATE,
          DELETEDATE,
          DISPLAYYN,
          NATIONALNM,
          NATIONALCD,
          AREA,
          SORTORDER                              -- 사업본부 바로 아래에 기표하기위해 정렬순서 추가
     FROM (SELECT 'HE' COMPANYCD,
                  'ko' LANGCD,
                  'X' || T1.OBJ_ID BUSOCD,
                  CASE
                     WHEN T4.OBJ_NM IS NULL
                     THEN
                        T3.OBJ_NM
                     WHEN TRIM (F_ORG_NM (T2.C_CD,
                                          TO_CHAR (SYSDATE, 'YYYYMMDD'),
                                          T2.ORG_ID,
                                          '4D')) <> TRIM (T3.OBJ_NM)
                     THEN
                        T3.OBJ_NM
                     ELSE
                        T4.OBJ_NM
                  END
                     AS BUSONM,
                  NVL (NVL (T4.ENG_OBJ_NM, T3.ENG_OBJ_NM), T4.OBJ_NM)
                     AS EBUSONM                      -- 원소속명칭이 없는 경우 근무지 명칭 기표
                               ,
                  NULL AS SBUSONM,
                  '1' AS BUSOGB,
                  '1' AS BONSAGB,
                  --T1.PAR_OBJ_ID AS ROOTCD,
                  T1.OBJ_ID AS ROOTCD,                 -- 본부장실은 자기자신 밑에 달아버린다.
                  T1.STA_YMD AS CREATEDATE,
                  T1.END_YMD AS DELETEDATE,
                  'Y' AS DISPLAYYN,
                  '대한민국' AS NATIONALNM,
                  'KR' AS NATIONALCD,
                  NULL AS AREA,
                  T1.SEQ AS SORTORDER
             FROM (           SELECT LEVEL TLEVEL,
                                     T1.OBJ_TYPE,
                                     T1.OBJ_ID,
                                     T1.PAR_OBJ_TYPE,
                                     T1.PAR_OBJ_ID,
                                     T1.STA_YMD,
                                     T1.END_YMD,
                                     ROWNUM SEQ
                                FROM (SELECT T1.*
                                        FROM SY3020 T1
                                       WHERE     T1.C_CD = 'HEC'
                                             AND TO_CHAR (SYSDATE, 'yyyymmdd') BETWEEN T1.STA_YMD
                                                                                   AND T1.END_YMD)
                                     T1
                          START WITH     (T1.C_CD, T1.OBJ_TYPE, T1.OBJ_ID) IN (SELECT C_CD,
                                                                                      ROOT_OBJ_TYPE,
                                                                                      ROOT_OBJ_ID
                                                                                 FROM SY3070
                                                                                WHERE     C_CD =
                                                                                             'HEC'
                                                                                      AND OBJ_TREE_TYPE =
                                                                                             'WATREE'
                                                                                      AND TO_CHAR (
                                                                                             SYSDATE,
                                                                                             'YYYYMMDD') BETWEEN STA_YMD
                                                                                                             AND END_YMD)
                                     AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T1.STA_YMD
                                                                           AND T1.END_YMD
                          CONNECT BY     PRIOR T1.C_CD = T1.C_CD
                                     AND PRIOR T1.OBJ_TYPE = T1.PAR_OBJ_TYPE
                                     AND PRIOR T1.OBJ_ID = T1.PAR_OBJ_ID
                   ORDER SIBLINGS BY T1.SEQ_NO) T1,
                  OM3010 T2,
                  SY3010 T3,
                  SY3010 T4,
                  OM0010 T5
            WHERE     T2.C_CD(+) = 'HEC'
                  AND T2.WORK_LOC_ID(+) = T1.OBJ_ID
                  AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T2.STA_YMD(+)
                                                        AND T2.END_YMD(+)
                  AND T3.C_CD(+) = 'HEC'
                  AND T3.OBJ_ID(+) = T1.OBJ_ID
                  AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T3.STA_YMD
                                                        AND T3.END_YMD
                  AND T4.OBJ_ID(+) = T2.ORG_ID
                  AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T4.STA_YMD(+)
                                                        AND T4.END_YMD(+)
                  AND T5.ORG_ID(+) = T2.ORG_ID
                  AND TO_CHAR (SYSDATE, 'YYYYMMDD') BETWEEN T5.STA_YMD(+)
                                                        AND T5.END_YMD(+)
                  AND T5.ORG_CLASS = '002'     -- 사업본부에 해당하는 경우만 추가 : 조직등급이 본부
                  AND T1.OBJ_ID <> 'WA00008610' -- 사장직속은 사업본부 등급이지만 중복기표되지 않도록 제외처리.
                                               )
   ORDER BY SORTORDER
/
