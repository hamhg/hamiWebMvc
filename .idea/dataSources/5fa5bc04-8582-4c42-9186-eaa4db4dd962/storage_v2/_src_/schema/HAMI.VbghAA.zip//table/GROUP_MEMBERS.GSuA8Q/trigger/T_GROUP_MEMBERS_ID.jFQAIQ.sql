create trigger T_GROUP_MEMBERS_ID
  before insert
  on GROUP_MEMBERS
  for each row
  BEGIN
    SELECT NVL(MAX(ID)+1,1) INTO :NEW.ID FROM GROUP_MEMBERS;
  END;
/

