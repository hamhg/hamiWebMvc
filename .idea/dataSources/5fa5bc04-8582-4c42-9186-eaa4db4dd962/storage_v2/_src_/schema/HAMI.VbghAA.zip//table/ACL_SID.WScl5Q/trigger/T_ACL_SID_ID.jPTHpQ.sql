create trigger T_ACL_SID_ID
  before insert
  on ACL_SID
  for each row
  BEGIN
    SELECT NVL(MAX(ID)+1,1) INTO :NEW.ID FROM ACL_SID;
  END;
/

