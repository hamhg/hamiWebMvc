create trigger T_ACL_CLASS_ID
  before insert
  on ACL_CLASS
  for each row
  BEGIN
    SELECT NVL(MAX(ID)+1,1) INTO :NEW.ID FROM ACL_CLASS;
  END;
/

