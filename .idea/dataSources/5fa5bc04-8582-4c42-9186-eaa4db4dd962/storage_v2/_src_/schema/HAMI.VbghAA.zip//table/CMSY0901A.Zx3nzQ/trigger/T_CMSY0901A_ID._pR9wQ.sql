create trigger T_CMSY0901A_ID
  before insert
  on CMSY0901A
  for each row
  BEGIN
    SELECT NVL(MAX(ID)+1,1)
    INTO   :NEW.ID
    FROM   CMSY0901A;
  END;
/

