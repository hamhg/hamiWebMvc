create view AUTHORITIES as
  SELECT  ID, USER_ID AS USERNAME, AUTHORITY
  FROM CMSY0901A
/

comment on table AUTHORITIES
is 'Login User Info'
/

