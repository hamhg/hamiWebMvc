create trigger T_GROUPS_ID
  before insert
  on GROUPS
  for each row
  BEGIN
    SELECT NVL(MAX(ID)+1,1) INTO :NEW.ID FROM GROUPS;
  END;
/

