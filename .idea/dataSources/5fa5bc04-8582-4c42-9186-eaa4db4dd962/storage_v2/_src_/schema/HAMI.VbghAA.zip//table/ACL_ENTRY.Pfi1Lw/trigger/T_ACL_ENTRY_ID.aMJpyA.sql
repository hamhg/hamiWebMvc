create trigger T_ACL_ENTRY_ID
  before insert
  on ACL_ENTRY
  for each row
  BEGIN
    SELECT NVL(MAX(ID)+1,1) INTO :NEW.ID FROM ACL_ENTRY;
  END;
/

