create view USERS as
  SELECT USER_ID AS USERNAME, PASSWORD, ENABLED
  FROM CMSY0900A
/

comment on table USERS
is 'Login User Info'
/

